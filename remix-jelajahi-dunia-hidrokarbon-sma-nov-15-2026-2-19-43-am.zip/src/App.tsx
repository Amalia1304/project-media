/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Aplikasi Utama "Jelajahi Dunia Hidrokarbon"
 * Media pembelajaran interaktif kimia SMA/MA Kelas XI
 */

import React, { useState, useEffect } from 'react';
import { Navbar, NavTab } from './components/Navbar';
import { Footer } from './components/Footer';
import { BerandaPage } from './components/pages/BerandaPage';
import { MateriPage, MateriTarget } from './components/pages/MateriPage';
import { LatihanSoalPage } from './components/pages/LatihanSoalPage';
import { PenilaianDiriPage } from './components/pages/PenilaianDiriPage';
import { TentangPage } from './components/pages/TentangPage';

const PETA_KONSEP_TO_MATERI: Record<string, MateriTarget> = {
  akar: { kegiatan: 'kegiatan-1', subBabId: '1.1' },
  struktur: { kegiatan: 'kegiatan-1', subBabId: '1.1' },
  kekhasan: { kegiatan: 'kegiatan-1', subBabId: '1.1' },
  'jenis-c': { kegiatan: 'kegiatan-1', subBabId: '1.3' },
  penggolongan: { kegiatan: 'kegiatan-2', subBabId: '2.1' },
  alkana: { kegiatan: 'kegiatan-2', subBabId: '2.1' },
  alkena: { kegiatan: 'kegiatan-2', subBabId: '2.1' },
  alkuna: { kegiatan: 'kegiatan-2', subBabId: '2.1' },
  sifat: { kegiatan: 'kegiatan-3', subBabId: '3.1' },
  reaksi: { kegiatan: 'kegiatan-3', subBabId: '3.2' },
  isomer: { kegiatan: 'kegiatan-3', subBabId: '3.4' },
};

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>(() => {
    try {
      const saved = localStorage.getItem('hidrokarbon_active_tab');
      if (
        saved &&
        ['beranda', 'materi', 'latihan-soal', 'penilaian-diri', 'tentang'].includes(saved)
      ) {
        return saved as NavTab;
      }
    } catch {
      // localStorage may fail in restricted iframes
    }
    return 'beranda';
  });

  const [latihanConfig, setLatihanConfig] = useState<{
    view: 'menu' | 'builder';
    challengeId?: string;
  }>({ view: 'menu' });

  const [materiTarget, setMateriTarget] = useState<MateriTarget | undefined>(undefined);

  // Persist active tab to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('hidrokarbon_active_tab', currentTab);
    } catch {
      // Ignore
    }
  }, [currentTab]);

  const handleTabChange = (tab: NavTab) => {
    if (tab === 'latihan-soal') {
      setLatihanConfig({ view: 'menu' });
    }
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenMateri = (
    kegiatan: 'kegiatan-1' | 'kegiatan-2' | 'kegiatan-3',
    subBabId?: string
  ) => {
    setMateriTarget({ kegiatan, subBabId, nonce: Date.now() });
    setCurrentTab('materi');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenStructureBuilder = (challengeId?: string) => {
    setLatihanConfig({ view: 'builder', challengeId });
    setCurrentTab('latihan-soal');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectSubBab = (nodeId: string) => {
    const mapped = PETA_KONSEP_TO_MATERI[nodeId] || {
      kegiatan: 'kegiatan-1',
      subBabId: '1.1',
    };
    handleOpenMateri(mapped.kegiatan, mapped.subBabId);
  };

  return (
    <div className="galaxy-bg min-h-screen flex flex-col text-[#EEEDFB] font-sans antialiased">
      {/* 1. Sticky Navigation */}
      <Navbar currentTab={currentTab} onTabChange={handleTabChange} />

      {/* 2. Main Content Viewport */}
      <main className="flex-1 w-full overflow-x-hidden">
        {currentTab === 'beranda' && (
          <BerandaPage
            onNavigateTab={handleTabChange}
            onSelectSubBab={handleSelectSubBab}
            onOpenMateri={handleOpenMateri}
            onOpenStructureBuilder={handleOpenStructureBuilder}
          />
        )}

        {currentTab === 'materi' && (
          <MateriPage
            onBackToBeranda={() => handleTabChange('beranda')}
            onOpenStructureBuilder={handleOpenStructureBuilder}
            initialTarget={materiTarget}
          />
        )}

        {currentTab === 'latihan-soal' && (
          <LatihanSoalPage
            onBackToBeranda={() => handleTabChange('beranda')}
            onNavigateTab={handleTabChange}
            onOpenMateri={handleOpenMateri}
            initialView={latihanConfig.view}
            initialChallengeId={latihanConfig.challengeId}
          />
        )}

        {currentTab === 'penilaian-diri' && (
          <PenilaianDiriPage
            onBackToBeranda={() => handleTabChange('beranda')}
            onNavigateTab={handleTabChange}
            onOpenMateri={handleOpenMateri}
          />
        )}

        {currentTab === 'tentang' && (
          <TentangPage
            onBackToBeranda={() => handleTabChange('beranda')}
            onNavigateTab={handleTabChange}
            onOpenMateri={handleOpenMateri}
            onOpenStructureBuilder={handleOpenStructureBuilder}
          />
        )}
      </main>

      {/* 3. Official Attribution & Navigation Footer */}
      <Footer currentTab={currentTab} onNavigateTab={handleTabChange} />
    </div>
  );
}
