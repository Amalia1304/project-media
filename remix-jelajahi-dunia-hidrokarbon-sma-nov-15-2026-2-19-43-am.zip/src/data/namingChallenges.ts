/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Kumpulan 10 Tantangan Permainan Memberi Nama IUPAC Struktur Senyawa Hidrokarbon
 * Mencakup Alkana, Alkena, Alkuna, penomoran kiri/kanan, urutan abjad, dan rantai induk berbelok.
 */

export interface NamingNode {
  id: string;
  row: number;
  col: number;
  formula: string; // e.g. "CH3", "CH2", "CH", "C"
  chainNum?: number; // 1..N untuk rantai induk
  isMainChain: boolean;
}

export interface NamingBond {
  from: string;
  to: string;
  order: 1 | 2 | 3;
}

export interface NamingChallenge {
  id: string;
  level: number;
  tingkat: 'Mudah' | 'Sedang' | 'Tantangan';
  golongan: 'alkana' | 'alkena' | 'alkuna';
  jawabanResmi: string;
  jawabanAlternatif?: string[];
  rantaiIndukBenar: string;
  arahPenomoran: string;
  wrongDirectionTrap?: string;
  wrongAlphabetTrap?: string;
  missingMultiplierTrap?: string;
  petunjuk: string;
  pembahasan: string;
  tokenBank: {
    angka: string[];
    cabang: string[];
    induk: string[];
  };
  nodes: NamingNode[];
  bonds: NamingBond[];
}

export const NAMING_CHALLENGES: NamingChallenge[] = [
  {
    id: 'name-1',
    level: 1,
    tingkat: 'Mudah',
    golongan: 'alkana',
    jawabanResmi: '2-metilbutana',
    rantaiIndukBenar: 'butana',
    arahPenomoran: 'Dari kiri ke kanan (cabang metil lebih dekat ke ujung kiri)',
    wrongDirectionTrap: '3-metilbutana',
    petunjuk:
      'Rantai terpanjang terdiri dari 4 atom C (butana). Mulailah penomoran dari ujung paling dekat dengan cabang —CH₃.',
    pembahasan:
      '• Rantai terpanjang = 4 atom C (butana).\n• Penomoran dari ujung kiri memberi cabang nomor 2 (dari kanan nomor 3).\n• Cabang metil (—CH₃) terletak di C-2 → 2-metilbutana.',
    tokenBank: {
      angka: ['1', '2', '3', '4'],
      cabang: ['metil', 'etil', 'dimetil'],
      induk: ['propana', 'butana', 'pentana'],
    },
    nodes: [
      { id: 'n1', row: 1, col: 0, formula: 'CH3', chainNum: 1, isMainChain: true },
      { id: 'n2', row: 1, col: 1, formula: 'CH', chainNum: 2, isMainChain: true },
      { id: 'n3', row: 1, col: 2, formula: 'CH2', chainNum: 3, isMainChain: true },
      { id: 'n4', row: 1, col: 3, formula: 'CH3', chainNum: 4, isMainChain: true },
      { id: 'b1', row: 2, col: 1, formula: 'CH3', isMainChain: false },
    ],
    bonds: [
      { from: 'n1', to: 'n2', order: 1 },
      { from: 'n2', to: 'n3', order: 1 },
      { from: 'n3', to: 'n4', order: 1 },
      { from: 'n2', to: 'b1', order: 1 },
    ],
  },
  {
    id: 'name-2',
    level: 2,
    tingkat: 'Mudah',
    golongan: 'alkana',
    jawabanResmi: '2-metilpentana',
    rantaiIndukBenar: 'pentana',
    arahPenomoran: 'Dari kanan ke kiri (cabang metil lebih dekat ke ujung kanan)',
    wrongDirectionTrap: '4-metilpentana',
    petunjuk:
      'Hitung rantai terpanjang (5 atom C = pentana). Hati-hati, cabang —CH₃ lebih dekat ke ujung kanan!',
    pembahasan:
      '• Rantai terpanjang = 5 atom C (pentana).\n• Penomoran dari ujung kanan: C1 di kanan, maka cabang berada di C-2 (jika dari kiri berada di C-4).\n• Nama IUPAC yang benar: 2-metilpentana.',
    tokenBank: {
      angka: ['1', '2', '3', '4', '5'],
      cabang: ['metil', 'etil', 'dimetil'],
      induk: ['butana', 'pentana', 'heksana'],
    },
    nodes: [
      { id: 'n5', row: 1, col: 0, formula: 'CH3', chainNum: 5, isMainChain: true },
      { id: 'n4', row: 1, col: 1, formula: 'CH2', chainNum: 4, isMainChain: true },
      { id: 'n3', row: 1, col: 2, formula: 'CH2', chainNum: 3, isMainChain: true },
      { id: 'n2', row: 1, col: 3, formula: 'CH', chainNum: 2, isMainChain: true },
      { id: 'n1', row: 1, col: 4, formula: 'CH3', chainNum: 1, isMainChain: true },
      { id: 'b1', row: 2, col: 3, formula: 'CH3', isMainChain: false },
    ],
    bonds: [
      { from: 'n5', to: 'n4', order: 1 },
      { from: 'n4', to: 'n3', order: 1 },
      { from: 'n3', to: 'n2', order: 1 },
      { from: 'n2', to: 'n1', order: 1 },
      { from: 'n2', to: 'b1', order: 1 },
    ],
  },
  {
    id: 'name-3',
    level: 3,
    tingkat: 'Mudah',
    golongan: 'alkena',
    jawabanResmi: '3-metil-1-butena',
    rantaiIndukBenar: 'butena',
    arahPenomoran: 'Dari kanan ke kiri (ikatan rangkap = di ujung kanan)',
    wrongDirectionTrap: '2-metil-3-butena',
    petunjuk:
      'Pada alkena, penomoran WAJIB dimulai dari ujung terdekat ikatan rangkap dua (=), yaitu ujung kanan.',
    pembahasan:
      '• Rantai terpanjang mengandung ikatan rangkap = 4 atom C (butena).\n• Penomoran dari ujung kanan menempatkan ikatan rangkap pada C-1 (1-butena) dan cabang metil pada C-3.\n• Nama resmi IUPAC: 3-metil-1-butena.',
    tokenBank: {
      angka: ['1', '2', '3', '4'],
      cabang: ['metil', 'etil', 'dimetil'],
      induk: ['propena', 'butena', 'pentena'],
    },
    nodes: [
      { id: 'n4', row: 1, col: 0, formula: 'CH3', chainNum: 4, isMainChain: true },
      { id: 'n3', row: 1, col: 1, formula: 'CH', chainNum: 3, isMainChain: true },
      { id: 'n2', row: 1, col: 2, formula: 'CH', chainNum: 2, isMainChain: true },
      { id: 'n1', row: 1, col: 3, formula: 'CH2', chainNum: 1, isMainChain: true },
      { id: 'b1', row: 2, col: 1, formula: 'CH3', isMainChain: false },
    ],
    bonds: [
      { from: 'n4', to: 'n3', order: 1 },
      { from: 'n3', to: 'n2', order: 1 },
      { from: 'n2', to: 'n1', order: 2 },
      { from: 'n3', to: 'b1', order: 1 },
    ],
  },
  {
    id: 'name-4',
    level: 4,
    tingkat: 'Sedang',
    golongan: 'alkana',
    jawabanResmi: '2,3-dimetilpentana',
    rantaiIndukBenar: 'pentana',
    arahPenomoran: 'Dari kanan ke kiri (himpunan nomor cabang {2, 3} lebih kecil dari {3, 4})',
    wrongDirectionTrap: '3,4-dimetilpentana',
    missingMultiplierTrap: '2,3-metilpentana',
    petunjuk:
      'Ada dua cabang metil sejenis (gunakan awalan di-). Bandingkan penomoran dari kiri vs dari kanan untuk mendapat nomor terkecil.',
    pembahasan:
      '• Rantai induk = 5 atom C (pentana).\n• Penomoran dari kanan menghasilkan nomor cabang 2 dan 3 (sedangkan dari kiri 3 dan 4).\n• Dua gugus metil digabung menjadi "2,3-dimetil".\n• Nama lengkap: 2,3-dimetilpentana.',
    tokenBank: {
      angka: ['1', '2', '3', '4', '5'],
      cabang: ['metil', 'dimetil', 'trimetil', 'etil'],
      induk: ['butana', 'pentana', 'heksana'],
    },
    nodes: [
      { id: 'n5', row: 1, col: 0, formula: 'CH3', chainNum: 5, isMainChain: true },
      { id: 'n4', row: 1, col: 1, formula: 'CH2', chainNum: 4, isMainChain: true },
      { id: 'n3', row: 1, col: 2, formula: 'CH', chainNum: 3, isMainChain: true },
      { id: 'n2', row: 1, col: 3, formula: 'CH', chainNum: 2, isMainChain: true },
      { id: 'n1', row: 1, col: 4, formula: 'CH3', chainNum: 1, isMainChain: true },
      { id: 'b1', row: 2, col: 2, formula: 'CH3', isMainChain: false },
      { id: 'b2', row: 0, col: 3, formula: 'CH3', isMainChain: false },
    ],
    bonds: [
      { from: 'n5', to: 'n4', order: 1 },
      { from: 'n4', to: 'n3', order: 1 },
      { from: 'n3', to: 'n2', order: 1 },
      { from: 'n2', to: 'n1', order: 1 },
      { from: 'n3', to: 'b1', order: 1 },
      { from: 'n2', to: 'b2', order: 1 },
    ],
  },
  {
    id: 'name-5',
    level: 5,
    tingkat: 'Sedang',
    golongan: 'alkana',
    jawabanResmi: '3-etil-2-metilpentana',
    rantaiIndukBenar: 'pentana',
    arahPenomoran: 'Dari kiri ke kanan (cabang di nomor 2 dan 3)',
    wrongDirectionTrap: '3-etil-4-metilpentana',
    wrongAlphabetTrap: '2-metil-3-etilpentana',
    petunjuk:
      'Terdapat cabang metil (1 C) dan cabang etil (2 C). Ingat aturan urutan alfabetis saat menuliskan nama cabang berbeda!',
    pembahasan:
      '• Rantai terpanjang = 5 atom C (pentana).\n• Penomoran dari kiri memberikan cabang di C-2 (metil) dan C-3 (etil).\n• Sesuai aturan abjad IUPAC, "etil" (huruf e) ditulis sebelum "metil" (huruf m).\n• Nama lengkap: 3-etil-2-metilpentana.',
    tokenBank: {
      angka: ['1', '2', '3', '4', '5'],
      cabang: ['metil', 'etil', 'dimetil'],
      induk: ['butana', 'pentana', 'heksana'],
    },
    nodes: [
      { id: 'n1', row: 1, col: 0, formula: 'CH3', chainNum: 1, isMainChain: true },
      { id: 'n2', row: 1, col: 1, formula: 'CH', chainNum: 2, isMainChain: true },
      { id: 'n3', row: 1, col: 2, formula: 'CH', chainNum: 3, isMainChain: true },
      { id: 'n4', row: 1, col: 3, formula: 'CH2', chainNum: 4, isMainChain: true },
      { id: 'n5', row: 1, col: 4, formula: 'CH3', chainNum: 5, isMainChain: true },
      { id: 'b1', row: 0, col: 1, formula: 'CH3', isMainChain: false },
      { id: 'e1', row: 2, col: 2, formula: 'CH2', isMainChain: false },
      { id: 'e2', row: 3, col: 2, formula: 'CH3', isMainChain: false },
    ],
    bonds: [
      { from: 'n1', to: 'n2', order: 1 },
      { from: 'n2', to: 'n3', order: 1 },
      { from: 'n3', to: 'n4', order: 1 },
      { from: 'n4', to: 'n5', order: 1 },
      { from: 'n2', to: 'b1', order: 1 },
      { from: 'n3', to: 'e1', order: 1 },
      { from: 'e1', to: 'e2', order: 1 },
    ],
  },
  {
    id: 'name-6',
    level: 6,
    tingkat: 'Sedang',
    golongan: 'alkena',
    jawabanResmi: '2,4-dimetil-2-pentena',
    rantaiIndukBenar: 'pentena',
    arahPenomoran: 'Dari kiri ke kanan (ikatan rangkap = di nomor 2)',
    wrongDirectionTrap: '2,4-dimetil-3-pentena',
    missingMultiplierTrap: '2,4-metil-2-pentena',
    petunjuk:
      'Cari rantai induk alkena (5 atom C = pentena). Mulai penomoran dari ujung paling dekat dengan ikatan rangkap dua (=).',
    pembahasan:
      '• Rantai terpanjang mengandung ikatan rangkap = 5 atom C (pentena).\n• Penomoran dari kiri menempatkan ikatan rangkap di C-2 (jika dari kanan di C-3).\n• Cabang metil berada di C-2 dan C-4 → 2,4-dimetil.\n• Nama resmi: 2,4-dimetil-2-pentena.',
    tokenBank: {
      angka: ['1', '2', '3', '4', '5'],
      cabang: ['metil', 'dimetil', 'etil'],
      induk: ['butena', 'pentena', 'heksena'],
    },
    nodes: [
      { id: 'n1', row: 1, col: 0, formula: 'CH3', chainNum: 1, isMainChain: true },
      { id: 'n2', row: 1, col: 1, formula: 'C', chainNum: 2, isMainChain: true },
      { id: 'n3', row: 1, col: 2, formula: 'CH', chainNum: 3, isMainChain: true },
      { id: 'n4', row: 1, col: 3, formula: 'CH', chainNum: 4, isMainChain: true },
      { id: 'n5', row: 1, col: 4, formula: 'CH3', chainNum: 5, isMainChain: true },
      { id: 'b1', row: 0, col: 1, formula: 'CH3', isMainChain: false },
      { id: 'b2', row: 2, col: 3, formula: 'CH3', isMainChain: false },
    ],
    bonds: [
      { from: 'n1', to: 'n2', order: 1 },
      { from: 'n2', to: 'n3', order: 2 },
      { from: 'n3', to: 'n4', order: 1 },
      { from: 'n4', to: 'n5', order: 1 },
      { from: 'n2', to: 'b1', order: 1 },
      { from: 'n4', to: 'b2', order: 1 },
    ],
  },
  {
    id: 'name-7',
    level: 7,
    tingkat: 'Sedang',
    golongan: 'alkuna',
    jawabanResmi: '3-metil-1-butuna',
    rantaiIndukBenar: 'butuna',
    arahPenomoran: 'Dari kanan ke kiri (ikatan rangkap ≡ di ujung kanan)',
    wrongDirectionTrap: '2-metil-3-butuna',
    petunjuk:
      'Ikatan rangkap tiga (≡) berada di ujung kanan. Jangan terkecoh oleh cabang metil di sebelah kiri!',
    pembahasan:
      '• Golongan alkuna dengan 4 atom C pada rantai induk → butuna.\n• Penomoran wajib dari ujung kanan karena terdekat dengan ikatan rangkap tiga (C-1).\n• Cabang metil berada di C-3 → 3-metil-1-butuna.',
    tokenBank: {
      angka: ['1', '2', '3', '4'],
      cabang: ['metil', 'etil', 'dimetil'],
      induk: ['propuna', 'butuna', 'pentuna'],
    },
    nodes: [
      { id: 'n4', row: 1, col: 0, formula: 'CH3', chainNum: 4, isMainChain: true },
      { id: 'n3', row: 1, col: 1, formula: 'CH', chainNum: 3, isMainChain: true },
      { id: 'n2', row: 1, col: 2, formula: 'C', chainNum: 2, isMainChain: true },
      { id: 'n1', row: 1, col: 3, formula: 'CH', chainNum: 1, isMainChain: true },
      { id: 'b1', row: 2, col: 1, formula: 'CH3', isMainChain: false },
    ],
    bonds: [
      { from: 'n4', to: 'n3', order: 1 },
      { from: 'n3', to: 'n2', order: 1 },
      { from: 'n2', to: 'n1', order: 3 },
      { from: 'n3', to: 'b1', order: 1 },
    ],
  },
  {
    id: 'name-8',
    level: 8,
    tingkat: 'Tantangan',
    golongan: 'alkana',
    jawabanResmi: '3-metilheksana',
    rantaiIndukBenar: 'heksana',
    arahPenomoran: 'Dari kiri berbelok ke bawah (rantai terpanjang berbelok = 6 atom C)',
    wrongDirectionTrap: '4-metilheksana',
    petunjuk:
      'Waspada! Rantai induk terpanjang TIDAK harus lurus mendatar. Telusuri rantai yang berbelok ke bawah untuk menemukan 6 atom C berurutan!',
    pembahasan:
      '• Jika hanya melihat garis mendatar (4 atom C), hasilnya keliru sebagai butana/pentana.\n• Rantai terpanjang sebenarnya berbelok ke bawah: CH₃(1)—CH₂(2)—CH(3)—CH₂(4)—CH₂(5)—CH₃(6) = 6 atom C (heksana).\n• Gugus —CH₃ di sebelah kanan CH-3 menjadi cabang metil pada C-3 → 3-metilheksana.',
    tokenBank: {
      angka: ['1', '2', '3', '4', '5', '6'],
      cabang: ['metil', 'etil', 'propil'],
      induk: ['butana', 'pentana', 'heksana'],
    },
    nodes: [
      { id: 'n1', row: 0, col: 0, formula: 'CH3', chainNum: 1, isMainChain: true },
      { id: 'n2', row: 0, col: 1, formula: 'CH2', chainNum: 2, isMainChain: true },
      { id: 'n3', row: 0, col: 2, formula: 'CH', chainNum: 3, isMainChain: true },
      { id: 'b1', row: 0, col: 3, formula: 'CH3', isMainChain: false },
      { id: 'n4', row: 1, col: 2, formula: 'CH2', chainNum: 4, isMainChain: true },
      { id: 'n5', row: 2, col: 2, formula: 'CH2', chainNum: 5, isMainChain: true },
      { id: 'n6', row: 3, col: 2, formula: 'CH3', chainNum: 6, isMainChain: true },
    ],
    bonds: [
      { from: 'n1', to: 'n2', order: 1 },
      { from: 'n2', to: 'n3', order: 1 },
      { from: 'n3', to: 'b1', order: 1 },
      { from: 'n3', to: 'n4', order: 1 },
      { from: 'n4', to: 'n5', order: 1 },
      { from: 'n5', to: 'n6', order: 1 },
    ],
  },
  {
    id: 'name-9',
    level: 9,
    tingkat: 'Tantangan',
    golongan: 'alkena',
    jawabanResmi: '4-metil-2-heksena',
    rantaiIndukBenar: 'heksena',
    arahPenomoran: 'Dari kiri ke kanan (ikatan rangkap = di nomor 2)',
    wrongDirectionTrap: '3-metil-4-heksena',
    petunjuk:
      'Rantai induk memiliki 6 atom C (heksena). Tentukan arah penomoran dari ujung paling dekat dengan ikatan rangkap dua (=).',
    pembahasan:
      '• Rantai induk terpanjang mengandung ikatan rangkap = 6 atom C (heksena).\n• Penomoran dari kiri menempatkan ikatan rangkap di C-2 (jika dari kanan di C-4).\n• Cabang metil terikat di C-4 → 4-metil-2-heksena.',
    tokenBank: {
      angka: ['1', '2', '3', '4', '5', '6'],
      cabang: ['metil', 'etil', 'dimetil'],
      induk: ['pentena', 'heksena', 'heptena'],
    },
    nodes: [
      { id: 'n1', row: 1, col: 0, formula: 'CH3', chainNum: 1, isMainChain: true },
      { id: 'n2', row: 1, col: 1, formula: 'CH', chainNum: 2, isMainChain: true },
      { id: 'n3', row: 1, col: 2, formula: 'CH', chainNum: 3, isMainChain: true },
      { id: 'n4', row: 1, col: 3, formula: 'CH', chainNum: 4, isMainChain: true },
      { id: 'n5', row: 1, col: 4, formula: 'CH2', chainNum: 5, isMainChain: true },
      { id: 'n6', row: 1, col: 5, formula: 'CH3', chainNum: 6, isMainChain: true },
      { id: 'b1', row: 2, col: 3, formula: 'CH3', isMainChain: false },
    ],
    bonds: [
      { from: 'n1', to: 'n2', order: 1 },
      { from: 'n2', to: 'n3', order: 2 },
      { from: 'n3', to: 'n4', order: 1 },
      { from: 'n4', to: 'n5', order: 1 },
      { from: 'n5', to: 'n6', order: 1 },
      { from: 'n4', to: 'b1', order: 1 },
    ],
  },
  {
    id: 'name-10',
    level: 10,
    tingkat: 'Tantangan',
    golongan: 'alkana',
    jawabanResmi: '4-etil-2,3-dimetilheksana',
    rantaiIndukBenar: 'heksana',
    arahPenomoran: 'Dari kiri ke kanan (himpunan nomor cabang {2, 3, 4} lebih kecil dari {3, 4, 5})',
    wrongDirectionTrap: '3-etil-4,5-dimetilheksana',
    wrongAlphabetTrap: '2,3-dimetil-4-etilheksana',
    missingMultiplierTrap: '4-etil-2,3-metilheksana',
    petunjuk:
      'Rantai induk = 6 atom C (heksana). Nomorilah dari kiri agar nomor cabang terkecil ({2, 3, 4}), gabungkan 2 metil menjadi dimetil, dan urutkan secara alfabetis (etil sebelum metil, awalan di- diabaikan saat mengurutkan abjad).',
    pembahasan:
      '• Rantai terpanjang = 6 atom C (heksana).\n• Penomoran dari kiri menghasilkan posisi cabang 2, 3, dan 4 (dari kanan 3, 4, dan 5).\n• Cabang di C-2 dan C-3 berupa metil → 2,3-dimetil; cabang di C-4 berupa etil → 4-etil.\n• Urutan abjad berdasarkan nama gugus dasar ("etil" sebelum "metil", awalan "di-" tidak memengaruhi abjad).\n• Nama IUPAC lengkap: 4-etil-2,3-dimetilheksana.',
    tokenBank: {
      angka: ['1', '2', '3', '4', '5', '6'],
      cabang: ['metil', 'dimetil', 'etil'],
      induk: ['pentana', 'heksana', 'heptana'],
    },
    nodes: [
      { id: 'n1', row: 1, col: 0, formula: 'CH3', chainNum: 1, isMainChain: true },
      { id: 'n2', row: 1, col: 1, formula: 'CH', chainNum: 2, isMainChain: true },
      { id: 'n3', row: 1, col: 2, formula: 'CH', chainNum: 3, isMainChain: true },
      { id: 'n4', row: 1, col: 3, formula: 'CH', chainNum: 4, isMainChain: true },
      { id: 'n5', row: 1, col: 4, formula: 'CH2', chainNum: 5, isMainChain: true },
      { id: 'n6', row: 1, col: 5, formula: 'CH3', chainNum: 6, isMainChain: true },
      { id: 'm1', row: 0, col: 1, formula: 'CH3', isMainChain: false },
      { id: 'm2', row: 2, col: 2, formula: 'CH3', isMainChain: false },
      { id: 'e1', row: 2, col: 3, formula: 'CH2', isMainChain: false },
      { id: 'e2', row: 3, col: 3, formula: 'CH3', isMainChain: false },
    ],
    bonds: [
      { from: 'n1', to: 'n2', order: 1 },
      { from: 'n2', to: 'n3', order: 1 },
      { from: 'n3', to: 'n4', order: 1 },
      { from: 'n4', to: 'n5', order: 1 },
      { from: 'n5', to: 'n6', order: 1 },
      { from: 'n2', to: 'm1', order: 1 },
      { from: 'n3', to: 'm2', order: 1 },
      { from: 'n4', to: 'e1', order: 1 },
      { from: 'e1', to: 'e2', order: 1 },
    ],
  },
];
