/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Halaman Beranda "Jelajahi Dunia Hidrokarbon"
 * Susunan awal yang dipercantik dengan nuansa galaksi & interaksi halus:
 * 1. Hero Kosmis & Visualisasi Orbit Molekul
 * 2. Yang Akan Kamu Pelajari (3 Kartu Topik Utama)
 * 3. Peta Konsep Interaktif
 * 4. Deret Homolog Interaktif (C₁–C₁₀)
 * 5. Tujuan Pembelajaran Siswa (KD 3.1 & KD 4.1)
 * 6. Cara Belajar 3 Langkah
 */

import React from 'react';
import {
  YANG_DIPELAJARI,
  TUJUAN_BELAJAR,
  CARA_BELAJAR,
} from '../../data';
import { MoleculeOrbit } from '../MoleculeOrbit';
import { DeretHomolog } from '../DeretHomolog';
import { PetaKonsep } from '../PetaKonsep';
import {
  ArrowRight,
  BookOpen,
  Compass,
  Sparkles,
  Atom,
  Target,
} from 'lucide-react';
import { NavTab } from '../Navbar';

interface BerandaPageProps {
  onNavigateTab: (tab: NavTab) => void;
  onSelectSubBab: (subBabId: string) => void;
  onOpenMateri?: (
    kegiatan: 'kegiatan-1' | 'kegiatan-2' | 'kegiatan-3',
    subBabId?: string
  ) => void;
  onOpenStructureBuilder?: (challengeId?: string) => void;
}

export const BerandaPage: React.FC<BerandaPageProps> = ({
  onNavigateTab,
  onSelectSubBab,
  onOpenMateri,
}) => {
  const handleOpenKegiatan = (index: number) => {
    const kegMap: ('kegiatan-1' | 'kegiatan-2' | 'kegiatan-3')[] = [
      'kegiatan-1',
      'kegiatan-2',
      'kegiatan-3',
    ];
    const target = kegMap[index] || 'kegiatan-1';
    if (onOpenMateri) {
      onOpenMateri(target);
    } else {
      onNavigateTab('materi');
    }
  };

  return (
    <div className="w-full overflow-hidden">
      {/* 1. HERO SECTION */}
      <section className="relative w-full pt-10 pb-14 sm:pt-14 sm:pb-20 px-4 sm:px-6 max-w-6xl mx-auto">
        {/* Ambient cosmic nebula glow & twinkling starfield */}
        <div className="absolute -top-10 left-1/4 w-72 h-72 rounded-full bg-[#B4A7FF]/10 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/6 w-80 h-80 rounded-full bg-[#5EEAD4]/8 blur-3xl pointer-events-none" />
        <div className="absolute top-12 left-8 w-1 h-1 rounded-full bg-[#FDE68A] animate-star-1 pointer-events-none" />
        <div className="absolute top-28 right-12 w-1.5 h-1.5 rounded-full bg-[#B4A7FF] animate-star-2 pointer-events-none" />
        <div className="absolute bottom-16 left-1/4 w-1 h-1 rounded-full bg-[#5EEAD4] animate-star-3 pointer-events-none" />
        <div className="absolute top-1/2 left-4 w-1 h-1 rounded-full bg-[#FFA8C5] animate-star-2 pointer-events-none" />
        <div className="absolute bottom-24 right-1/3 w-1 h-1 rounded-full bg-[#FDE68A] animate-star-1 pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center relative z-10">
          {/* Hero Text Column */}
          <div className="lg:col-span-7 text-center lg:text-left space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-[#1E1850]/90 border border-[#3A3280] rounded-full text-xs font-semibold text-[#5EEAD4] shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-[#FDE68A]" />
              <span>Kimia SMA/MA Kelas XI · Kurikulum Nasional (KD 3.1 & KD 4.1)</span>
            </div>

            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[3.25rem] font-extrabold tracking-tight text-[#EEEDFB] leading-[1.12] text-balance">
              Jelajahi Dunia{' '}
              <span className="bg-gradient-to-r from-[#5EEAD4] via-[#B4A7FF] to-[#FFA8C5] bg-clip-text text-transparent">
                Hidrokarbon
              </span>
            </h1>

            <p className="text-sm sm:text-base md:text-lg text-[#B8B5DE] max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Media pembelajaran interaktif bertema galaksi untuk memahami kekhasan atom karbon, penggolongan alkana–alkena–alkuna, tata nama IUPAC, reaksi kimia, dan isomer secara runtut.
            </p>

            {/* Quick Highlight Specs */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-x-5 gap-y-2 text-xs text-[#B8B5DE] font-mono">
              <span className="inline-flex items-center gap-1.5">
                <span className="text-[#5EEAD4] font-bold">―</span>
                <span>Alkana</span>
              </span>
              <span className="text-[#3A3280]" aria-hidden="true">•</span>
              <span className="inline-flex items-center gap-1.5">
                <span className="text-[#B4A7FF] font-bold">=</span>
                <span>Alkena</span>
              </span>
              <span className="text-[#3A3280]" aria-hidden="true">•</span>
              <span className="inline-flex items-center gap-1.5">
                <span className="text-[#FFA8C5] font-bold">≡</span>
                <span>Alkuna</span>
              </span>
              <span className="text-[#3A3280]" aria-hidden="true">•</span>
              <span className="inline-flex items-center gap-1.5 text-[#FDE68A]">
                <Atom className="w-3.5 h-3.5" />
                <span>4 Valensi C</span>
              </span>
            </div>

            {/* Hero CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-1">
              <button
                onClick={() => handleOpenKegiatan(0)}
                className="w-full sm:w-auto px-6 py-3.5 bg-gradient-to-r from-[#B4A7FF] to-[#8F80FF] text-[#0F0B2A] rounded-xl font-bold text-sm sm:text-base hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#A99CFF]/20 cursor-pointer min-h-[48px] whitespace-nowrap"
              >
                <BookOpen className="w-4 h-4" />
                <span>Mulai Belajar Materi</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  const el = document.getElementById('deret-homolog');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full sm:w-auto px-6 py-3.5 bg-[#1E1850]/85 border border-[#3A3280] hover:border-[#5EEAD4] text-[#EEEDFB] hover:text-[#5EEAD4] rounded-xl font-semibold text-sm sm:text-base active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer min-h-[48px] whitespace-nowrap"
              >
                <Compass className="w-4 h-4 text-[#5EEAD4]" />
                <span>Eksplor Deret Homolog</span>
              </button>
            </div>
          </div>

          {/* Hero Visual Column: SVG Molecule Animation with Celestial Halo */}
          <div className="lg:col-span-5 flex justify-center relative">
            <div className="relative w-full max-w-md flex flex-col items-center justify-center py-4">
              {/* Outer subtle orbital ring */}
              <div className="absolute inset-6 rounded-full border border-dashed border-[#3A3280]/50 pointer-events-none" />
              <MoleculeOrbit />
            </div>
          </div>
        </div>
      </section>

      {/* 2. BAGIAN "YANG AKAN KAMU PELAJARI" */}
      <section
        id="yang-dipelajari"
        className="w-full py-12 px-4 sm:px-6 max-w-5xl mx-auto scroll-mt-20"
      >
        <div className="text-center mb-10">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#A99CFF]">
            Ringkasan Topik Utama
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-[#EEEDFB] mt-1.5">
            Yang Akan Kamu Pelajari
          </h2>
          <p className="mt-2.5 text-sm sm:text-base text-[#B8B5DE] max-w-xl mx-auto leading-relaxed">
            Tiga topik inti senyawa hidrokarbon yang tersusun runtut dari struktur dasar hingga sifat dan reaksinya.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {YANG_DIPELAJARI.map((item, idx) => (
            <div
              key={item.nomor}
              onClick={() => handleOpenKegiatan(idx)}
              className="relative overflow-hidden bg-[#1E1850] border border-[#3A3280] rounded-2xl p-6 sm:p-7 shadow-lg hover:border-[#8E8BB5]/80 hover:-translate-y-1 transition-all duration-200 flex flex-col justify-between group cursor-pointer"
            >
              {/* Top subtle gradient accent */}
              <div
                className="absolute top-0 inset-x-0 h-[2px] opacity-80 group-hover:opacity-100 transition-opacity"
                style={{
                  background: `linear-gradient(90deg, transparent, ${item.warnaAksen}, transparent)`,
                }}
              />

              <div>
                <div className="flex items-center justify-between mb-5">
                  <span
                    className="w-11 h-11 rounded-xl flex items-center justify-center font-mono font-extrabold text-sm shadow-inner"
                    style={{
                      backgroundColor: `${item.warnaAksen}18`,
                      color: item.warnaAksen,
                      border: `1px solid ${item.warnaAksen}50`,
                    }}
                  >
                    {item.nomor}
                  </span>
                  <span
                    className="w-9 h-9 rounded-full bg-[#0F0B2A]/80 border border-[#3A3280] flex items-center justify-center text-base font-mono font-bold"
                    style={{ color: item.warnaAksen }}
                  >
                    {item.simbol}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-[#EEEDFB] group-hover:text-[#5EEAD4] transition-colors leading-snug">
                  {item.judul}
                </h3>

                <p className="mt-3 text-sm text-[#B8B5DE] leading-relaxed">
                  {item.deskripsi}
                </p>
              </div>

              <div className="pt-5 mt-5 border-t border-[#3A3280]/60 flex items-center justify-between">
                <span className="text-xs text-[#8E8BB5] font-medium">
                  Kegiatan {idx + 1}
                </span>
                <span
                  className="text-xs font-semibold inline-flex items-center gap-1 group-hover:gap-1.5 transition-all"
                  style={{ color: item.warnaAksen }}
                >
                  <span>Buka Materi</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. PETA KONSEP INTERAKTIF */}
      <PetaKonsep onSelectSubBab={(subId) => onSelectSubBab(subId)} />

      {/* 4. BAGIAN "DERET HOMOLOG: DARI SEDERHANA SAMPAI DEKANA" */}
      <DeretHomolog
        onGoToMateri={() =>
          onOpenMateri ? onOpenMateri('kegiatan-2', '2.2') : onNavigateTab('materi')
        }
      />

      {/* 5. TUJUAN BELAJAR (KD 3.1 & KD 4.1) */}
      <section
        id="tujuan-belajar"
        className="w-full py-12 px-4 sm:px-6 max-w-5xl mx-auto"
      >
        <div className="relative overflow-hidden bg-[#1E1850] border border-[#3A3280] rounded-2xl p-6 sm:p-8 shadow-xl">
          <div
            className="absolute top-0 inset-x-0 h-[2px]"
            style={{
              background:
                'linear-gradient(90deg, transparent, #5EEAD4, #B4A7FF, transparent)',
            }}
          />

          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-6 border-b border-[#3A3280]">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#0F0B2A] border border-[#3A3280] flex items-center justify-center text-[#5EEAD4] shrink-0 mt-0.5">
                <Target className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-[#5EEAD4]">
                  Kompetensi Dasar (KD)
                </span>
                <h2 className="text-xl sm:text-2xl font-bold text-[#EEEDFB] mt-0.5">
                  Tujuan Pembelajaran Siswa
                </h2>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-[#B8B5DE] max-w-md leading-relaxed">
              Target capaian pembelajaran Kimia SMA/MA Kelas XI sesuai standar kurikulum nasional.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {TUJUAN_BELAJAR.map((tujuan) => (
              <div
                key={tujuan.kode}
                className="p-5 bg-[#0F0B2A]/80 border border-[#3A3280] hover:border-[#8E8BB5]/50 transition-colors rounded-xl flex items-start gap-4"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center font-bold text-xs font-mono shrink-0"
                  style={{
                    backgroundColor: `${tujuan.warnaAksen}20`,
                    color: tujuan.warnaAksen,
                    border: `1px solid ${tujuan.warnaAksen}50`,
                  }}
                >
                  {tujuan.kode}
                </div>
                <div className="space-y-1">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#EEEDFB]">
                    {tujuan.jenis}
                  </span>
                  <p className="text-sm text-[#B8B5DE] leading-relaxed">
                    {tujuan.uraian}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. CARA BELAJAR 3 LANGKAH */}
      <section
        id="cara-belajar"
        className="w-full py-12 px-4 sm:px-6 max-w-5xl mx-auto"
      >
        <div className="text-center mb-10">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#A99CFF]">
            Alur Pembelajaran Mandiri
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#EEEDFB] mt-1.5">
            Cara Belajar 3 Langkah
          </h2>
          <p className="mt-2.5 text-sm sm:text-base text-[#B8B5DE] max-w-lg mx-auto leading-relaxed">
            Ikuti tiga langkah sederhana ini untuk menguasai materi hidrokarbon secara runtut.
          </p>
        </div>

        <div className="relative grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Connecting constellation dashed track on desktop */}
          <div
            aria-hidden="true"
            className="hidden md:block absolute top-11 left-[16%] right-[16%] h-px border-t border-dashed border-[#3A3280] z-0"
          />

          {CARA_BELAJAR.map((item) => {
            const stepColor =
              item.langkah === 1
                ? '#5EEAD4'
                : item.langkah === 2
                ? '#B4A7FF'
                : '#FFA8C5';

            return (
              <div
                key={item.langkah}
                className="relative z-10 bg-[#1E1850] border border-[#3A3280] rounded-2xl p-6 flex flex-col justify-between shadow-lg hover:border-[#8E8BB5]/60 transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span
                      className="text-xs font-bold uppercase tracking-wider"
                      style={{ color: stepColor }}
                    >
                      Langkah 0{item.langkah}
                    </span>
                    <div
                      className="w-9 h-9 rounded-full bg-[#150F38] flex items-center justify-center text-xs font-mono font-extrabold tabular-nums shadow-inner"
                      style={{
                        color: stepColor,
                        border: `1.5px solid ${stepColor}70`,
                      }}
                    >
                      {item.langkah}
                    </div>
                  </div>

                  <h3 className="text-lg font-bold text-[#EEEDFB]">{item.nama}</h3>

                  <p className="mt-2 text-sm text-[#B8B5DE] leading-relaxed">
                    {item.deskripsi}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#3A3280]/60">
                  {item.langkah === 1 && (
                    <button
                      onClick={() => handleOpenKegiatan(0)}
                      className="text-xs font-semibold text-[#5EEAD4] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <span>Mulai Membaca Materi</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {item.langkah === 2 && (
                    <button
                      onClick={() => {
                        const el = document.getElementById('deret-homolog');
                        el?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="text-xs font-semibold text-[#B4A7FF] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <span>Eksplorasi Deret Homolog</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {item.langkah === 3 && (
                    <button
                      onClick={() => onNavigateTab('latihan-soal')}
                      className="text-xs font-semibold text-[#FFA8C5] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <span>Mulai Latihan Soal</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
