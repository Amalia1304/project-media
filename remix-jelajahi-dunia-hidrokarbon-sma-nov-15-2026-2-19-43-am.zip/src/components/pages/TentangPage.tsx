/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Halaman Tentang "Jelajahi Dunia Hidrokarbon"
 * Menyajikan profil platform, latar belakang pengembangan, landasan pedagogis,
 * standar kurikulum, FAQ platform, pengelolaan data lokal, dan atribusi pengembang.
 */

import React, { useState } from 'react';
import {
  Atom,
  ArrowLeft,
  ChevronDown,
  RotateCcw,
  CheckCircle2,
} from 'lucide-react';
import { NavTab } from '../Navbar';
import orbitalIllustration from '../../assets/images/about_hydrocarbon_orbital_1794673103827.jpg';

interface TentangPageProps {
  onBackToBeranda: () => void;
  onNavigateTab?: (tab: NavTab) => void;
  onOpenMateri?: (
    kegiatan: 'kegiatan-1' | 'kegiatan-2' | 'kegiatan-3',
    subBabId?: string
  ) => void;
  onOpenStructureBuilder?: (challengeId?: string) => void;
}

function countStoredRecords(): number {
  let count = 0;
  const keys = [
    'hidrokarbon_opened_subbabs',
    'hidrokarbon_solved_structures',
    'hidrokarbon_solved_naming',
    'hidrokarbon_latihan_history',
    'hidrokarbon_penilaian_diri',
  ];
  for (const key of keys) {
    try {
      const raw = localStorage.getItem(key);
      if (raw && raw !== '[]' && raw !== '{}') {
        count += 1;
      }
    } catch {
      // Ignore storage errors
    }
  }
  return count;
}

export const TentangPage: React.FC<TentangPageProps> = ({ onBackToBeranda }) => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [imageFailed, setImageFailed] = useState<boolean>(false);
  const [storedCount, setStoredCount] = useState<number>(() => countStoredRecords());
  const [confirmReset, setConfirmReset] = useState<boolean>(false);
  const [resetDoneNotice, setResetDoneNotice] = useState<boolean>(false);

  const handleResetLocalProgress = () => {
    try {
      localStorage.removeItem('hidrokarbon_opened_subbabs');
      localStorage.removeItem('hidrokarbon_solved_structures');
      localStorage.removeItem('hidrokarbon_solved_naming');
      localStorage.removeItem('hidrokarbon_latihan_history');
      localStorage.removeItem('hidrokarbon_penilaian_diri');
    } catch {
      // Ignore storage access errors
    }
    setStoredCount(countStoredRecords());
    setConfirmReset(false);
    setResetDoneNotice(true);
    setTimeout(() => setResetDoneNotice(false), 4000);
  };

  const platformSpecifications = [
    {
      kode: '01',
      aspek: 'Rujukan Kurikulum',
      ringkasan: 'Kimia SMA/MA Kelas XI · KD 3.1 & KD 4.1',
      uraian:
        'Materi mencakup kekhasan atom karbon, penggolongan hidrokarbon (alkana, alkena, alkuna), tata nama IUPAC, sifat fisis, mekanisme reaksi kimia, serta konsep isomerisme struktural dan geometri.',
    },
    {
      kode: '02',
      aspek: 'Pendekatan Visual',
      ringkasan: 'Analogi Orbit Kosmis & Simulasi Spasial',
      uraian:
        'Empat elektron valensi atom karbon divisualisasikan menyerupai pusat tata surya dengan atom hidrogen sebagai pengorbit. Pendekatan ini membantu siswa membayangkan ikatan kovalen tanpa bergantung pada hafalan semata.',
    },
    {
      kode: '03',
      aspek: 'Metodologi Belajar',
      ringkasan: 'Eksplorasi Aktif & Umpan Balik Langsung',
      uraian:
        'Setiap konsep disertai interaksi langsung—mulai dari penyusunan struktur molekul pada kanvas grid hingga pemeriksaan aturan valensi dan refleksi diri mandiri.',
    },
    {
      kode: '04',
      aspek: 'Akses & Privasi Data',
      ringkasan: '100% Lokal di Peramban · Tanpa Akun',
      uraian:
        'Tidak memerlukan pendaftaran, login, atau basis data server eksternal. Catatan progres belajar tersimpan secara privat di perangkat masing-masing pengguna dan dapat dihapus kapan saja.',
    },
  ];

  const faqItems = [
    {
      pertanyaan: 'Siapa yang mengembangkan media pembelajaran ini?',
      jawaban:
        'Platform Jelajahi Dunia Hidrokarbon dikembangkan oleh Tim Mahasiswa Pendidikan Kimia Universitas Negeri Malang sebagai media pendukung pembelajaran kimia organik dasar untuk jenjang SMA/MA Kelas XI.',
    },
    {
      pertanyaan: 'Apakah website ini dapat digunakan di sekolah maupun di rumah?',
      jawaban:
        'Ya. Antarmuka dirancang responsif untuk layar ponsel siswa, tablet, maupun komputer dan proyektor kelas sehingga dapat digunakan baik untuk pengajaran terbimbing maupun belajar mandiri.',
    },
    {
      pertanyaan: 'Mengapa tidak ada fitur login atau akun pengguna?',
      jawaban:
        'Kami sengaja menghilangkan hambatan registrasi agar siswa dapat langsung belajar dalam hitungan detik. Seluruh progres belajar disimpan secara lokal di peramban perangkat pengguna.',
    },
    {
      pertanyaan: 'Apakah materi di dalamnya mengikuti standar kurikulum sekolah?',
      jawaban:
        'Seluruh cakupan topik dan indikator evaluasi disusun selaras dengan Kompetensi Dasar (KD) 3.1 dan KD 4.1 Kimia SMA/MA Kelas XI mengenai senyawa hidrokarbon.',
    },
    {
      pertanyaan: 'Bagaimana jika ingin mengulang progres belajar dari awal?',
      jawaban:
        'Anda dapat menghapus seluruh riwayat belajar tersimpan melalui tombol Atur Ulang Data Lokal yang tersedia pada panel Informasi Pengembang di halaman ini.',
    },
  ];

  return (
    <div className="w-full py-8 sm:py-12 px-4 sm:px-6 max-w-5xl mx-auto">
      {/* Top Back Link */}
      <button
        onClick={onBackToBeranda}
        className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#B8B5DE] hover:text-[#5EEAD4] transition-colors mb-8 cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Kembali ke Beranda</span>
      </button>

      {/* 1. EDITORIAL ABOUT HEADER */}
      <header className="space-y-6 pb-10 sm:pb-12 border-b border-[#3A3280]/70">
        <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs font-medium text-[#5EEAD4]">
          <span>Tentang Platform</span>
          <span className="text-[#3A3280]" aria-hidden="true">·</span>
          <span className="text-[#B8B5DE]">Kimia SMA/MA Kelas XI</span>
          <span className="text-[#3A3280]" aria-hidden="true">·</span>
          <span className="text-[#B8B5DE]">Tim Mahasiswa Pendidikan Kimia Universitas Negeri Malang</span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-[2.65rem] font-extrabold tracking-tight text-[#EEEDFB] leading-[1.18] max-w-3xl text-balance">
          Menjadikan Struktur Hidrokarbon Lebih Nyata, Visual, dan Mudah Dipahami
        </h1>

        <p className="text-sm sm:text-base text-[#B8B5DE] leading-relaxed max-w-3xl">
          Jelajahi Dunia Hidrokarbon adalah media pembelajaran berbasis web yang dikembangkan untuk membantu siswa SMA/MA Kelas XI memahami konsep dasar kimia organik secara runtut—tanpa terbebani istilah abstrak yang sulit dibayangkan di atas kertas.
        </p>

        {/* Editorial Visual Figure */}
        <figure className="pt-2">
          <div className="relative rounded-2xl overflow-hidden border border-[#3A3280] bg-[#150F38] aspect-[16/9] sm:aspect-[21/9]">
            {!imageFailed ? (
              <img
                src={orbitalIllustration}
                alt="Ilustrasi ilmiah orbital molekul hidrokarbon tetrahedral dengan satu atom karbon pusat dan empat atom hidrogen"
                referrerPolicy="no-referrer"
                onError={() => setImageFailed(true)}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-[#150F38] via-[#1E1850] to-[#0F0B2A] flex items-center justify-center p-8">
                <div className="text-center space-y-2">
                  <Atom className="w-10 h-10 text-[#5EEAD4] mx-auto" />
                  <p className="text-xs font-mono text-[#B8B5DE]">
                    Visualisasi Orbital Karbon Tetrahedral (CH₄)
                  </p>
                </div>
              </div>
            )}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#0F0B2A]/80 via-transparent to-transparent"
            />
          </div>
          <figcaption className="mt-3 text-xs text-[#8E8BB5] leading-relaxed">
            Ilustrasi konseptual ikatan kovalen atom karbon bervalensi empat sebagai dasar metafora visual platform.
          </figcaption>
        </figure>
      </header>

      {/* 2. LATAR BELAKANG & VISI PENGEMBANGAN (Editorial 2-Column Prose) */}
      <section className="py-12 sm:py-14 border-b border-[#3A3280]/70 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-12">
        <div className="lg:col-span-4 space-y-2">
          <div className="text-xs font-semibold text-[#B4A7FF]">
            Latar Belakang
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-[#EEEDFB] leading-snug text-balance">
            Mengapa Media Ini Dibangun
          </h2>
        </div>

        <div className="lg:col-span-8 space-y-4 text-sm sm:text-base text-[#B8B5DE] leading-relaxed">
          <p>
            Materi senyawa hidrokarbon merupakan fondasi penting dalam kimia organik di tingkat SMA/MA. Namun, siswa sering kali mengalami kesulitan ketika harus membedakan kedudukan atom karbon primer hingga kuartener, menerapkan aturan penamaan IUPAC pada rantai bercabang, maupun membayangkan perbedaan struktur antar-isomer dari rumus molekul yang sama.
          </p>
          <p>
            Dikembangkan oleh <span className="text-[#EEEDFB] font-semibold">Tim Mahasiswa Pendidikan Kimia Universitas Negeri Malang</span>, platform ini hadir sebagai ruang belajar interaktif yang memadukan penjelasan ringkas, visualisasi orbit atom karbon, kanvas penyusunan struktur molekul, serta evaluasi mandiri dalam satu tempat yang ringan diakses dari perangkat apa pun.
          </p>
        </div>
      </section>

      {/* 3. LANDASAN DESAIN & STANDAR AKADEMIK (Clean Hairline Specification Rows) */}
      <section className="py-12 sm:py-14 border-b border-[#3A3280]/70">
        <div className="max-w-2xl mb-8 space-y-1.5">
          <div className="text-xs font-semibold text-[#5EEAD4]">
            Prinsip &amp; Standar
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-[#EEEDFB]">
            Landasan Pengembangan Platform
          </h2>
        </div>

        <div className="divide-y divide-[#3A3280]/60 border-t border-[#3A3280]/60">
          {platformSpecifications.map((spec) => (
            <div
              key={spec.kode}
              className="py-6 grid grid-cols-1 md:grid-cols-12 gap-3 md:gap-8 items-start"
            >
              <div className="md:col-span-4 flex items-baseline gap-3">
                <span className="font-mono text-xs font-bold tabular-nums text-[#5EEAD4]">
                  {spec.kode}.
                </span>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-[#EEEDFB]">
                    {spec.aspek}
                  </h3>
                  <div className="text-xs text-[#8E8BB5] mt-0.5">
                    {spec.ringkasan}
                  </div>
                </div>
              </div>
              <p className="md:col-span-8 text-sm text-[#B8B5DE] leading-relaxed">
                {spec.uraian}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* 4. PERTANYAAN UMUM & INFORMASI PENGEMBANG */}
      <section className="pt-12 sm:pt-14 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
        {/* FAQ Left Column */}
        <div className="lg:col-span-7 space-y-6">
          <div className="space-y-1.5">
            <div className="text-xs font-semibold text-[#B4A7FF]">
              Informasi Umum
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-[#EEEDFB]">
              Pertanyaan yang Sering Diajukan
            </h2>
          </div>

          <div className="divide-y divide-[#3A3280]/60 border-y border-[#3A3280]/60">
            {faqItems.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div key={faq.pertanyaan}>
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                    aria-expanded={isOpen}
                    className="w-full py-4 flex items-center justify-between gap-4 text-left cursor-pointer group"
                  >
                    <span className="text-sm sm:text-base font-semibold text-[#EEEDFB] group-hover:text-[#5EEAD4] transition-colors">
                      {faq.pertanyaan}
                    </span>
                    <ChevronDown
                      className={`w-4 h-4 text-[#B8B5DE] shrink-0 transition-transform duration-200 ${
                        isOpen ? 'rotate-180 text-[#5EEAD4]' : ''
                      }`}
                    />
                  </button>
                  {isOpen && (
                    <div className="pb-4 pr-6 text-sm text-[#B8B5DE] leading-relaxed">
                      {faq.jawaban}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Institutional Attribution & Local Data Management Right Column */}
        <div className="lg:col-span-5">
          <div className="bg-[#150F38] border border-[#3A3280] rounded-2xl p-6 sm:p-7 space-y-6">
            <div className="space-y-1">
              <div className="text-xs font-semibold text-[#FFA8C5]">
                Atribusi &amp; Tata Kelola
              </div>
              <h2 className="text-lg font-bold text-[#EEEDFB]">
                Informasi Pengembang
              </h2>
            </div>

            <dl className="divide-y divide-[#3A3280]/60 text-sm">
              <div className="py-3 flex flex-col gap-0.5">
                <dt className="text-xs text-[#8E8BB5]">Tim Penyusun</dt>
                <dd className="font-semibold text-[#EEEDFB]">
                  Tim Mahasiswa Pendidikan Kimia Universitas Negeri Malang
                </dd>
              </div>
              <div className="py-3 flex flex-col gap-0.5">
                <dt className="text-xs text-[#8E8BB5]">Sasaran Mata Pelajaran</dt>
                <dd className="font-semibold text-[#EEEDFB]">
                  Kimia SMA/MA Kelas XI
                </dd>
              </div>
              <div className="py-3 flex flex-col gap-0.5">
                <dt className="text-xs text-[#8E8BB5]">Acuan Kompetensi</dt>
                <dd className="font-semibold text-[#EEEDFB]">
                  KD 3.1 &amp; KD 4.1 Senyawa Hidrokarbon
                </dd>
              </div>
              <div className="py-3 flex flex-col gap-1">
                <dt className="text-xs text-[#8E8BB5]">Penyimpanan Peramban</dt>
                <dd className="text-xs text-[#B8B5DE] leading-relaxed">
                  {storedCount > 0 ? (
                    <span>
                      Terdapat <span className="font-mono font-semibold text-[#EEEDFB] tabular-nums">{storedCount}</span> kategori catatan belajar tersimpan secara lokal di perangkat ini.
                    </span>
                  ) : (
                    <span>
                      Belum ada catatan progres belajar tersimpan di peramban ini.
                    </span>
                  )}
                </dd>
              </div>
            </dl>

            {resetDoneNotice && (
              <div className="p-3 rounded-xl bg-[#0F0B2A] border border-[#5EEAD4]/50 flex items-center gap-2.5 text-xs text-[#5EEAD4]">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Data progres lokal berhasil dihapus.</span>
              </div>
            )}

            <div className="pt-1">
              {!confirmReset ? (
                <button
                  onClick={() => setConfirmReset(true)}
                  disabled={storedCount === 0}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#1E1850] hover:bg-[#251E60] disabled:opacity-50 disabled:cursor-not-allowed border border-[#3A3280] text-xs font-semibold text-[#EEEDFB] transition-colors inline-flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Atur Ulang Data Lokal</span>
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleResetLocalProgress}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-[#FFA8C5] text-[#0F0B2A] text-xs font-bold hover:brightness-105 transition-all cursor-pointer whitespace-nowrap"
                  >
                    Ya, Hapus Data
                  </button>
                  <button
                    onClick={() => setConfirmReset(false)}
                    className="py-2.5 px-3.5 rounded-xl bg-[#1E1850] border border-[#3A3280] text-xs font-semibold text-[#B8B5DE] hover:text-[#EEEDFB] transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Batal
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
