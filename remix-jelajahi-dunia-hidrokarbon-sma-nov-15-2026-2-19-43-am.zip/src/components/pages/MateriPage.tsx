/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Halaman Materi Lengkap: Kegiatan Pembelajaran 1, 2, & 3
 * Dilengkapi tab per kegiatan, sidebar sub-bab, dan progress bar interaktif.
 */

import React, { useState, useEffect } from 'react';
import {
  KEGIATAN_1_DATA,
  KEGIATAN_2_DATA,
  KEGIATAN_3_DATA
} from '../../data';
import { AtomCPosisiInteractive } from '../materi/AtomCPosisiInteractive';
import { SliderRumusMolekul } from '../materi/SliderRumusMolekul';
import { TabelDeretHomologMateri } from '../materi/TabelDeretHomologMateri';
import { TataNamaIUPACViewer } from '../materi/TataNamaIUPACViewer';
import { CekPemahamanBox } from '../materi/CekPemahamanBox';
import { SifatFisikaViewer } from '../materi/SifatFisikaViewer';
import { ReaksiKimiaStepViewer } from '../materi/ReaksiKimiaStepViewer';
import { PenjelajahIsomer } from '../materi/PenjelajahIsomer';
import { VideoPemantikIUPAC } from '../materi/VideoPemantikIUPAC';
import { BentukRantaiVisualizer } from '../materi/BentukRantaiVisualizer';
import { KekhasanKarbonVisualizer } from '../materi/KekhasanKarbonVisualizer';
import {
  BookOpen,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Layers,
  ChevronRight,
  ChevronLeft,
  FlaskConical,
  X,
  PanelLeftOpen
} from 'lucide-react';

export interface MateriTarget {
  kegiatan: 'kegiatan-1' | 'kegiatan-2' | 'kegiatan-3';
  subBabId?: string;
  nonce?: number;
}

interface MateriPageProps {
  onBackToBeranda: () => void;
  onOpenStructureBuilder?: (challengeId?: string) => void;
  initialTarget?: MateriTarget;
}

const SUB_BAB_ANCHOR_MAP: Record<string, string> = {
  '2.4': 'subbab-2.2',
  '2.6': 'subbab-2.5',
  '2.7': 'subbab-2.5',
  '3.3': 'subbab-3.2',
  '3.5': 'subbab-3.4',
};

function getSubBabAnchorId(subId: string): string {
  return SUB_BAB_ANCHOR_MAP[subId] || `subbab-${subId}`;
}

export const MateriPage: React.FC<MateriPageProps> = ({
  onBackToBeranda,
  onOpenStructureBuilder,
  initialTarget
}) => {
  const [activeKegiatan, setActiveKegiatan] = useState<'kegiatan-1' | 'kegiatan-2' | 'kegiatan-3'>(
    initialTarget?.kegiatan || 'kegiatan-1'
  );
  const [activeSubBabId, setActiveSubBabId] = useState<string>(
    initialTarget?.subBabId ||
      (initialTarget?.kegiatan === 'kegiatan-2'
        ? '2.1'
        : initialTarget?.kegiatan === 'kegiatan-3'
        ? '3.1'
        : '1.1')
  );

  // Daftar Sub-Bab hidden by default; shown on demand via drawer
  const [isSubBabOpen, setIsSubBabOpen] = useState(false);
  const [drawerKegiatan, setDrawerKegiatan] = useState<'kegiatan-1' | 'kegiatan-2' | 'kegiatan-3'>(
    initialTarget?.kegiatan || 'kegiatan-1'
  );

  // Track opened sub-babs with localStorage persistence
  const [openedSubBabs, setOpenedSubBabs] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('hidrokarbon_opened_subbabs');
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return ['1.1'];
  });

  // Sync with incoming deep-link target
  useEffect(() => {
    if (!initialTarget) return;
    setActiveKegiatan(initialTarget.kegiatan);
    setDrawerKegiatan(initialTarget.kegiatan);
    const targetSub =
      initialTarget.subBabId ||
      (initialTarget.kegiatan === 'kegiatan-2'
        ? '2.1'
        : initialTarget.kegiatan === 'kegiatan-3'
        ? '3.1'
        : '1.1');
    setActiveSubBabId(targetSub);

    if (initialTarget.subBabId) {
      setTimeout(() => {
        const el = document.getElementById(getSubBabAnchorId(targetSub));
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 80);
    }
  }, [initialTarget]);

  // Close drawer with Escape key
  useEffect(() => {
    if (!isSubBabOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsSubBabOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSubBabOpen]);

  // Total sub-babs across Kegiatan 1, 2, and 3
  const allSubBabs = [
    ...KEGIATAN_1_DATA.subBabs.map((s) => ({ ...s, kegiatan: 'kegiatan-1' as const })),
    ...KEGIATAN_2_DATA.subBabs.map((s) => ({ ...s, kegiatan: 'kegiatan-2' as const })),
    ...KEGIATAN_3_DATA.subBabs.map((s) => ({ ...s, kegiatan: 'kegiatan-3' as const }))
  ];

  // When activeSubBabId changes, mark it as opened
  useEffect(() => {
    if (!openedSubBabs.includes(activeSubBabId)) {
      const nextOpened = [...openedSubBabs, activeSubBabId];
      setOpenedSubBabs(nextOpened);
      try {
        localStorage.setItem('hidrokarbon_opened_subbabs', JSON.stringify(nextOpened));
      } catch {
        // ignore
      }
    }
  }, [activeSubBabId, openedSubBabs]);

  const progressPercentage = Math.round((openedSubBabs.length / allSubBabs.length) * 100);

  const openSubBabDrawer = () => {
    setDrawerKegiatan(activeKegiatan);
    setIsSubBabOpen(true);
  };

  const handleSelectSubBab = (subId: string, kegiatan: 'kegiatan-1' | 'kegiatan-2' | 'kegiatan-3') => {
    setActiveKegiatan(kegiatan);
    setDrawerKegiatan(kegiatan);
    setActiveSubBabId(subId);
    setIsSubBabOpen(false);
    setTimeout(() => {
      const element = document.getElementById(getSubBabAnchorId(subId));
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 60);
  };

  const handleSwitchKegiatan = (kegiatan: 'kegiatan-1' | 'kegiatan-2' | 'kegiatan-3') => {
    setActiveKegiatan(kegiatan);
    setDrawerKegiatan(kegiatan);
    const firstSub = kegiatan === 'kegiatan-1' ? '1.1' : kegiatan === 'kegiatan-2' ? '2.1' : '3.1';
    setActiveSubBabId(firstSub);
    window.scrollTo({ top: 120, behavior: 'smooth' });
  };

  // Helper current & drawer sub-babs
  const currentSubBabs =
    activeKegiatan === 'kegiatan-1'
      ? KEGIATAN_1_DATA.subBabs
      : activeKegiatan === 'kegiatan-2'
      ? KEGIATAN_2_DATA.subBabs
      : KEGIATAN_3_DATA.subBabs;

  const drawerSubBabs =
    drawerKegiatan === 'kegiatan-1'
      ? KEGIATAN_1_DATA.subBabs
      : drawerKegiatan === 'kegiatan-2'
      ? KEGIATAN_2_DATA.subBabs
      : KEGIATAN_3_DATA.subBabs;

  const activeSubBabObj =
    currentSubBabs.find((s) => s.id === activeSubBabId) || currentSubBabs[0];
  const activeSubIndex = currentSubBabs.findIndex((s) => s.id === activeSubBabId);
  const prevSubBab = activeSubIndex > 0 ? currentSubBabs[activeSubIndex - 1] : null;
  const nextSubBab =
    activeSubIndex >= 0 && activeSubIndex < currentSubBabs.length - 1
      ? currentSubBabs[activeSubIndex + 1]
      : null;

  const activeAccentColor =
    activeKegiatan === 'kegiatan-1'
      ? '#5EEAD4'
      : activeKegiatan === 'kegiatan-2'
      ? '#B4A7FF'
      : '#FFA8C5';

  const drawerAccentColor =
    drawerKegiatan === 'kegiatan-1'
      ? '#5EEAD4'
      : drawerKegiatan === 'kegiatan-2'
      ? '#B4A7FF'
      : '#FFA8C5';

  return (
    <div className="w-full py-8 px-4 sm:px-6 max-w-6xl mx-auto">
      {/* Top Navigation & Back Button */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <button
          onClick={onBackToBeranda}
          className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#B8B5DE] hover:text-[#5EEAD4] transition-colors cursor-pointer py-1.5"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Beranda</span>
        </button>

        <div className="text-xs text-[#B8B5DE]">
          Kimia SMA/MA Kelas XI · KD 3.1 & KD 4.1
        </div>
      </div>

      {/* PROGRESS BAR SECTION */}
      <div className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-4 sm:p-5 mb-6 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#5EEAD4]" />
            <span className="text-xs font-bold uppercase tracking-wider text-[#EEEDFB]">
              Progres Belajar Materi
            </span>
          </div>
          <span className="text-xs font-mono font-bold text-[#5EEAD4] tabular-nums">
            {progressPercentage}% Selesai ({openedSubBabs.length} dari {allSubBabs.length} Sub-bab Dibuka)
          </span>
        </div>

        {/* Progress Track */}
        <div className="w-full h-2.5 bg-[#0F0B2A] rounded-full overflow-hidden border border-[#3A3280]/60">
          <div
            className="h-full bg-gradient-to-r from-[#5EEAD4] via-[#B4A7FF] to-[#FFA8C5] rounded-full transition-all duration-500"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </div>

      {/* KEGIATAN TABS SELECTOR (3 Tab Cards) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-5">
        {/* Tab Kegiatan 1 */}
        <button
          onClick={() => handleSwitchKegiatan('kegiatan-1')}
          className={`p-4 sm:p-5 rounded-2xl border text-left transition-all cursor-pointer flex items-start gap-3.5 ${
            activeKegiatan === 'kegiatan-1'
              ? 'bg-[#1E1850] border-[#5EEAD4] shadow-lg shadow-[#5EEAD4]/10'
              : 'bg-[#150F38]/60 border-[#3A3280] hover:border-[#8E8BB5]'
          }`}
        >
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 ${
              activeKegiatan === 'kegiatan-1'
                ? 'bg-[#5EEAD4] text-[#0F0B2A]'
                : 'bg-[#1E1850] text-[#B8B5DE] border border-[#3A3280]'
            }`}
          >
            01
          </div>
          <div className="space-y-0.5 min-w-0">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#5EEAD4]">
              Kegiatan 1
            </span>
            <h2 className="text-sm sm:text-base font-bold text-[#EEEDFB]">
              Kekhasan Atom Karbon
            </h2>
            <p className="text-xs text-[#B8B5DE] leading-relaxed">
              Konfigurasi ₆C, 4 valensi, dan posisi 1°–4°.
            </p>
          </div>
        </button>

        {/* Tab Kegiatan 2 */}
        <button
          onClick={() => handleSwitchKegiatan('kegiatan-2')}
          className={`p-4 sm:p-5 rounded-2xl border text-left transition-all cursor-pointer flex items-start gap-3.5 ${
            activeKegiatan === 'kegiatan-2'
              ? 'bg-[#1E1850] border-[#B4A7FF] shadow-lg shadow-[#B4A7FF]/10'
              : 'bg-[#150F38]/60 border-[#3A3280] hover:border-[#8E8BB5]'
          }`}
        >
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 ${
              activeKegiatan === 'kegiatan-2'
                ? 'bg-[#B4A7FF] text-[#0F0B2A]'
                : 'bg-[#1E1850] text-[#B8B5DE] border border-[#3A3280]'
            }`}
          >
            02
          </div>
          <div className="space-y-0.5 min-w-0">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#B4A7FF]">
              Kegiatan 2
            </span>
            <h2 className="text-sm sm:text-base font-bold text-[#EEEDFB]">
              Penggolongan & Tata Nama
            </h2>
            <p className="text-xs text-[#B8B5DE] leading-relaxed">
              Alkana, alkena, alkuna, deret homolog, & IUPAC.
            </p>
          </div>
        </button>

        {/* Tab Kegiatan 3 */}
        <button
          onClick={() => handleSwitchKegiatan('kegiatan-3')}
          className={`p-4 sm:p-5 rounded-2xl border text-left transition-all cursor-pointer flex items-start gap-3.5 ${
            activeKegiatan === 'kegiatan-3'
              ? 'bg-[#1E1850] border-[#FFA8C5] shadow-lg shadow-[#FFA8C5]/10'
              : 'bg-[#150F38]/60 border-[#3A3280] hover:border-[#8E8BB5]'
          }`}
        >
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 ${
              activeKegiatan === 'kegiatan-3'
                ? 'bg-[#FFA8C5] text-[#0F0B2A]'
                : 'bg-[#1E1850] text-[#B8B5DE] border border-[#3A3280]'
            }`}
          >
            03
          </div>
          <div className="space-y-0.5 min-w-0">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#FFA8C5]">
              Kegiatan 3
            </span>
            <h2 className="text-sm sm:text-base font-bold text-[#EEEDFB]">
              Sifat Hidrokarbon & Isomer
            </h2>
            <p className="text-xs text-[#B8B5DE] leading-relaxed">
              Sifat fisika, reaksi kimia, & penjelajah isomer.
            </p>
          </div>
        </button>
      </div>

      {/* ON-DEMAND SUB-BAB CONTROL BAR (Daftar Sub-Bab tersembunyi sampai diklik) */}
      <div className="lg:sticky lg:top-[72px] lg:z-30 bg-[#150F38]/95 lg:backdrop-blur-md border border-[#3A3280] rounded-2xl px-3.5 py-3 sm:px-4 mb-8 shadow-md">
        <div className="flex items-center justify-between gap-2.5">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={openSubBabDrawer}
              aria-expanded={isSubBabOpen}
              aria-controls="drawer-daftar-subbab"
              className="inline-flex items-center gap-2 px-3.5 py-2 min-h-[42px] rounded-xl bg-[#1E1850] hover:bg-[#272063] border border-[#3A3280] hover:border-[#5EEAD4] text-[#EEEDFB] text-xs sm:text-sm font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#5EEAD4]"
            >
              <PanelLeftOpen className="w-4 h-4 text-[#5EEAD4]" />
              <span>Daftar Sub-Bab</span>
              <span className="font-mono text-xs text-[#B8B5DE] tabular-nums">
                ({currentSubBabs.length})
              </span>
            </button>

            <div className="hidden md:flex items-center gap-2 text-xs sm:text-sm text-[#B8B5DE] min-w-0">
              <span className="text-[#8E8BB5]">Topik aktif:</span>
              <span
                className="font-mono font-bold shrink-0"
                style={{ color: activeAccentColor }}
              >
                {activeSubBabObj?.id}
              </span>
              <span className="text-[#EEEDFB] font-semibold truncate max-w-md">
                {activeSubBabObj?.judul}
              </span>
            </div>
          </div>

          {/* Quick Prev / Next Sub-Bab Stepper */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              disabled={!prevSubBab}
              onClick={() => prevSubBab && handleSelectSubBab(prevSubBab.id, activeKegiatan)}
              aria-label="Sub-bab sebelumnya"
              className={`inline-flex items-center justify-center gap-1 px-2.5 sm:px-3 py-2 min-h-[40px] min-w-[40px] rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap ${
                prevSubBab
                  ? 'bg-[#1E1850]/70 border-[#3A3280] text-[#EEEDFB] hover:border-[#8E8BB5] cursor-pointer'
                  : 'bg-[#150F38]/40 border-[#3A3280]/40 text-[#8E8BB5]/40 cursor-not-allowed'
              }`}
              title={prevSubBab ? `Ke Sub-Bab ${prevSubBab.id}: ${prevSubBab.judul}` : undefined}
            >
              <ChevronLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Sebelumnya</span>
            </button>

            <button
              type="button"
              disabled={!nextSubBab}
              onClick={() => nextSubBab && handleSelectSubBab(nextSubBab.id, activeKegiatan)}
              aria-label="Sub-bab berikutnya"
              className={`inline-flex items-center justify-center gap-1 px-2.5 sm:px-3 py-2 min-h-[40px] min-w-[40px] rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap ${
                nextSubBab
                  ? 'bg-[#1E1850]/70 border-[#3A3280] text-[#EEEDFB] hover:border-[#8E8BB5] cursor-pointer'
                  : 'bg-[#150F38]/40 border-[#3A3280]/40 text-[#8E8BB5]/40 cursor-not-allowed'
              }`}
              title={nextSubBab ? `Ke Sub-Bab ${nextSubBab.id}: ${nextSubBab.judul}` : undefined}
            >
              <span className="hidden sm:inline">Berikutnya</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Active sub-bab indicator row on mobile/tablet (< md) */}
        <div className="md:hidden mt-2.5 pt-2.5 border-t border-[#3A3280]/60 flex items-center gap-2 text-xs min-w-0">
          <span
            className="font-mono font-bold shrink-0"
            style={{ color: activeAccentColor }}
          >
            {activeSubBabObj?.id}
          </span>
          <span className="text-[#EEEDFB] font-semibold truncate">
            {activeSubBabObj?.judul}
          </span>
        </div>
      </div>

      {/* ON-DEMAND SLIDE-OVER DRAWER: DAFTAR SUB-BAB */}
      {isSubBabOpen && (
        <div className="fixed inset-0 z-[60] flex" role="dialog" aria-modal="true" aria-labelledby="drawer-subbab-title">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-[#08051A]/75 backdrop-blur-sm transition-opacity"
            onClick={() => setIsSubBabOpen(false)}
            aria-hidden="true"
          />

          {/* Drawer Panel */}
          <aside
            id="drawer-daftar-subbab"
            className="relative z-10 w-[86vw] max-w-sm h-full bg-[#150F38] border-r border-[#3A3280] shadow-2xl flex flex-col pb-[env(safe-area-inset-bottom,0px)]"
          >
            {/* Drawer Header */}
            <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-[#3A3280]">
              <div className="flex items-center gap-2.5 min-w-0">
                <Layers className="w-4 h-4 text-[#5EEAD4] shrink-0" />
                <div>
                  <h3 id="drawer-subbab-title" className="text-sm font-bold text-[#EEEDFB]">
                    Daftar Sub-Bab
                  </h3>
                  <p className="text-[11px] text-[#B8B5DE]">
                    {drawerKegiatan === 'kegiatan-1'
                      ? 'Kegiatan 1 · Hal. 8–10'
                      : drawerKegiatan === 'kegiatan-2'
                      ? 'Kegiatan 2 · Hal. 15–21'
                      : 'Kegiatan 3 · Hal. 28–31'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsSubBabOpen(false)}
                aria-label="Tutup daftar sub-bab"
                className="w-10 h-10 rounded-xl bg-[#1E1850] border border-[#3A3280] text-[#B8B5DE] hover:text-[#EEEDFB] hover:border-[#8E8BB5] flex items-center justify-center transition-colors cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Kegiatan Switcher inside Drawer */}
            <div className="px-5 pt-4 pb-3 border-b border-[#3A3280]/60">
              <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#0F0B2A] rounded-xl border border-[#3A3280]/80">
                {[
                  { id: 'kegiatan-1' as const, label: 'Keg. 1', color: '#5EEAD4' },
                  { id: 'kegiatan-2' as const, label: 'Keg. 2', color: '#B4A7FF' },
                  { id: 'kegiatan-3' as const, label: 'Keg. 3', color: '#FFA8C5' },
                ].map((tab) => {
                  const isSelected = drawerKegiatan === tab.id;
                  return (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setDrawerKegiatan(tab.id)}
                      className={`py-2 px-2 rounded-lg text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                        isSelected
                          ? 'bg-[#1E1850] text-[#EEEDFB] border border-[#3A3280]'
                          : 'text-[#8E8BB5] hover:text-[#EEEDFB]'
                      }`}
                      style={isSelected ? { color: tab.color } : undefined}
                    >
                      {tab.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Sub-Bab List */}
            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-2">
              {drawerSubBabs.map((sub) => {
                const isCurrent =
                  activeKegiatan === drawerKegiatan && activeSubBabId === sub.id;
                const isOpened = openedSubBabs.includes(sub.id);

                return (
                  <button
                    key={sub.id}
                    type="button"
                    onClick={() => handleSelectSubBab(sub.id, drawerKegiatan)}
                    className={`w-full text-left px-3.5 py-3 min-h-[46px] rounded-xl transition-all cursor-pointer flex items-center justify-between gap-2 text-xs sm:text-sm border ${
                      isCurrent
                        ? 'bg-[#1E1850] font-bold'
                        : 'bg-[#0F0B2A]/60 border-transparent text-[#B8B5DE] hover:text-[#EEEDFB] hover:bg-[#1E1850]/60 hover:border-[#3A3280]'
                    }`}
                    style={
                      isCurrent
                        ? { borderColor: drawerAccentColor, color: drawerAccentColor }
                        : undefined
                    }
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="font-mono text-xs font-bold shrink-0 tabular-nums">
                        {sub.id}
                      </span>
                      <span className="truncate">{sub.judul}</span>
                    </div>
                    {isOpened && (
                      <CheckCircle2 className="w-4 h-4 text-[#5EEAD4] shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Drawer Footer */}
            <div className="px-5 py-3.5 border-t border-[#3A3280] bg-[#0F0B2A]/60 flex items-center justify-between text-[11px] text-[#B8B5DE]">
              <span>Pilih sub-bab untuk langsung melompat</span>
              <span className="font-mono font-bold text-[#5EEAD4] tabular-nums">
                {openedSubBabs.length}/{allSubBabs.length} dibuka
              </span>
            </div>
          </aside>
        </div>
      )}

      {/* FULL-WIDTH CONTENT STAGE */}
      <div className="w-full">
        <div className="space-y-10">
          {/* ================================================================ */}
          {/* ISI KEGIATAN 1                                                   */}
          {/* ================================================================ */}
          {activeKegiatan === 'kegiatan-1' && (
            <div className="space-y-10">
              {/* Sub-Bab 1.1: Kekhasan Atom Karbon */}
              <section id="subbab-1.1" className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-6 sm:p-8 space-y-5 shadow-lg scroll-mt-24">
                <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
                  <div>
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-[#5EEAD4]/20 text-[#5EEAD4] border border-[#5EEAD4]/40">
                      Sub-Bab 1.1
                    </span>
                    <h3 className="text-xl sm:text-2xl font-bold text-[#EEEDFB] mt-2">
                      Kekhasan Atom Karbon
                    </h3>
                  </div>
                  <div className="px-3 py-1.5 rounded-xl bg-[#0F0B2A] border border-[#3A3280] text-xs font-mono text-[#EEEDFB] w-fit">
                    <span className="text-[#5EEAD4] font-bold">₆C</span> · {KEGIATAN_1_DATA.kekhasan.konfigurasi}
                  </div>
                </div>

                {/* Visualisasi Interaktif Kekhasan Atom Karbon */}
                <KekhasanKarbonVisualizer />
              </section>

              {/* Sub-Bab 1.2: Bentuk Ikatan & Bentuk Rantai Karbon */}
              <section id="subbab-1.2" className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-6 sm:p-8 space-y-6 shadow-lg scroll-mt-24">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-[#5EEAD4]/20 text-[#5EEAD4] border border-[#5EEAD4]/40">
                      Sub-Bab 1.2
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-[#EEEDFB]">
                    Bentuk Ikatan Kovalen & Kerangka Rantai Karbon
                  </h3>
                </div>

                {/* Jenis Ikatan: Tunggal, Rangkap 2, Rangkap 3 */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#B8B5DE]">
                    1. Berdasarkan Jumlah Pasangan Elektron Ikatan:
                  </h4>
                  <div className="grid grid-cols-1 gap-3">
                    {KEGIATAN_1_DATA.bentukIkatan.map((ikatan) => (
                      <div
                        key={ikatan.jenis}
                        className="p-4 bg-[#0F0B2A] border border-[#3A3280] rounded-xl space-y-1.5"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-bold text-[#EEEDFB]">
                            {ikatan.jenis}
                          </span>
                          <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                            ikatan.sifat === 'Jenuh' ? 'bg-[#5EEAD4]/20 text-[#5EEAD4]' : 'bg-[#FFA8C5]/20 text-[#FFA8C5]'
                          }`}>
                            {ikatan.sifat}
                          </span>
                        </div>
                        <p className="text-xs text-[#B8B5DE] leading-relaxed">
                          {ikatan.penjelasan}
                        </p>
                        <div className="text-xs font-mono text-[#A99CFF]">
                          {ikatan.contoh}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bentuk Rantai: Terbuka (Alifatik) & Tertutup (Siklis) */}
                <div className="space-y-4 pt-4 border-t border-[#3A3280]">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#B8B5DE]">
                    2. Berdasarkan Bentuk Susunan Rantai Karbon:
                  </h4>

                  <BentukRantaiVisualizer />
                </div>
              </section>

              {/* Sub-Bab 1.3: Posisi Atom C (Interaktif) */}
              <section id="subbab-1.3" className="scroll-mt-24">
                <AtomCPosisiInteractive />
              </section>

              {/* Sub-Bab 1.4: Rangkuman & Cek Pemahaman Kegiatan 1 */}
              <section id="subbab-1.4" className="space-y-6 scroll-mt-24">
                {/* Rangkuman */}
                <div className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-6 sm:p-8 space-y-4 shadow-lg">
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-[#5EEAD4]" />
                    <h3 className="text-lg sm:text-xl font-bold text-[#EEEDFB]">
                      Rangkuman Kegiatan Pembelajaran 1
                    </h3>
                  </div>
                  <ul className="space-y-2.5">
                    {KEGIATAN_1_DATA.rangkuman.map((poin, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-[#B8B5DE] leading-relaxed">
                        <span className="text-[#5EEAD4] font-bold mt-0.5">#{idx + 1}</span>
                        <span>{poin}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Cek Pemahaman */}
                <CekPemahamanBox
                  judul="Cek Pemahaman: Kegiatan Pembelajaran 1"
                  soals={KEGIATAN_1_DATA.cekPemahaman}
                  aksenColor="#5EEAD4"
                />

                {/* Tombol Lanjut ke Kegiatan 2 & Akses Daftar Sub-Bab */}
                <div className="pt-2 flex flex-col-reverse sm:flex-row sm:items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={openSubBabDrawer}
                    className="inline-flex items-center justify-center gap-2 px-4 py-2.5 min-h-[42px] rounded-xl border border-[#3A3280] bg-[#150F38] text-[#B8B5DE] hover:text-[#EEEDFB] hover:border-[#5EEAD4] font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
                  >
                    <Layers className="w-4 h-4 text-[#5EEAD4]" />
                    <span>Daftar Sub-Bab</span>
                  </button>

                  <button
                    onClick={() => handleSwitchKegiatan('kegiatan-2')}
                    className="px-5 py-3 min-h-[44px] rounded-xl bg-[#B4A7FF] text-[#0F0B2A] font-bold text-xs sm:text-sm hover:bg-[#9E8EFE] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                  >
                    <span>Lanjut ke Kegiatan 2: Penggolongan Hidrokarbon</span>
                    <ChevronRight className="w-4 h-4 shrink-0" />
                  </button>
                </div>
              </section>
            </div>
          )}

          {/* ================================================================ */}
          {/* ISI KEGIATAN 2                                                   */}
          {/* ================================================================ */}
          {activeKegiatan === 'kegiatan-2' && (
            <div className="space-y-10">
              {/* Sub-Bab 2.1: Penggolongan Alkana, Alkena, Alkuna */}
              <section id="subbab-2.1" className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-6 sm:p-8 space-y-5 shadow-lg scroll-mt-24">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-[#B4A7FF]/20 text-[#B4A7FF] border border-[#B4A7FF]/40">
                    Sub-Bab 2.1
                  </span>
                </div>

                <h3 className="text-xl sm:text-2xl font-bold text-[#EEEDFB]">
                  Penggolongan Hidrokarbon Alifatik: Alkana, Alkena, dan Alkuna
                </h3>

                {/* 3 Golongan Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                  {KEGIATAN_2_DATA.golonganUtama.map((gol) => (
                    <div
                      key={gol.id}
                      className="p-5 bg-[#0F0B2A] border rounded-xl space-y-3 flex flex-col justify-between"
                      style={{ borderColor: `${gol.warna}50` }}
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-xl font-bold" style={{ color: gol.warna }}>
                            {gol.simbolIkatan}
                          </span>
                          <span className="font-mono text-xs px-2 py-0.5 rounded bg-[#150F38] border border-[#3A3280] text-[#EEEDFB]">
                            {gol.rumusUmum}
                          </span>
                        </div>
                        <h4 className="text-lg font-bold text-[#EEEDFB]">
                          {gol.nama}
                        </h4>
                        <div className="text-xs font-medium" style={{ color: gol.warna }}>
                          {gol.jenisIkatan}
                        </div>
                        <p className="text-xs text-[#B8B5DE] leading-relaxed">
                          {gol.deskripsi}
                        </p>
                      </div>

                      <div className="pt-3 border-t border-[#3A3280]/60 text-xs">
                        <span className="text-[#B8B5DE] block text-[11px]">Suku Paling Sederhana:</span>
                        <strong className="text-[#EEEDFB] font-mono">{gol.anggotaSederhana}</strong>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Sub-Bab 2.2: Deret Homolog & Tabel Rumus Struktur */}
              <section id="subbab-2.2" className="scroll-mt-24">
                <TabelDeretHomologMateri />
              </section>

              {/* Sub-Bab 2.3: Slider Rumus Molekul Interaktif */}
              <section id="subbab-2.3" className="scroll-mt-24">
                <SliderRumusMolekul />
              </section>

              {/* Video Pemantik sebelum Sub-Bab 2.5 */}
              <VideoPemantikIUPAC />

              {/* Sub-Bab 2.5 & 2.6 & 2.7: Tata Nama IUPAC & 9 Contoh & Latihan */}
              <section id="subbab-2.5" className="scroll-mt-24 space-y-6">
                <TataNamaIUPACViewer />

                {onOpenStructureBuilder && (
                  <div className="bg-[#1E1850] border border-[#5EEAD4]/50 rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs font-bold text-[#5EEAD4]">
                        <FlaskConical className="w-4 h-4" />
                        <span>Praktik Menggambar Struktur Senyawa</span>
                      </div>
                      <h4 className="text-base sm:text-lg font-bold text-[#EEEDFB]">
                        Latihan Susun Struktur dari Nama IUPAC
                      </h4>
                      <p className="text-xs text-[#B8B5DE] leading-relaxed max-w-lg">
                        Sudah paham aturan tata nama? Coba langsung susun struktur molekul seperti{' '}
                        <span className="font-mono text-[#EEEDFB]">3-etil-4,5-dimetilheksana</span>{' '}
                        pada kanvas interaktif!
                      </p>
                    </div>
                    <button
                      onClick={() => onOpenStructureBuilder('chal-10')}
                      className="px-4 py-2.5 rounded-xl bg-[#5EEAD4] hover:bg-[#4dd6c0] text-[#0F0B2A] font-bold text-xs sm:text-sm transition-colors cursor-pointer flex items-center gap-2 shrink-0 whitespace-nowrap"
                    >
                      <span>Buka Permainan Struktur</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </section>

              {/* Sub-Bab 2.8: Rangkuman & Cek Pemahaman Kegiatan 2 */}
              <section id="subbab-2.8" className="space-y-6 scroll-mt-24">
                {/* Rangkuman Kegiatan 2 */}
                <div className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-6 sm:p-8 space-y-4 shadow-lg">
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-[#B4A7FF]" />
                    <h3 className="text-lg sm:text-xl font-bold text-[#EEEDFB]">
                      Rangkuman Kegiatan Pembelajaran 2
                    </h3>
                  </div>
                  <ul className="space-y-2.5">
                    {KEGIATAN_2_DATA.rangkuman.map((poin, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-[#B8B5DE] leading-relaxed">
                        <span className="text-[#B4A7FF] font-bold mt-0.5">#{idx + 1}</span>
                        <span>{poin}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Cek Pemahaman Kegiatan 2 */}
                <CekPemahamanBox
                  judul="Cek Pemahaman: Kegiatan Pembelajaran 2"
                  soals={KEGIATAN_2_DATA.cekPemahaman}
                  aksenColor="#B4A7FF"
                />

                {/* Tombol Navigasi Antar Kegiatan */}
                <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleSwitchKegiatan('kegiatan-1')}
                      className="px-4 py-2.5 min-h-[42px] rounded-xl border border-[#3A3280] text-[#B8B5DE] hover:text-[#EEEDFB] font-semibold text-xs sm:text-sm transition-all cursor-pointer"
                    >
                      ← Kegiatan 1
                    </button>
                    <button
                      type="button"
                      onClick={openSubBabDrawer}
                      className="inline-flex items-center gap-2 px-3.5 py-2.5 min-h-[42px] rounded-xl border border-[#3A3280] bg-[#150F38] text-[#B8B5DE] hover:text-[#EEEDFB] hover:border-[#B4A7FF] font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
                    >
                      <Layers className="w-4 h-4 text-[#B4A7FF]" />
                      <span>Sub-Bab</span>
                    </button>
                  </div>

                  <button
                    onClick={() => handleSwitchKegiatan('kegiatan-3')}
                    className="px-5 py-2.5 min-h-[42px] rounded-xl bg-[#FFA8C5] text-[#0F0B2A] font-bold text-xs sm:text-sm hover:bg-[#FF94B6] transition-all cursor-pointer shadow-md flex items-center gap-1.5"
                  >
                    <span>Lanjut ke Kegiatan 3: Sifat & Isomer</span>
                    <ChevronRight className="w-4 h-4 shrink-0" />
                  </button>
                </div>
              </section>
            </div>
          )}

          {/* ================================================================ */}
          {/* ISI KEGIATAN 3                                                   */}
          {/* ================================================================ */}
          {activeKegiatan === 'kegiatan-3' && (
            <div className="space-y-10">
              {/* Sub-Bab 3.1: Sifat Fisika Hidrokarbon */}
              <section id="subbab-3.1" className="scroll-mt-24">
                <SifatFisikaViewer />
              </section>

              {/* Sub-Bab 3.2 & 3.3: Reaksi-Reaksi Kimia Hidrokarbon & Aturan Markovnikov */}
              <section id="subbab-3.2" className="scroll-mt-24">
                <ReaksiKimiaStepViewer />
              </section>

              {/* Sub-Bab 3.4 & 3.5: Penjelajah Isomer KD 4.1 */}
              <section id="subbab-3.4" className="scroll-mt-24">
                <PenjelajahIsomer />
              </section>

              {/* Sub-Bab 3.6: Rangkuman & Cek Pemahaman Kegiatan 3 */}
              <section id="subbab-3.6" className="space-y-6 scroll-mt-24">
                {/* Rangkuman Kegiatan 3 */}
                <div className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-6 sm:p-8 space-y-4 shadow-lg">
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-[#FFA8C5]" />
                    <h3 className="text-lg sm:text-xl font-bold text-[#EEEDFB]">
                      Rangkuman Kegiatan Pembelajaran 3
                    </h3>
                  </div>
                  <ul className="space-y-2.5">
                    {KEGIATAN_3_DATA.rangkuman.map((poin, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-[#B8B5DE] leading-relaxed">
                        <span className="text-[#FFA8C5] font-bold mt-0.5">#{idx + 1}</span>
                        <span>{poin}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Cek Pemahaman Kegiatan 3 */}
                <CekPemahamanBox
                  judul="Cek Pemahaman: Kegiatan Pembelajaran 3"
                  soals={KEGIATAN_3_DATA.cekPemahaman}
                  aksenColor="#FFA8C5"
                />

                {/* Navigasi Footer Halaman Materi */}
                <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleSwitchKegiatan('kegiatan-2')}
                      className="px-4 py-2.5 min-h-[42px] rounded-xl border border-[#3A3280] text-[#B8B5DE] hover:text-[#EEEDFB] font-semibold text-xs sm:text-sm transition-all cursor-pointer"
                    >
                      ← Kegiatan 2
                    </button>
                    <button
                      type="button"
                      onClick={openSubBabDrawer}
                      className="inline-flex items-center gap-2 px-3.5 py-2.5 min-h-[42px] rounded-xl border border-[#3A3280] bg-[#150F38] text-[#B8B5DE] hover:text-[#EEEDFB] hover:border-[#FFA8C5] font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
                    >
                      <Layers className="w-4 h-4 text-[#FFA8C5]" />
                      <span>Sub-Bab</span>
                    </button>
                  </div>

                  <button
                    onClick={onBackToBeranda}
                    className="px-5 py-2.5 min-h-[42px] rounded-xl bg-[#5EEAD4] text-[#0F0B2A] font-bold text-xs sm:text-sm hover:bg-[#48D4BE] transition-all cursor-pointer shadow-md"
                  >
                    Kembali ke Beranda
                  </button>
                </div>
              </section>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
