/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Permainan & Latihan Interaktif Menyusun Struktur Senyawa Hidrokarbon
 * Fitur:
 * - Grid molekul interaktif 10x7 dengan auto-valensi (CH₃, CH₂, CH, C)
 * - Pilihan ikatan tunggal (—), rangkap dua (=), dan rangkap tiga (≡)
 * - Tombol cepat (+) di sekitar atom terpilih untuk merangkai rantai & cabang dengan mudah
 * - Mode Tantangan (10 soal termasuk 3-etil-4,5-dimetilheksana) & Mode Eksplorasi Bebas
 * - Validasi graf molekul eksak (isomorfisme graf) dengan diagnostik kesalahan terarah
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  GridAtom,
  GridBond,
  StructureChallenge,
  ValidationResult,
  analyzeMolecule,
  makeBondId,
  validateStructureAgainstChallenge,
} from '../../utils/hydrocarbonEngine';
import { STRUCTURE_CHALLENGES } from '../../data/structureChallenges';
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Lightbulb,
  RotateCcw,
  Undo2,
  Trash2,
  Eye,
  ArrowRight,
  Compass,
  FlaskConical,
  HelpCircle,
  Plus,
  Layers,
} from 'lucide-react';

const GRID_COLS = 10;
const GRID_ROWS = 7;

type ToolMode = 'bond-1' | 'bond-2' | 'bond-3' | 'erase';
type GameMode = 'challenge' | 'sandbox';

interface HistorySnapshot {
  atoms: GridAtom[];
  bonds: GridBond[];
  selectedAtomId: string | null;
}

interface HydrocarbonBuilderGameProps {
  initialChallengeId?: string;
}

const INITIAL_SEED_ATOM: GridAtom = { id: 'a-seed', row: 3, col: 2 };

export const HydrocarbonBuilderGame: React.FC<HydrocarbonBuilderGameProps> = ({
  initialChallengeId,
}) => {
  const [gameMode, setGameMode] = useState<GameMode>('challenge');
  const [activeChallengeId, setActiveChallengeId] = useState<string>(() => {
    if (
      initialChallengeId &&
      STRUCTURE_CHALLENGES.some((c) => c.id === initialChallengeId)
    ) {
      return initialChallengeId;
    }
    // Default to challenge 1, or if user navigated specifically for 3-etil-4,5-dimetilheksana
    return STRUCTURE_CHALLENGES[0].id;
  });

  // Update challenge if initialChallengeId prop changes
  useEffect(() => {
    if (
      initialChallengeId &&
      STRUCTURE_CHALLENGES.some((c) => c.id === initialChallengeId)
    ) {
      setGameMode('challenge');
      setActiveChallengeId(initialChallengeId);
    }
  }, [initialChallengeId]);

  const activeChallenge: StructureChallenge = useMemo(
    () =>
      STRUCTURE_CHALLENGES.find((c) => c.id === activeChallengeId) ||
      STRUCTURE_CHALLENGES[0],
    [activeChallengeId]
  );

  // Solved challenges persisted in localStorage
  const [solvedIds, setSolvedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('hidrokarbon_solved_structures');
      if (saved) return JSON.parse(saved);
    } catch {
      // Ignore storage restrictions
    }
    return [];
  });

  // Canvas state
  const [atoms, setAtoms] = useState<GridAtom[]>([INITIAL_SEED_ATOM]);
  const [bonds, setBonds] = useState<GridBond[]>([]);
  const [selectedAtomId, setSelectedAtomId] = useState<string | null>(
    INITIAL_SEED_ATOM.id
  );
  const [history, setHistory] = useState<HistorySnapshot[]>([]);

  // Tool & UI state
  const [toolMode, setToolMode] = useState<ToolMode>('bond-1');
  const [showHint, setShowHint] = useState<boolean>(false);
  const [showChainNumbers, setShowChainNumbers] = useState<boolean>(false);
  const [isShowingKey, setIsShowingKey] = useState<boolean>(false);
  const [valenceWarning, setValenceWarning] = useState<string | null>(null);
  const [validationResult, setValidationResult] =
    useState<ValidationResult | null>(null);

  // Live chemical analysis of current canvas
  const analysis = useMemo(() => analyzeMolecule(atoms, bonds), [atoms, bonds]);

  // Reset canvas whenever switching challenges
  const resetCanvas = (withSeed = true) => {
    const seed = withSeed ? [{ ...INITIAL_SEED_ATOM }] : [];
    setAtoms(seed);
    setBonds([]);
    setSelectedAtomId(withSeed ? INITIAL_SEED_ATOM.id : null);
    setHistory([]);
    setValidationResult(null);
    setValenceWarning(null);
    setIsShowingKey(false);
    setShowChainNumbers(false);
    setToolMode('bond-1');
  };

  const handleSelectChallenge = (id: string) => {
    setActiveChallengeId(id);
    setGameMode('challenge');
    setShowHint(false);
    resetCanvas(true);
  };

  const handleSwitchGameMode = (mode: GameMode) => {
    setGameMode(mode);
    setShowHint(false);
    resetCanvas(true);
  };

  const pushHistory = () => {
    setHistory((prev) => [
      ...prev.slice(-24),
      {
        atoms: atoms.map((a) => ({ ...a })),
        bonds: bonds.map((b) => ({ ...b })),
        selectedAtomId,
      },
    ]);
  };

  const handleUndo = () => {
    if (history.length === 0) return;
    const last = history[history.length - 1];
    setAtoms(last.atoms);
    setBonds(last.bonds);
    setSelectedAtomId(last.selectedAtomId);
    setHistory((prev) => prev.slice(0, -1));
    setValidationResult(null);
    setValenceWarning(null);
    setIsShowingKey(false);
  };

  const getActiveBondOrder = (): 1 | 2 | 3 => {
    if (toolMode === 'bond-2') return 2;
    if (toolMode === 'bond-3') return 3;
    return 1;
  };

  const getAtomUsedValence = (atomId: string, currentBonds = bonds): number => {
    return currentBonds
      .filter((b) => b.from === atomId || b.to === atomId)
      .reduce((sum, b) => sum + b.order, 0);
  };

  const areAdjacent = (a: GridAtom, b: GridAtom): boolean => {
    return Math.abs(a.row - b.row) + Math.abs(a.col - b.col) === 1;
  };

  const showTempWarning = (msg: string) => {
    setValenceWarning(msg);
  };

  // Click on an empty grid cell (or a '+' ghost cell)
  const handleEmptyCellClick = (row: number, col: number) => {
    if (toolMode === 'erase') {
      setSelectedAtomId(null);
      return;
    }

    setValenceWarning(null);
    setValidationResult(null);
    setIsShowingKey(false);

    const newId = `a-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const newAtom: GridAtom = { id: newId, row, col };
    const order = getActiveBondOrder();

    // Determine which adjacent atom to auto-connect to (prefer currently selected atom)
    const adjacentAtoms = atoms.filter((a) => areAdjacent(a, newAtom));
    let connectTarget: GridAtom | undefined;

    if (selectedAtomId) {
      connectTarget = adjacentAtoms.find((a) => a.id === selectedAtomId);
    }
    if (!connectTarget && adjacentAtoms.length > 0) {
      connectTarget = adjacentAtoms.find(
        (a) => getAtomUsedValence(a.id) + order <= 4
      );
    }

    // Check valence if adjacent to selected atom specifically
    if (connectTarget && getAtomUsedValence(connectTarget.id) + order > 4) {
      showTempWarning(
        'Atom C tersebut sudah memakai 4 tangan ikatan kovalen (maksimal aturan oktet). Pilih atom C lain atau kurangi orde ikatan.'
      );
      return;
    }

    pushHistory();
    const nextAtoms = [...atoms, newAtom];
    const nextBonds = [...bonds];

    if (connectTarget) {
      nextBonds.push({
        id: makeBondId(connectTarget.id, newAtom.id),
        from: connectTarget.id,
        to: newAtom.id,
        order,
      });
    }

    setAtoms(nextAtoms);
    setBonds(nextBonds);
    setSelectedAtomId(newId);
  };

  // Click on an existing carbon atom
  const handleAtomClick = (atom: GridAtom) => {
    setValenceWarning(null);
    setValidationResult(null);
    setIsShowingKey(false);

    if (toolMode === 'erase') {
      pushHistory();
      setAtoms((prev) => prev.filter((a) => a.id !== atom.id));
      setBonds((prev) =>
        prev.filter((b) => b.from !== atom.id && b.to !== atom.id)
      );
      if (selectedAtomId === atom.id) {
        setSelectedAtomId(null);
      }
      return;
    }

    // If clicking the already-selected atom -> keep selected
    if (selectedAtomId === atom.id) {
      return;
    }

    // If another atom is selected and is adjacent -> create/update bond or move selection
    if (selectedAtomId) {
      const selectedAtom = atoms.find((a) => a.id === selectedAtomId);
      if (selectedAtom && areAdjacent(selectedAtom, atom)) {
        const bId = makeBondId(selectedAtom.id, atom.id);
        const existingBond = bonds.find((b) => b.id === bId);
        const targetOrder = getActiveBondOrder();

        if (!existingBond) {
          const usedA = getAtomUsedValence(selectedAtom.id);
          const usedB = getAtomUsedValence(atom.id);
          if (usedA + targetOrder > 4 || usedB + targetOrder > 4) {
            showTempWarning(
              'Tidak dapat menyambung ikatan karena salah satu atom C akan melebihi 4 ikatan (oktet).'
            );
            setSelectedAtomId(atom.id);
            return;
          }
          pushHistory();
          setBonds((prev) => [
            ...prev,
            { id: bId, from: selectedAtom.id, to: atom.id, order: targetOrder },
          ]);
          setSelectedAtomId(atom.id);
          return;
        } else if (existingBond.order !== targetOrder) {
          const delta = targetOrder - existingBond.order;
          const usedA = getAtomUsedValence(selectedAtom.id);
          const usedB = getAtomUsedValence(atom.id);
          if (usedA + delta > 4 || usedB + delta > 4) {
            showTempWarning(
              'Valensi atom C tidak mencukupi untuk menaikkan orde ikatan ini (maksimal 4 tangan ikatan).'
            );
            return;
          }
          pushHistory();
          setBonds((prev) =>
            prev.map((b) =>
              b.id === bId ? { ...b, order: targetOrder } : b
            )
          );
          return;
        }
      }
    }

    setSelectedAtomId(atom.id);
  };

  // Click directly on a covalent bond line
  const handleBondClick = (bond: GridBond) => {
    setValenceWarning(null);
    setValidationResult(null);
    setIsShowingKey(false);

    if (toolMode === 'erase') {
      pushHistory();
      setBonds((prev) => prev.filter((b) => b.id !== bond.id));
      return;
    }

    const activeOrder = getActiveBondOrder();
    const nextOrder: 1 | 2 | 3 =
      bond.order !== activeOrder
        ? activeOrder
        : bond.order === 1
        ? 2
        : bond.order === 2
        ? 3
        : 1;

    const delta = nextOrder - bond.order;
    if (delta > 0) {
      const usedA = getAtomUsedValence(bond.from);
      const usedB = getAtomUsedValence(bond.to);
      if (usedA + delta > 4 || usedB + delta > 4) {
        showTempWarning(
          'Tidak cukup tangan ikatan bebas untuk menambah ikatan rangkap (atom C maksimal 4 ikatan).'
        );
        return;
      }
    }

    pushHistory();
    setBonds((prev) =>
      prev.map((b) => (b.id === bond.id ? { ...b, order: nextOrder } : b))
    );
  };

  // Submit & Validate Structure
  const handleCheckStructure = () => {
    setValenceWarning(null);
    const result = validateStructureAgainstChallenge(
      atoms,
      bonds,
      activeChallenge
    );
    setValidationResult(result);

    if (result.isCorrect) {
      setShowChainNumbers(true);
      if (!solvedIds.includes(activeChallenge.id)) {
        const updated = [...solvedIds, activeChallenge.id];
        setSolvedIds(updated);
        try {
          localStorage.setItem(
            'hidrokarbon_solved_structures',
            JSON.stringify(updated)
          );
        } catch {
          // Ignore
        }
      }
    }
  };

  // Load reference key onto canvas for learning
  const handleShowReferenceKey = () => {
    pushHistory();
    setAtoms(activeChallenge.referenceAtoms.map((a) => ({ ...a })));
    setBonds(activeChallenge.referenceBonds.map((b) => ({ ...b })));
    setSelectedAtomId(null);
    setIsShowingKey(true);
    setShowChainNumbers(true);
    setValenceWarning(null);
    setValidationResult(null);
  };

  const handleNextChallenge = () => {
    const idx = STRUCTURE_CHALLENGES.findIndex(
      (c) => c.id === activeChallenge.id
    );
    const next = STRUCTURE_CHALLENGES[(idx + 1) % STRUCTURE_CHALLENGES.length];
    handleSelectChallenge(next.id);
  };

  // Compute adjacent empty cells around the currently selected atom for quick '+' ghost buttons
  const selectedAtom = atoms.find((a) => a.id === selectedAtomId) || null;
  const selectedAtomHasFreeValence = selectedAtom
    ? getAtomUsedValence(selectedAtom.id) + getActiveBondOrder() <= 4
    : false;

  const occupiedMap = useMemo(() => {
    const map: Record<string, GridAtom> = {};
    for (const a of atoms) {
      map[`${a.row},${a.col}`] = a;
    }
    return map;
  }, [atoms]);

  const ghostNeighborKeys = useMemo(() => {
    const keys = new Set<string>();
    if (!selectedAtom || toolMode === 'erase' || !selectedAtomHasFreeValence) {
      return keys;
    }
    const dirs = [
      [-1, 0],
      [1, 0],
      [0, -1],
      [0, 1],
    ];
    for (const [dr, dc] of dirs) {
      const nr = selectedAtom.row + dr;
      const nc = selectedAtom.col + dc;
      if (
        nr >= 0 &&
        nr < GRID_ROWS &&
        nc >= 0 &&
        nc < GRID_COLS &&
        !occupiedMap[`${nr},${nc}`]
      ) {
        keys.add(`${nr},${nc}`);
      }
    }
    return keys;
  }, [selectedAtom, toolMode, selectedAtomHasFreeValence, occupiedMap]);

  // Helper for main chain numbering overlay
  const chainOrderMap = useMemo(() => {
    const map: Record<string, number> = {};
    if (showChainNumbers && analysis.longestChainIds.length > 0) {
      analysis.longestChainIds.forEach((id, idx) => {
        map[id] = idx + 1;
      });
    }
    return map;
  }, [showChainNumbers, analysis.longestChainIds]);

  const golonganColor = (gol: 'alkana' | 'alkena' | 'alkuna') => {
    if (gol === 'alkana') return '#5EEAD4';
    if (gol === 'alkena') return '#B4A7FF';
    return '#FFA8C5';
  };

  return (
    <div className="space-y-6">
      {/* Top Mode & Progress Bar */}
      <div className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-1.5 p-1 bg-[#0F0B2A] border border-[#3A3280] rounded-xl w-full sm:w-fit">
          <button
            onClick={() => handleSwitchGameMode('challenge')}
            className={`px-3.5 py-2.5 sm:py-2 rounded-lg text-xs sm:text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-2 ${
              gameMode === 'challenge'
                ? 'bg-[#1E1850] text-[#5EEAD4] border border-[#5EEAD4]/40'
                : 'text-[#B8B5DE] hover:text-[#EEEDFB]'
            }`}
          >
            <FlaskConical className="w-4 h-4 shrink-0" />
            <span>Mode Tantangan (10 Soal)</span>
          </button>
          <button
            onClick={() => handleSwitchGameMode('sandbox')}
            className={`px-3.5 py-2.5 sm:py-2 rounded-lg text-xs sm:text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-2 ${
              gameMode === 'sandbox'
                ? 'bg-[#1E1850] text-[#B4A7FF] border border-[#B4A7FF]/40'
                : 'text-[#B8B5DE] hover:text-[#EEEDFB]'
            }`}
          >
            <Compass className="w-4 h-4 shrink-0" />
            <span>Eksplorasi Bebas</span>
          </button>
        </div>

        {gameMode === 'challenge' ? (
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs sm:text-sm text-[#B8B5DE]">
            <span className="tabular-nums">
              Terselesaikan:{' '}
              <strong className="text-[#5EEAD4]">
                {solvedIds.length} / {STRUCTURE_CHALLENGES.length}
              </strong>
            </span>
            {activeChallenge.id !== 'chal-10' && (
              <button
                onClick={() => handleSelectChallenge('chal-10')}
                className="px-3 py-1.5 rounded-lg bg-[#150F38] hover:bg-[#251E60] border border-[#A99CFF]/50 text-xs font-semibold text-[#A99CFF] transition-colors cursor-pointer whitespace-nowrap"
              >
                Coba: 3-etil-4,5-dimetilheksana
              </button>
            )}
          </div>
        ) : (
          <div className="text-xs sm:text-sm text-[#B8B5DE]">
            Rangkai molekul hidrokarbon sesukamu untuk melihat rumus & posisi atom C secara langsung.
          </div>
        )}
      </div>

      {/* Challenge Selector Strip (only in Challenge Mode) */}
      {gameMode === 'challenge' && (
        <div className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-[#B8B5DE] flex items-center gap-2">
              <Layers className="w-3.5 h-3.5 text-[#5EEAD4]" />
              <span>Pilih Soal Susun Struktur:</span>
            </span>
            <span className="text-xs text-[#8E8BB5] tabular-nums">
              Soal {activeChallenge.level} dari {STRUCTURE_CHALLENGES.length}
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
            {STRUCTURE_CHALLENGES.map((chal) => {
              const isActive = chal.id === activeChallenge.id;
              const isSolved = solvedIds.includes(chal.id);
              return (
                <button
                  key={chal.id}
                  onClick={() => handleSelectChallenge(chal.id)}
                  className={`px-3 py-2 rounded-xl border text-xs font-semibold whitespace-nowrap shrink-0 transition-all cursor-pointer flex items-center gap-2 ${
                    isActive
                      ? 'bg-[#150F38] border-[#5EEAD4] text-[#EEEDFB]'
                      : isSolved
                      ? 'bg-[#5EEAD4]/10 border-[#5EEAD4]/40 text-[#5EEAD4] hover:bg-[#5EEAD4]/15'
                      : 'bg-[#0F0B2A] border-[#3A3280] text-[#B8B5DE] hover:text-[#EEEDFB] hover:border-[#8E8BB5]'
                  }`}
                >
                  <span className="font-mono tabular-nums text-[11px] opacity-80">
                    #{chal.level}
                  </span>
                  <span>{chal.namaIUPAC}</span>
                  {isSolved && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#5EEAD4] shrink-0" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* MAIN TWO-ZONE SANDBOX LAYOUT */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT ZONE (60%+): INTERACTIVE MOLECULAR CANVAS */}
        <div className="lg:col-span-7 xl:col-span-8 bg-[#1E1850] border border-[#3A3280] rounded-2xl p-4 sm:p-6 space-y-4">
          {/* Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#3A3280]">
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => setToolMode('bond-1')}
                className={`px-3 py-2 rounded-xl border text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 min-h-[40px] whitespace-nowrap ${
                  toolMode === 'bond-1'
                    ? 'bg-[#5EEAD4] text-[#0F0B2A] border-[#5EEAD4] font-bold'
                    : 'bg-[#0F0B2A] text-[#EEEDFB] border-[#3A3280] hover:border-[#5EEAD4]/60'
                }`}
              >
                <span className="font-mono font-bold text-sm leading-none">—</span>
                <span>Tunggal</span>
              </button>

              <button
                onClick={() => setToolMode('bond-2')}
                className={`px-3 py-2 rounded-xl border text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 min-h-[40px] whitespace-nowrap ${
                  toolMode === 'bond-2'
                    ? 'bg-[#B4A7FF] text-[#0F0B2A] border-[#B4A7FF] font-bold'
                    : 'bg-[#0F0B2A] text-[#EEEDFB] border-[#3A3280] hover:border-[#B4A7FF]/60'
                }`}
              >
                <span className="font-mono font-bold text-sm leading-none">=</span>
                <span>Rangkap 2</span>
              </button>

              <button
                onClick={() => setToolMode('bond-3')}
                className={`px-3 py-2 rounded-xl border text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 min-h-[40px] whitespace-nowrap ${
                  toolMode === 'bond-3'
                    ? 'bg-[#FFA8C5] text-[#0F0B2A] border-[#FFA8C5] font-bold'
                    : 'bg-[#0F0B2A] text-[#EEEDFB] border-[#3A3280] hover:border-[#FFA8C5]/60'
                }`}
              >
                <span className="font-mono font-bold text-sm leading-none">≡</span>
                <span>Rangkap 3</span>
              </button>

              <button
                onClick={() => setToolMode('erase')}
                className={`px-3 py-2 rounded-xl border text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 min-h-[40px] whitespace-nowrap ${
                  toolMode === 'erase'
                    ? 'bg-[#FFA8C5]/20 text-[#FFA8C5] border-[#FFA8C5]'
                    : 'bg-[#0F0B2A] text-[#B8B5DE] border-[#3A3280] hover:text-[#FFA8C5]'
                }`}
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Hapus</span>
              </button>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setShowChainNumbers((prev) => !prev)}
                className={`px-2.5 py-2 rounded-xl border text-xs font-semibold transition-colors cursor-pointer min-h-[40px] whitespace-nowrap ${
                  showChainNumbers
                    ? 'bg-[#150F38] border-[#FDE68A] text-[#FDE68A]'
                    : 'bg-[#0F0B2A] border-[#3A3280] text-[#B8B5DE] hover:text-[#EEEDFB]'
                }`}
                title="Tampilkan penomoran rantai terpanjang"
              >
                Nomor C
              </button>

              <button
                onClick={handleUndo}
                disabled={history.length === 0}
                className="px-2.5 py-2 rounded-xl border border-[#3A3280] bg-[#0F0B2A] text-xs font-semibold text-[#B8B5DE] hover:text-[#EEEDFB] disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer flex items-center gap-1 min-h-[40px]"
                title="Urungkan langkah terakhir"
              >
                <Undo2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Urungkan</span>
              </button>

              <button
                onClick={() => resetCanvas(true)}
                className="px-2.5 py-2 rounded-xl border border-[#3A3280] bg-[#0F0B2A] text-xs font-semibold text-[#B8B5DE] hover:text-[#EEEDFB] transition-colors cursor-pointer flex items-center gap-1 min-h-[40px]"
                title="Reset kanvas"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Reset</span>
              </button>
            </div>
          </div>

          {/* Inline Instruction / Valence Warning */}
          {valenceWarning ? (
            <div className="p-3 rounded-xl bg-[#FFA8C5]/10 border border-[#FFA8C5]/40 text-xs text-[#FFA8C5] flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{valenceWarning}</span>
            </div>
          ) : (
            <div className="text-xs text-[#B8B5DE] flex flex-wrap items-center justify-between gap-2">
              <span>
                Klik tanda <strong className="text-[#5EEAD4]">+</strong> atau kotak kosong untuk menambah atom C. Klik garis ikatan untuk mengubah jenis ikatan.
              </span>
              {isShowingKey && (
                <span className="text-[#FDE68A] font-semibold">
                  Menampilkan Kunci Struktur Referensi
                </span>
              )}
            </div>
          )}

          {/* Mobile scroll hint */}
          <div className="sm:hidden text-[11px] text-[#8E8BB5] flex items-center justify-between">
            <span>Geser area kanvas ke kanan/kiri untuk menjangkau seluruh grid</span>
            <span>← →</span>
          </div>

          {/* Interactive Grid Container (horizontally scrollable on narrow mobile screens) */}
          <div className="w-full overflow-x-auto rounded-2xl bg-[#0F0B2A] border border-[#3A3280] p-2 sm:p-3">
            <div
              className="relative w-full min-w-[480px] aspect-[10/7] select-none"
              style={{
                backgroundImage:
                  'radial-gradient(circle, rgba(169, 156, 255, 0.14) 1px, transparent 1px)',
                backgroundSize: '10% 14.2857%',
              }}
            >
              {/* Layer 1: Background Clickable Grid Cells */}
              <div className="absolute inset-0 grid grid-cols-10 grid-rows-7">
                {Array.from({ length: GRID_ROWS }).map((_, r) =>
                  Array.from({ length: GRID_COLS }).map((__, c) => {
                    const key = `${r},${c}`;
                    const hasAtom = Boolean(occupiedMap[key]);
                    const isGhost = ghostNeighborKeys.has(key);

                    if (hasAtom) {
                      return <div key={key} className="pointer-events-none" />;
                    }

                    return (
                      <button
                        key={key}
                        type="button"
                        onClick={() => handleEmptyCellClick(r, c)}
                        aria-label={`Tambah atom karbon di baris ${r + 1} kolom ${c + 1}`}
                        className="group relative flex items-center justify-center cursor-pointer focus-visible:outline-2 focus-visible:outline-[#5EEAD4] rounded-lg"
                      >
                        {isGhost ? (
                          <span className="w-8 h-8 rounded-full border border-dashed border-[#5EEAD4]/60 bg-[#5EEAD4]/10 group-hover:bg-[#5EEAD4]/25 group-hover:border-[#5EEAD4] flex items-center justify-center text-[#5EEAD4] transition-all">
                            <Plus className="w-4 h-4" />
                          </span>
                        ) : (
                          <span className="w-6 h-6 rounded-full opacity-0 group-hover:opacity-100 bg-[#1E1850] border border-[#3A3280] flex items-center justify-center text-[#B8B5DE] text-[10px] font-mono transition-opacity">
                            +C
                          </span>
                        )}
                      </button>
                    );
                  })
                )}
              </div>

              {/* Layer 2: SVG Covalent Bonds */}
              <svg
                className="absolute inset-0 w-full h-full pointer-events-none"
                viewBox="0 0 1000 700"
                preserveAspectRatio="none"
              >
                {bonds.map((bond) => {
                  const a = atoms.find((at) => at.id === bond.from);
                  const b = atoms.find((at) => at.id === bond.to);
                  if (!a || !b) return null;

                  const x1 = a.col * 100 + 50;
                  const y1 = a.row * 100 + 50;
                  const x2 = b.col * 100 + 50;
                  const y2 = b.row * 100 + 50;

                  const dx = x2 - x1;
                  const dy = y2 - y1;
                  const len = Math.hypot(dx, dy) || 1;
                  // Perpendicular unit vector
                  const px = -dy / len;
                  const py = dx / len;

                  const strokeColor =
                    bond.order === 2
                      ? '#B4A7FF'
                      : bond.order === 3
                      ? '#FFA8C5'
                      : '#7E72B8';

                  const offsets =
                    bond.order === 1
                      ? [0]
                      : bond.order === 2
                      ? [-6, 6]
                      : [-9, 0, 9];

                  return (
                    <g key={bond.id} className="pointer-events-auto">
                      {/* Wide invisible click hitbox */}
                      <line
                        x1={x1}
                        y1={y1}
                        x2={x2}
                        y2={y2}
                        stroke="transparent"
                        strokeWidth="28"
                        className="cursor-pointer"
                        onClick={() => handleBondClick(bond)}
                      />
                      {/* Visible covalent bond line(s) */}
                      {offsets.map((off, idx) => (
                        <line
                          key={idx}
                          x1={x1 + px * off}
                          y1={y1 + py * off}
                          x2={x2 + px * off}
                          y2={y2 + py * off}
                          stroke={strokeColor}
                          strokeWidth={bond.order === 1 ? '4.5' : '3.5'}
                          strokeLinecap="round"
                          className="pointer-events-none"
                        />
                      ))}
                    </g>
                  );
                })}
              </svg>

              {/* Layer 3: Carbon Atom Nodes */}
              {atoms.map((atom) => {
                const info = analysis.atomInfoMap[atom.id];
                const isSelected = atom.id === selectedAtomId;
                const chainNum = chainOrderMap[atom.id];
                const inLongestChain = analysis.longestChainIds.includes(atom.id);

                let borderClass = 'border-[#5EEAD4]/60 bg-[#1E1850] text-[#EEEDFB]';
                if (!info?.isValidValence) {
                  borderClass = 'border-[#FFA8C5] bg-[#FFA8C5]/20 text-[#FFA8C5]';
                } else if (isSelected) {
                  borderClass =
                    'border-[#5EEAD4] bg-[#150F38] text-[#5EEAD4] ring-2 ring-[#5EEAD4]/50 ring-offset-2 ring-offset-[#0F0B2A] scale-105';
                } else if (validationResult?.isCorrect && inLongestChain) {
                  borderClass = 'border-[#5EEAD4] bg-[#150F38] text-[#5EEAD4]';
                } else if (validationResult?.isCorrect) {
                  borderClass = 'border-[#B4A7FF] bg-[#1E1850] text-[#B4A7FF]';
                }

                return (
                  <button
                    key={atom.id}
                    type="button"
                    onClick={() => handleAtomClick(atom)}
                    style={{
                      left: `${((atom.col + 0.5) / GRID_COLS) * 100}%`,
                      top: `${((atom.row + 0.5) / GRID_ROWS) * 100}%`,
                      transform: 'translate(-50%, -50%)',
                    }}
                    className={`absolute z-10 w-11 h-11 sm:w-12 sm:h-12 rounded-full border-2 flex flex-col items-center justify-center transition-all cursor-pointer shadow-md focus-visible:outline-2 focus-visible:outline-[#5EEAD4] ${borderClass}`}
                    aria-label={`Atom karbon ${info?.formulaLabel || 'C'}`}
                  >
                    <span className="font-mono font-bold text-xs sm:text-sm leading-none">
                      {info?.formulaLabel || 'C'}
                    </span>
                    {chainNum ? (
                      <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-[#FDE68A] text-[#0F0B2A] text-[10px] font-mono font-extrabold flex items-center justify-center shadow">
                        {chainNum}
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Live Molecular Readout (Tabular Numerals, Clean Unboxed Strip) */}
          <div className="p-3.5 sm:p-4 bg-[#0F0B2A] border border-[#3A3280] rounded-xl flex flex-wrap items-center justify-between gap-4 text-xs sm:text-sm">
            <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
              <div>
                <span className="text-[#8E8BB5] mr-1.5">Rumus Molekul:</span>
                <span className="font-mono font-bold text-[#5EEAD4] tabular-nums">
                  {analysis.formula}
                </span>
              </div>
              <div>
                <span className="text-[#8E8BB5] mr-1.5">Jumlah C:</span>
                <span className="font-mono font-bold text-[#EEEDFB] tabular-nums">
                  {analysis.atomCount}
                </span>
              </div>
              <div>
                <span className="text-[#8E8BB5] mr-1.5">Rantai Terpanjang:</span>
                <span className="font-mono font-bold text-[#B4A7FF] tabular-nums">
                  {analysis.isConnected ? `${analysis.longestChainLength} C` : 'Terpisah'}
                </span>
              </div>
              <div>
                <span className="text-[#8E8BB5] mr-1.5">Golongan:</span>
                <span className="font-semibold text-[#EEEDFB]">
                  {analysis.golonganLabel}
                </span>
              </div>
            </div>

            {gameMode === 'sandbox' && analysis.atomCount > 0 && (
              <div className="flex items-center gap-3 text-xs font-mono tabular-nums text-[#B8B5DE]">
                <span>1°: {analysis.degreeCounts.primer}</span>
                <span aria-hidden="true">·</span>
                <span>2°: {analysis.degreeCounts.sekunder}</span>
                <span aria-hidden="true">·</span>
                <span>3°: {analysis.degreeCounts.tersier}</span>
                <span aria-hidden="true">·</span>
                <span>4°: {analysis.degreeCounts.kuarterner}</span>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT ZONE (35-40%): CHALLENGE PROMPT, CONTROLS & FEEDBACK */}
        <div className="lg:col-span-5 xl:col-span-4 space-y-4">
          {gameMode === 'challenge' ? (
            <>
              {/* Challenge Prompt Card */}
              <div className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-5 sm:p-6 space-y-4">
                <div className="flex items-center justify-between text-xs text-[#B8B5DE]">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-[#5EEAD4] tabular-nums">
                      Soal {activeChallenge.level}/{STRUCTURE_CHALLENGES.length}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{activeChallenge.tingkat}</span>
                    <span aria-hidden="true">·</span>
                    <span
                      className="font-semibold uppercase"
                      style={{ color: golonganColor(activeChallenge.golongan) }}
                    >
                      {activeChallenge.golongan}
                    </span>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg sm:text-xl font-bold text-[#EEEDFB] leading-snug">
                    {activeChallenge.soalTeks}
                  </h3>
                  <p className="text-xs text-[#B8B5DE] mt-2 leading-relaxed">
                    Susun kerangka atom karbon dan ikatan kovalennya pada kanvas grid di sebelah kiri. Jumlah atom Hidrogen (H) akan dihitung otomatis.
                  </p>
                </div>

                {/* Hint Toggle */}
                <div>
                  <button
                    onClick={() => setShowHint((prev) => !prev)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#150F38] hover:bg-[#251E60] border border-[#FDE68A]/40 text-xs font-semibold text-[#FDE68A] transition-colors cursor-pointer"
                  >
                    <Lightbulb className="w-3.5 h-3.5" />
                    <span>{showHint ? 'Tutup Petunjuk' : 'Lihat Petunjuk'}</span>
                  </button>

                  {showHint && (
                    <div className="mt-3 p-3.5 bg-[#0F0B2A] border border-[#FDE68A]/40 rounded-xl text-xs text-[#FDE68A] leading-relaxed">
                      {activeChallenge.petunjuk}
                    </div>
                  )}
                </div>

                {/* Primary CTA: Check Answer */}
                <div className="pt-2 flex flex-col gap-2.5">
                  <button
                    onClick={handleCheckStructure}
                    className="w-full py-3 px-4 rounded-xl bg-[#5EEAD4] hover:bg-[#4dd6c0] text-[#0F0B2A] font-bold text-sm transition-colors cursor-pointer flex items-center justify-center gap-2 min-h-[44px]"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Periksa Struktur</span>
                  </button>

                  <button
                    onClick={handleShowReferenceKey}
                    className="w-full py-2.5 px-4 rounded-xl bg-[#0F0B2A] hover:bg-[#150F38] border border-[#3A3280] text-xs font-semibold text-[#B8B5DE] hover:text-[#EEEDFB] transition-colors cursor-pointer flex items-center justify-center gap-2 min-h-[40px]"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Tampilkan Kunci Struktur</span>
                  </button>
                </div>
              </div>

              {/* Validation Feedback Panel */}
              {validationResult && (
                <div
                  className={`rounded-2xl p-5 border space-y-3 ${
                    validationResult.isCorrect
                      ? 'bg-[#1E1850] border-[#5EEAD4]'
                      : 'bg-[#1E1850] border-[#FFA8C5]'
                  }`}
                >
                  <div
                    className={`flex items-start gap-2.5 text-sm font-bold ${
                      validationResult.isCorrect
                        ? 'text-[#5EEAD4]'
                        : 'text-[#FFA8C5]'
                    }`}
                  >
                    {validationResult.isCorrect ? (
                      <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 shrink-0 mt-0.5" />
                    )}
                    <span>{validationResult.headline}</span>
                  </div>

                  <ul className="space-y-1.5 text-xs text-[#EEEDFB] leading-relaxed">
                    {validationResult.diagnostics.map((d, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-[#8E8BB5] mt-0.5">•</span>
                        <span>{d}</span>
                      </li>
                    ))}
                  </ul>

                  {validationResult.isCorrect && (
                    <div className="pt-3 border-t border-[#3A3280] space-y-3">
                      <div className="text-xs text-[#B8B5DE] whitespace-pre-line leading-relaxed">
                        {activeChallenge.pembahasan}
                      </div>
                      {activeChallenge.catatanTambahan && (
                        <div className="p-3 rounded-xl bg-[#0F0B2A] border border-[#3A3280] text-[11px] text-[#FDE68A] leading-relaxed">
                          {activeChallenge.catatanTambahan}
                        </div>
                      )}
                      <button
                        onClick={handleNextChallenge}
                        className="w-full py-2.5 px-4 rounded-xl bg-[#A99CFF] hover:bg-[#9889FC] text-[#0F0B2A] font-bold text-xs sm:text-sm transition-colors cursor-pointer flex items-center justify-center gap-2 min-h-[42px]"
                      >
                        <span>Lanjut ke Tantangan Berikutnya</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Key Shown Explanation Panel */}
              {isShowingKey && !validationResult && (
                <div className="bg-[#1E1850] border border-[#FDE68A]/50 rounded-2xl p-5 space-y-3">
                  <div className="text-sm font-bold text-[#FDE68A] flex items-center gap-2">
                    <Eye className="w-4 h-4 shrink-0" />
                    <span>Kunci Struktur: {activeChallenge.namaIUPAC}</span>
                  </div>
                  <div className="text-xs text-[#EEEDFB] whitespace-pre-line leading-relaxed">
                    {activeChallenge.pembahasan}
                  </div>
                  {activeChallenge.catatanTambahan && (
                    <div className="p-3 rounded-xl bg-[#0F0B2A] border border-[#3A3280] text-[11px] text-[#FDE68A] leading-relaxed">
                      {activeChallenge.catatanTambahan}
                    </div>
                  )}
                  <button
                    onClick={() => resetCanvas(true)}
                    className="w-full py-2.5 px-4 rounded-xl bg-[#5EEAD4] hover:bg-[#4dd6c0] text-[#0F0B2A] font-bold text-xs transition-colors cursor-pointer"
                  >
                    Coba Susun Ulang Sendiri
                  </button>
                </div>
              )}
            </>
          ) : (
            /* SANDBOX INFO DECK */
            <div className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-5 sm:p-6 space-y-4">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#B4A7FF]">
                <Compass className="w-4 h-4" />
                <span>Laboratorium Molekul Bebas</span>
              </div>
              <h3 className="text-lg font-bold text-[#EEEDFB]">
                Eksplorasi Struktur Hidrokarbon
              </h3>
              <p className="text-xs sm:text-sm text-[#B8B5DE] leading-relaxed">
                Bangun rantai karbon lurus, bercabang, atau ikatan rangkap secara bebas. Sistem menghitung otomatis jumlah atom H sesuai aturan oktet (4 ikatan per atom C) dan mengklasifikasikan posisinya.
              </p>

              <div className="p-4 bg-[#0F0B2A] border border-[#3A3280] rounded-xl space-y-2.5 text-xs">
                <div className="font-bold text-[#EEEDFB] flex items-center gap-1.5">
                  <HelpCircle className="w-3.5 h-3.5 text-[#5EEAD4]" />
                  <span>Analisis Struktur Saat Ini:</span>
                </div>
                <div className="flex justify-between text-[#B8B5DE]">
                  <span>Rumus Molekul:</span>
                  <span className="font-mono font-bold text-[#5EEAD4] tabular-nums">
                    {analysis.formula}
                  </span>
                </div>
                <div className="flex justify-between text-[#B8B5DE]">
                  <span>Golongan Senyawa:</span>
                  <span className="font-semibold text-[#EEEDFB]">
                    {analysis.golonganLabel}
                  </span>
                </div>
                <div className="flex justify-between text-[#B8B5DE]">
                  <span>Rantai Utama Terpanjang:</span>
                  <span className="font-mono font-bold text-[#B4A7FF] tabular-nums">
                    {analysis.isConnected ? `${analysis.longestChainLength} atom C` : 'Belum utuh'}
                  </span>
                </div>
                <div className="pt-2 border-t border-[#3A3280] grid grid-cols-2 gap-2 font-mono tabular-nums">
                  <div className="text-[#5EEAD4]">Primer (1°): {analysis.degreeCounts.primer}</div>
                  <div className="text-[#B4A7FF]">Sekunder (2°): {analysis.degreeCounts.sekunder}</div>
                  <div className="text-[#FFA8C5]">Tersier (3°): {analysis.degreeCounts.tersier}</div>
                  <div className="text-[#FDE68A]">Kuarterner (4°): {analysis.degreeCounts.kuarterner}</div>
                </div>
              </div>

              <button
                onClick={() => handleSwitchGameMode('challenge')}
                className="w-full py-2.5 px-4 rounded-xl bg-[#A99CFF] hover:bg-[#9889FC] text-[#0F0B2A] font-bold text-xs sm:text-sm transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Kembali ke Mode Tantangan</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
