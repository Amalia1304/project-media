/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Permainan & Latihan Beri Nama IUPAC Struktur Senyawa Hidrokarbon
 * Fitur:
 * - Visualisasi struktur 2D gaya buku kimia SMA (rantai lurus, bercabang, berbelok, rangkap 2 & 3)
 * - Input fleksibel: ketik langsung atau susun menggunakan blok token IUPAC
 * - Deteksi kesalahan terarah (penomoran terbalik, urutan abjad cabang, awalan di-/tri-, rantai induk)
 * - Penyorotan rantai induk & nomor atom C otomatis setelah terjawab benar atau saat melihat pembahasan
 */

import React, { useState, useMemo } from 'react';
import {
  NAMING_CHALLENGES,
  NamingChallenge,
} from '../../data/namingChallenges';
import {
  CheckCircle2,
  XCircle,
  Lightbulb,
  Eye,
  ArrowRight,
  RotateCcw,
  Delete,
  Layers,
  Tag,
} from 'lucide-react';

interface NamingFeedback {
  isCorrect: boolean;
  headline: string;
  details: string[];
}

function normalizeIupacInput(raw: string): string {
  return raw
    .trim()
    .toLowerCase()
    .replace(/\s*-\s*/g, '-')
    .replace(/\s*,\s*/g, ',')
    .replace(/\s+/g, '');
}

function evaluateNamingAnswer(
  rawInput: string,
  challenge: NamingChallenge
): NamingFeedback {
  const normalized = normalizeIupacInput(rawInput);

  if (!normalized) {
    return {
      isCorrect: false,
      headline: 'Nama Senyawa Belum Diisi',
      details: [
        'Ketik nama IUPAC pada kotak jawaban atau klik blok-blok penyusun nama di bawah.',
      ],
    };
  }

  const expected = normalizeIupacInput(challenge.jawabanResmi);
  const alts = (challenge.jawabanAlternatif || []).map(normalizeIupacInput);

  if (normalized === expected || alts.includes(normalized)) {
    return {
      isCorrect: true,
      headline: `Tepat Sekali! Nama IUPAC yang benar adalah ${challenge.jawabanResmi}`,
      details: [challenge.arahPenomoran],
    };
  }

  const details: string[] = [];

  if (
    challenge.wrongDirectionTrap &&
    normalized === normalizeIupacInput(challenge.wrongDirectionTrap)
  ) {
    details.push(
      `Arah penomoran masih terbalik! Kamu menomori dari ujung yang salah. Aturan yang tepat: ${challenge.arahPenomoran}.`
    );
  }

  if (
    challenge.wrongAlphabetTrap &&
    normalized === normalizeIupacInput(challenge.wrongAlphabetTrap)
  ) {
    details.push(
      'Nomor dan nama cabangmu sudah benar, tetapi urutan penulisan cabang harus disusun secara alfabetis (abjad "etil" ditulis sebelum "metil"; awalan di-/tri- diabaikan dalam abjad).'
    );
  }

  if (
    challenge.missingMultiplierTrap &&
    normalized === normalizeIupacInput(challenge.missingMultiplierTrap)
  ) {
    details.push(
      'Jika terdapat lebih dari satu cabang yang sama, jangan lupa menambahkan awalan jumlah seperti "di-" (untuk 2 cabang sejenis) atau "tri-" (untuk 3 cabang sejenis).'
    );
  }

  // Check parent chain & bond suffix diagnostics
  if (details.length === 0) {
    const expectedSuffix =
      challenge.golongan === 'alkana'
        ? 'ana'
        : challenge.golongan === 'alkena'
        ? 'ena'
        : 'una';

    if (!normalized.endsWith(expectedSuffix)) {
      const labelGol =
        challenge.golongan === 'alkana'
          ? 'alkana (ikatan tunggal, akhiran -ana)'
          : challenge.golongan === 'alkena'
          ? 'alkena (ikatan rangkap dua =, akhiran -ena)'
          : 'alkuna (ikatan rangkap tiga ≡, akhiran -una)';
      details.push(
        `Perhatikan jenis ikatan pada struktur! Senyawa ini termasuk golongan ${labelGol}.`
      );
    } else if (!normalized.includes(challenge.rantaiIndukBenar)) {
      details.push(
        `Nama rantai induk belum tepat. Telusuri kembali rantai karbon terpanjang yang berkesinambungan (termasuk jika rantainya berbelok).`
      );
    } else {
      details.push(
        'Rantai induknya sudah tepat, tetapi periksa kembali nomor posisi cabang, posisi ikatan rangkap, atau tanda hubung (-) dan koma (,).'
      );
    }
  }

  return {
    isCorrect: false,
    headline: 'Nama Belum Tepat, Ayo Cek Kembali!',
    details,
  };
}

// Render SVG chemical formula label (e.g. CH3 -> CH₃)
const renderSvgFormula = (
  formula: string,
  x: number,
  y: number,
  color: string
) => {
  const match = formula.match(/^([A-Za-z]+)(\d*)$/);
  if (!match) {
    return (
      <text
        x={x}
        y={y}
        textAnchor="middle"
        fill={color}
        fontSize="16"
        fontWeight="700"
        fontFamily="JetBrains Mono, monospace"
      >
        {formula}
      </text>
    );
  }
  const [, letters, digits] = match;
  return (
    <text
      x={x}
      y={y}
      textAnchor="middle"
      fill={color}
      fontSize="16"
      fontWeight="700"
      fontFamily="JetBrains Mono, monospace"
    >
      {letters}
      {digits && (
        <tspan dy="4" fontSize="11.5" fontWeight="700">
          {digits}
        </tspan>
      )}
    </text>
  );
};

export const HydrocarbonNamingGame: React.FC = () => {
  const [activeId, setActiveId] = useState<string>(NAMING_CHALLENGES[0].id);
  const [inputValue, setInputValue] = useState<string>('');
  const [feedback, setFeedback] = useState<NamingFeedback | null>(null);
  const [showHint, setShowHint] = useState<boolean>(false);
  const [showSolution, setShowSolution] = useState<boolean>(false);

  const [solvedIds, setSolvedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('hidrokarbon_solved_naming');
      if (saved) return JSON.parse(saved);
    } catch {
      // Ignore
    }
    return [];
  });

  const challenge = useMemo(
    () =>
      NAMING_CHALLENGES.find((c) => c.id === activeId) || NAMING_CHALLENGES[0],
    [activeId]
  );

  const handleSelectChallenge = (id: string) => {
    setActiveId(id);
    setInputValue('');
    setFeedback(null);
    setShowHint(false);
    setShowSolution(false);
  };

  const handleAppendToken = (token: string) => {
    setFeedback(null);
    setInputValue((prev) => prev + token);
  };

  const handleBackspace = () => {
    setFeedback(null);
    setInputValue((prev) => prev.slice(0, -1));
  };

  const handleClear = () => {
    setFeedback(null);
    setInputValue('');
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const res = evaluateNamingAnswer(inputValue, challenge);
    setFeedback(res);
    if (res.isCorrect) {
      setShowSolution(true);
      if (!solvedIds.includes(challenge.id)) {
        const updated = [...solvedIds, challenge.id];
        setSolvedIds(updated);
        try {
          localStorage.setItem(
            'hidrokarbon_solved_naming',
            JSON.stringify(updated)
          );
        } catch {
          // Ignore
        }
      }
    }
  };

  const handleRevealSolution = () => {
    setShowSolution(true);
    setFeedback(null);
  };

  const handleNextChallenge = () => {
    const idx = NAMING_CHALLENGES.findIndex((c) => c.id === challenge.id);
    const next = NAMING_CHALLENGES[(idx + 1) % NAMING_CHALLENGES.length];
    handleSelectChallenge(next.id);
  };

  // Compute SVG bounding box dynamically from challenge nodes
  const svgMetrics = useMemo(() => {
    const maxCol = Math.max(...challenge.nodes.map((n) => n.col));
    const maxRow = Math.max(...challenge.nodes.map((n) => n.row));
    const spacingX = 96;
    const spacingY = 66;
    const padX = 70;
    const padY = 56;
    const width = padX * 2 + maxCol * spacingX;
    const height = padY * 2 + maxRow * spacingY;
    return { spacingX, spacingY, padX, padY, width, height };
  }, [challenge]);

  const highlightActive = showSolution || Boolean(feedback?.isCorrect);

  const golonganColor =
    challenge.golongan === 'alkana'
      ? '#5EEAD4'
      : challenge.golongan === 'alkena'
      ? '#B4A7FF'
      : '#FFA8C5';

  return (
    <div className="space-y-6">
      {/* Top Progress & Challenge Strip */}
      <div className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs sm:text-sm">
          <span className="font-semibold text-[#B8B5DE] flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#B4A7FF]" />
            <span>Pilih Soal Beri Nama Senyawa:</span>
          </span>
          <span className="text-[#B8B5DE] tabular-nums">
            Terselesaikan:{' '}
            <strong className="text-[#5EEAD4]">
              {solvedIds.length} / {NAMING_CHALLENGES.length}
            </strong>
          </span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          {NAMING_CHALLENGES.map((item) => {
            const isActive = item.id === challenge.id;
            const isSolved = solvedIds.includes(item.id);
            return (
              <button
                key={item.id}
                onClick={() => handleSelectChallenge(item.id)}
                className={`px-3 py-2 rounded-xl border text-xs font-semibold whitespace-nowrap shrink-0 transition-all cursor-pointer flex items-center gap-2 ${
                  isActive
                    ? 'bg-[#150F38] border-[#B4A7FF] text-[#EEEDFB]'
                    : isSolved
                    ? 'bg-[#5EEAD4]/10 border-[#5EEAD4]/40 text-[#5EEAD4] hover:bg-[#5EEAD4]/15'
                    : 'bg-[#0F0B2A] border-[#3A3280] text-[#B8B5DE] hover:text-[#EEEDFB] hover:border-[#8E8BB5]'
                }`}
              >
                <span className="font-mono tabular-nums">#{item.level}</span>
                <span className="capitalize">
                  {isSolved ? item.jawabanResmi : item.golongan}
                </span>
                {isSolved && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#5EEAD4] shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Two-Zone Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT ZONE: 2D STRUCTURAL DIAGRAM */}
        <div className="lg:col-span-7 bg-[#1E1850] border border-[#3A3280] rounded-2xl p-5 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs text-[#B8B5DE]">
              <span className="font-mono font-bold text-[#B4A7FF] tabular-nums">
                Soal {challenge.level}/{NAMING_CHALLENGES.length}
              </span>
              <span aria-hidden="true">·</span>
              <span>{challenge.tingkat}</span>
              <span aria-hidden="true">·</span>
              <span
                className="font-semibold uppercase"
                style={{ color: golonganColor }}
              >
                {challenge.golongan}
              </span>
            </div>

            <span className="text-xs text-[#8E8BB5]">
              {highlightActive
                ? 'Rantai induk & penomoran ditampilkan'
                : 'Tentukan rantai induk terpanjang & arah penomorannya'}
            </span>
          </div>

          <h2 className="text-lg sm:text-xl font-bold text-[#EEEDFB]">
            Tentukan Nama IUPAC dari Struktur Berikut:
          </h2>

          {/* SVG Structure Stage */}
          <div className="w-full overflow-x-auto bg-[#0F0B2A] border border-[#3A3280] rounded-2xl p-4">
            <svg
              viewBox={`0 0 ${svgMetrics.width} ${svgMetrics.height}`}
              className="w-full h-auto select-none mx-auto block"
              style={{ maxWidth: `${Math.max(440, svgMetrics.width)}px` }}
              role="img"
              aria-label={`Diagram struktur senyawa hidrokarbon soal nomor ${challenge.level}`}
            >
              {/* Bonds */}
              {challenge.bonds.map((bond, idx) => {
                const a = challenge.nodes.find((n) => n.id === bond.from);
                const b = challenge.nodes.find((n) => n.id === bond.to);
                if (!a || !b) return null;

                const ax = svgMetrics.padX + a.col * svgMetrics.spacingX;
                const ay = svgMetrics.padY + a.row * svgMetrics.spacingY;
                const bx = svgMetrics.padX + b.col * svgMetrics.spacingX;
                const by = svgMetrics.padY + b.row * svgMetrics.spacingY;

                const dx = bx - ax;
                const dy = by - ay;
                const len = Math.hypot(dx, dy) || 1;
                const ux = dx / len;
                const uy = dy / len;
                const px = -uy;
                const py = ux;

                // Trim endpoints slightly so lines don't overlap text labels
                const trim = 22;
                const x1 = ax + ux * trim;
                const y1 = ay + uy * trim;
                const x2 = bx - ux * trim;
                const y2 = by - uy * trim;

                const isMainBond = a.isMainChain && b.isMainChain;
                const strokeColor = highlightActive
                  ? isMainBond
                    ? '#5EEAD4'
                    : '#FFA8C5'
                  : bond.order === 2
                  ? '#B4A7FF'
                  : bond.order === 3
                  ? '#FFA8C5'
                  : '#948EC7';

                const offsets =
                  bond.order === 1
                    ? [0]
                    : bond.order === 2
                    ? [-4.5, 4.5]
                    : [-6.5, 0, 6.5];

                return (
                  <g key={`bond-${idx}`}>
                    {offsets.map((off, oIdx) => (
                      <line
                        key={oIdx}
                        x1={x1 + px * off}
                        y1={y1 + py * off}
                        x2={x2 + px * off}
                        y2={y2 + py * off}
                        stroke={strokeColor}
                        strokeWidth={bond.order === 1 ? '2.8' : '2.4'}
                        strokeLinecap="round"
                      />
                    ))}
                  </g>
                );
              })}

              {/* Nodes */}
              {challenge.nodes.map((node) => {
                const cx = svgMetrics.padX + node.col * svgMetrics.spacingX;
                const cy = svgMetrics.padY + node.row * svgMetrics.spacingY;

                const textColor = highlightActive
                  ? node.isMainChain
                    ? '#5EEAD4'
                    : '#FFA8C5'
                  : '#EEEDFB';

                return (
                  <g key={node.id}>
                    {renderSvgFormula(node.formula, cx, cy + 5, textColor)}

                    {/* Reveal Carbon numbering badge after answer / solution */}
                    {highlightActive && node.chainNum && (
                      <g>
                        <circle
                          cx={cx + 22}
                          cy={cy - 18}
                          r="10"
                          fill="#1E1850"
                          stroke="#FDE68A"
                          strokeWidth="1.5"
                        />
                        <text
                          x={cx + 22}
                          y={cy - 14.5}
                          textAnchor="middle"
                          fill="#FDE68A"
                          fontSize="10.5"
                          fontWeight="800"
                          fontFamily="JetBrains Mono, monospace"
                        >
                          {node.chainNum}
                        </text>
                      </g>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>

          {highlightActive && (
            <div className="p-3.5 rounded-xl bg-[#0F0B2A] border border-[#3A3280] flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex flex-wrap items-center gap-4 text-[#B8B5DE]">
                <span className="inline-flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#5EEAD4] inline-block" />
                  <span>Rantai induk ({challenge.rantaiIndukBenar})</span>
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#FFA8C5] inline-block" />
                  <span>Cabang alkil</span>
                </span>
              </div>
              <span className="text-[#FDE68A] font-medium">
                {challenge.arahPenomoran}
              </span>
            </div>
          )}
        </div>

        {/* RIGHT ZONE: NAME BUILDER & VALIDATION */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-5 sm:p-6 space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#B4A7FF]">
              <Tag className="w-4 h-4" />
              <span>Susun atau Ketik Nama IUPAC</span>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label
                  htmlFor="iupac-name-input"
                  className="block text-xs text-[#B8B5DE] mb-1.5"
                >
                  Jawaban Nama Senyawa:
                </label>
                <input
                  id="iupac-name-input"
                  type="text"
                  value={inputValue}
                  onChange={(e) => {
                    setInputValue(e.target.value);
                    setFeedback(null);
                  }}
                  placeholder="Contoh: 3-etil-2-metilpentana"
                  autoComplete="off"
                  className="w-full px-4 py-3 rounded-xl bg-[#0F0B2A] border border-[#3A3280] focus:border-[#5EEAD4] focus:outline-none text-sm sm:text-base font-mono font-bold text-[#EEEDFB] placeholder:text-[#8E8BB5]/60"
                />
              </div>

              {/* Token Builder Chips */}
              <div className="p-3.5 bg-[#0F0B2A] border border-[#3A3280] rounded-xl space-y-3">
                <div className="flex items-center justify-between text-[11px] text-[#B8B5DE]">
                  <span className="font-semibold">Blok Penyusun Cepat:</span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleBackspace}
                      disabled={!inputValue}
                      className="inline-flex items-center gap-1 text-[#B8B5DE] hover:text-[#EEEDFB] disabled:opacity-40 cursor-pointer"
                    >
                      <Delete className="w-3.5 h-3.5" />
                      <span>Hapus 1</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleClear}
                      disabled={!inputValue}
                      className="inline-flex items-center gap-1 text-[#FFA8C5] hover:underline disabled:opacity-40 cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Bersihkan</span>
                    </button>
                  </div>
                </div>

                {/* Numbers & Punctuation */}
                <div className="flex flex-wrap gap-1.5">
                  {challenge.tokenBank.angka.map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => handleAppendToken(num)}
                      className="min-w-[34px] h-[34px] px-2.5 rounded-lg bg-[#1E1850] hover:bg-[#251E60] border border-[#3A3280] text-xs font-mono font-bold text-[#FDE68A] cursor-pointer transition-colors"
                    >
                      {num}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => handleAppendToken('-')}
                    className="min-w-[34px] h-[34px] px-2.5 rounded-lg bg-[#1E1850] hover:bg-[#251E60] border border-[#3A3280] text-xs font-mono font-bold text-[#EEEDFB] cursor-pointer transition-colors"
                    title="Tanda hubung (-)"
                  >
                    -
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAppendToken(',')}
                    className="min-w-[34px] h-[34px] px-2.5 rounded-lg bg-[#1E1850] hover:bg-[#251E60] border border-[#3A3280] text-xs font-mono font-bold text-[#EEEDFB] cursor-pointer transition-colors"
                    title="Tanda koma (,)"
                  >
                    ,
                  </button>
                </div>

                {/* Substituents */}
                <div className="flex flex-wrap gap-1.5">
                  {challenge.tokenBank.cabang.map((cab) => (
                    <button
                      key={cab}
                      type="button"
                      onClick={() => handleAppendToken(cab)}
                      className="px-3 py-1.5 rounded-lg bg-[#1E1850] hover:bg-[#251E60] border border-[#FFA8C5]/40 text-xs font-mono font-semibold text-[#FFA8C5] cursor-pointer transition-colors"
                    >
                      {cab}
                    </button>
                  ))}
                </div>

                {/* Parent Chains */}
                <div className="flex flex-wrap gap-1.5">
                  {challenge.tokenBank.induk.map((ind) => (
                    <button
                      key={ind}
                      type="button"
                      onClick={() => handleAppendToken(ind)}
                      className="px-3 py-1.5 rounded-lg bg-[#1E1850] hover:bg-[#251E60] border border-[#5EEAD4]/40 text-xs font-mono font-semibold text-[#5EEAD4] cursor-pointer transition-colors"
                    >
                      {ind}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-[#B4A7FF] hover:bg-[#a192fc] text-[#0F0B2A] font-bold text-sm transition-colors cursor-pointer flex items-center justify-center gap-2 min-h-[44px]"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Periksa Nama IUPAC</span>
              </button>
            </form>

            {/* Hint & Reveal Solution Controls */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowHint((prev) => !prev)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#150F38] hover:bg-[#251E60] border border-[#FDE68A]/40 text-xs font-semibold text-[#FDE68A] transition-colors cursor-pointer"
              >
                <Lightbulb className="w-3.5 h-3.5" />
                <span>{showHint ? 'Tutup Petunjuk' : 'Lihat Petunjuk'}</span>
              </button>

              <button
                type="button"
                onClick={handleRevealSolution}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0F0B2A] hover:bg-[#150F38] border border-[#3A3280] text-xs font-semibold text-[#B8B5DE] hover:text-[#EEEDFB] transition-colors cursor-pointer"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Lihat Pembahasan</span>
              </button>
            </div>

            {showHint && (
              <div className="p-3.5 bg-[#0F0B2A] border border-[#FDE68A]/40 rounded-xl text-xs text-[#FDE68A] leading-relaxed">
                {challenge.petunjuk}
              </div>
            )}
          </div>

          {/* Feedback / Solution Card */}
          {(feedback || showSolution) && (
            <div
              className={`rounded-2xl p-5 border space-y-3 bg-[#1E1850] ${
                feedback?.isCorrect || (!feedback && showSolution)
                  ? 'border-[#5EEAD4]'
                  : 'border-[#FFA8C5]'
              }`}
            >
              {feedback ? (
                <>
                  <div
                    className={`flex items-start gap-2.5 text-sm font-bold ${
                      feedback.isCorrect ? 'text-[#5EEAD4]' : 'text-[#FFA8C5]'
                    }`}
                  >
                    {feedback.isCorrect ? (
                      <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 shrink-0 mt-0.5" />
                    )}
                    <span>{feedback.headline}</span>
                  </div>

                  <ul className="space-y-1.5 text-xs text-[#EEEDFB] leading-relaxed">
                    {feedback.details.map((d, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-[#8E8BB5] mt-0.5">•</span>
                        <span>{d}</span>
                      </li>
                    ))}
                  </ul>
                </>
              ) : (
                <div className="flex items-start gap-2.5 text-sm font-bold text-[#5EEAD4]">
                  <Eye className="w-5 h-5 shrink-0 mt-0.5" />
                  <span>Jawaban Resmi: {challenge.jawabanResmi}</span>
                </div>
              )}

              {(feedback?.isCorrect || showSolution) && (
                <div className="pt-3 border-t border-[#3A3280] space-y-3">
                  <div className="text-xs text-[#B8B5DE] whitespace-pre-line leading-relaxed">
                    {challenge.pembahasan}
                  </div>
                  <button
                    type="button"
                    onClick={handleNextChallenge}
                    className="w-full py-2.5 px-4 rounded-xl bg-[#5EEAD4] hover:bg-[#4dd6c0] text-[#0F0B2A] font-bold text-xs sm:text-sm transition-colors cursor-pointer flex items-center justify-center gap-2 min-h-[42px]"
                  >
                    <span>Lanjut ke Soal Berikutnya</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
