/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Footer Komponen Jelajahi Dunia Hidrokarbon
 * Menampilkan identitas platform dan atribusi pengembang.
 */

import React from 'react';
import { NavTab } from './Navbar';

interface FooterProps {
  currentTab?: NavTab;
  onNavigateTab?: (tab: NavTab) => void;
}

export const Footer: React.FC<FooterProps> = () => {
  return (
    <footer className="w-full bg-[#0F0B2A] border-t border-[#3A3280]/60 mt-12 sm:mt-16 pt-8 pb-[calc(5.5rem+env(safe-area-inset-bottom,0px))] lg:pb-8 px-4 sm:px-6">
      <div className="max-w-5xl mx-auto flex flex-col items-center justify-center gap-1.5 text-center">
        <div className="text-xs font-bold text-[#EEEDFB]">
          Jelajahi Dunia Hidrokarbon
        </div>
        <p className="text-xs text-[#B8B5DE] tracking-wide">
          Dikembangkan oleh Tim Mahasiswa Pendidikan Kimia Universitas Negeri Malang
        </p>
      </div>
    </footer>
  );
};
