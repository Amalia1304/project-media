/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Diagram SVG Mekanisme Reaksi Hidrokarbon (Sub-Bab 3.2 & 3.3)
 * Memvisualisasikan kondisi awal, pemutusan/penataan ikatan, dan produk akhir
 * untuk Pembakaran, Substitusi, Eliminasi, Adisi Alkena, Adisi Alkuna, dan Markovnikov.
 */

import React from 'react';

interface ReaksiDiagramSvgProps {
  reaksiId: string;
  tahap: number; // 1 | 2 | 3
}

const C_FILL = '#150F38';
const C_STROKE = '#5EEAD4';
const H_STROKE = '#B4A7FF';
const BREAK_COLOR = '#FFA8C5';
const NEW_COLOR = '#FDE68A';
const TEXT_LIGHT = '#EEEDFB';
const TEXT_MUTED = '#B8B5DE';

const AtomCircle: React.FC<{
  cx: number;
  cy: number;
  label: string;
  r?: number;
  stroke?: string;
  fill?: string;
  textColor?: string;
  subLabel?: string;
}> = ({
  cx,
  cy,
  label,
  r = 22,
  stroke = C_STROKE,
  fill = C_FILL,
  textColor = TEXT_LIGHT,
  subLabel,
}) => (
  <g>
    <circle
      cx={cx}
      cy={cy}
      r={r}
      fill={fill}
      stroke={stroke}
      strokeWidth="2.5"
    />
    <text
      x={cx}
      y={cy + 4.5}
      textAnchor="middle"
      fill={textColor}
      fontSize={label.length > 3 ? '10.5' : label.length > 2 ? '11.5' : '13'}
      fontWeight="700"
      fontFamily="JetBrains Mono, monospace"
    >
      {label}
    </text>
    {subLabel && (
      <text
        x={cx}
        y={cy + r + 15}
        textAnchor="middle"
        fill={TEXT_MUTED}
        fontSize="10"
        fontWeight="600"
        fontFamily="Nunito, sans-serif"
      >
        {subLabel}
      </text>
    )}
  </g>
);

const BondLine: React.FC<{
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  order?: 1 | 2 | 3;
  color?: string;
  dashed?: boolean;
}> = ({ x1, y1, x2, y2, order = 1, color = C_STROKE, dashed = false }) => {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  const offsets =
    order === 1 ? [0] : order === 2 ? [-4, 4] : [-5.5, 0, 5.5];

  return (
    <g>
      {offsets.map((off, idx) => (
        <line
          key={idx}
          x1={x1 + nx * off}
          y1={y1 + ny * off}
          x2={x2 + nx * off}
          y2={y2 + ny * off}
          stroke={color}
          strokeWidth={order === 1 ? 3 : 2.4}
          strokeLinecap="round"
          strokeDasharray={dashed ? '5 4' : undefined}
        />
      ))}
    </g>
  );
};

export const ReaksiDiagramSvg: React.FC<ReaksiDiagramSvgProps> = ({
  reaksiId,
  tahap,
}) => {
  return (
    <div className="w-full space-y-3">
      <div className="w-full overflow-x-auto bg-[#0F0B2A] border border-[#3A3280] rounded-xl p-3 sm:p-4">
        <svg
          viewBox="0 0 600 225"
          className="w-full max-w-[600px] h-auto mx-auto block select-none"
          role="img"
          aria-label={`Diagram mekanisme ${reaksiId} tahap ${tahap}`}
        >
          <defs>
            <marker
              id="arrow-gold"
              markerWidth="8"
              markerHeight="8"
              refX="6"
              refY="3"
              orient="auto"
            >
              <path d="M0,0 L0,6 L7,3 z" fill={NEW_COLOR} />
            </marker>
            <marker
              id="arrow-pink"
              markerWidth="8"
              markerHeight="8"
              refX="6"
              refY="3"
              orient="auto"
            >
              <path d="M0,0 L0,6 L7,3 z" fill={BREAK_COLOR} />
            </marker>
            <marker
              id="arrow-mint"
              markerWidth="8"
              markerHeight="8"
              refX="6"
              refY="3"
              orient="auto"
            >
              <path d="M0,0 L0,6 L7,3 z" fill={C_STROKE} />
            </marker>
          </defs>

          {/* ============================================================== */}
          {/* A. PEMBAKARAN SEMPURNA: CH4 + 2 O2 -> CO2 + 2 H2O              */}
          {/* ============================================================== */}
          {reaksiId === 'rx-pembakaran' && tahap === 1 && (
            <g>
              <text x="150" y="24" textAnchor="middle" fill={C_STROKE} fontSize="11.5" fontWeight="700">
                Metana (CH₄)
              </text>
              <BondLine x1={150} y1={115} x2={150} y2={58} color={C_STROKE} />
              <BondLine x1={150} y1={115} x2={150} y2={172} color={C_STROKE} />
              <BondLine x1={150} y1={115} x2={93} y2={115} color={C_STROKE} />
              <BondLine x1={150} y1={115} x2={207} y2={115} color={C_STROKE} />
              <AtomCircle cx={150} cy={115} label="C" r={22} />
              <AtomCircle cx={150} cy={58} label="H" r={15} stroke={H_STROKE} />
              <AtomCircle cx={150} cy={172} label="H" r={15} stroke={H_STROKE} />
              <AtomCircle cx={93} cy={115} label="H" r={15} stroke={H_STROKE} />
              <AtomCircle cx={207} cy={115} label="H" r={15} stroke={H_STROKE} />

              <text x="275" y="121" textAnchor="middle" fill={TEXT_LIGHT} fontSize="22" fontWeight="700">
                +
              </text>

              <text x="430" y="24" textAnchor="middle" fill={NEW_COLOR} fontSize="11.5" fontWeight="700">
                2 Molekul Oksigen (2 O₂)
              </text>
              <BondLine x1={380} y1={82} x2={480} y2={82} order={2} color={NEW_COLOR} />
              <AtomCircle cx={380} cy={82} label="O" r={19} stroke={NEW_COLOR} />
              <AtomCircle cx={480} cy={82} label="O" r={19} stroke={NEW_COLOR} />

              <BondLine x1={380} y1={152} x2={480} y2={152} order={2} color={NEW_COLOR} />
              <AtomCircle cx={380} cy={152} label="O" r={19} stroke={NEW_COLOR} />
              <AtomCircle cx={480} cy={152} label="O" r={19} stroke={NEW_COLOR} />

              <text x="300" y="212" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                Semua ikatan awal masih utuh sebelum terkena percikan api / panas
              </text>
            </g>
          )}

          {reaksiId === 'rx-pembakaran' && tahap === 2 && (
            <g>
              <text x="300" y="24" textAnchor="middle" fill={BREAK_COLOR} fontSize="12" fontWeight="700">
                Energi Panas Memutus 4 Ikatan C—H dan 2 Ikatan O=O
              </text>

              {/* Breaking CH4 */}
              <BondLine x1={150} y1={115} x2={150} y2={58} color={BREAK_COLOR} dashed />
              <BondLine x1={150} y1={115} x2={150} y2={172} color={BREAK_COLOR} dashed />
              <BondLine x1={150} y1={115} x2={93} y2={115} color={BREAK_COLOR} dashed />
              <BondLine x1={150} y1={115} x2={207} y2={115} color={BREAK_COLOR} dashed />
              <AtomCircle cx={150} cy={115} label="C" r={22} stroke={BREAK_COLOR} />
              <AtomCircle cx={150} cy={58} label="H" r={15} stroke={BREAK_COLOR} />
              <AtomCircle cx={150} cy={172} label="H" r={15} stroke={BREAK_COLOR} />
              <AtomCircle cx={93} cy={115} label="H" r={15} stroke={BREAK_COLOR} />
              <AtomCircle cx={207} cy={115} label="H" r={15} stroke={BREAK_COLOR} />

              <text x="150" y="88" textAnchor="middle" fill={BREAK_COLOR} fontSize="11" fontWeight="700">✂</text>
              <text x="122" y="119" textAnchor="middle" fill={BREAK_COLOR} fontSize="11" fontWeight="700">✂</text>

              {/* Breaking 2 O2 */}
              <BondLine x1={380} y1={82} x2={480} y2={82} order={2} color={BREAK_COLOR} dashed />
              <AtomCircle cx={380} cy={82} label="O" r={19} stroke={BREAK_COLOR} />
              <AtomCircle cx={480} cy={82} label="O" r={19} stroke={BREAK_COLOR} />
              <text x="430" y="72" textAnchor="middle" fill={BREAK_COLOR} fontSize="11" fontWeight="700">✂ Putus</text>

              <BondLine x1={380} y1={152} x2={480} y2={152} order={2} color={BREAK_COLOR} dashed />
              <AtomCircle cx={380} cy={152} label="O" r={19} stroke={BREAK_COLOR} />
              <AtomCircle cx={480} cy={152} label="O" r={19} stroke={BREAK_COLOR} />
              <text x="430" y="142" textAnchor="middle" fill={BREAK_COLOR} fontSize="11" fontWeight="700">✂ Putus</text>

              <text x="300" y="212" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                Atom C, H, dan O terpisah sementara lalu segera bergabung membentuk molekul baru
              </text>
            </g>
          )}

          {reaksiId === 'rx-pembakaran' && tahap === 3 && (
            <g>
              <text x="155" y="28" textAnchor="middle" fill={C_STROKE} fontSize="11.5" fontWeight="700">
                Karbon Dioksida (CO₂)
              </text>
              <BondLine x1={85} y1={108} x2={155} y2={108} order={2} color={NEW_COLOR} />
              <BondLine x1={155} y1={108} x2={225} y2={108} order={2} color={NEW_COLOR} />
              <AtomCircle cx={85} cy={108} label="O" r={19} stroke={NEW_COLOR} />
              <AtomCircle cx={155} cy={108} label="C" r={22} stroke={C_STROKE} />
              <AtomCircle cx={225} cy={108} label="O" r={19} stroke={NEW_COLOR} />

              <text x="275" y="114" textAnchor="middle" fill={TEXT_LIGHT} fontSize="22" fontWeight="700">
                +
              </text>

              <text x="430" y="28" textAnchor="middle" fill={H_STROKE} fontSize="11.5" fontWeight="700">
                2 Molekul Air (2 H₂O)
              </text>
              {/* Water 1 */}
              <BondLine x1={380} y1={80} x2={430} y2={80} color={NEW_COLOR} />
              <BondLine x1={430} y1={80} x2={480} y2={80} color={NEW_COLOR} />
              <AtomCircle cx={380} cy={80} label="H" r={15} stroke={H_STROKE} />
              <AtomCircle cx={430} cy={80} label="O" r={18} stroke={NEW_COLOR} />
              <AtomCircle cx={480} cy={80} label="H" r={15} stroke={H_STROKE} />

              {/* Water 2 */}
              <BondLine x1={380} y1={142} x2={430} y2={142} color={NEW_COLOR} />
              <BondLine x1={430} y1={142} x2={480} y2={142} color={NEW_COLOR} />
              <AtomCircle cx={380} cy={142} label="H" r={15} stroke={H_STROKE} />
              <AtomCircle cx={430} cy={142} label="O" r={18} stroke={NEW_COLOR} />
              <AtomCircle cx={480} cy={142} label="H" r={15} stroke={H_STROKE} />

              <rect x="190" y="176" width="220" height="28" rx="8" fill="#1E1850" stroke={NEW_COLOR} strokeOpacity="0.6" />
              <text x="300" y="194" textAnchor="middle" fill={NEW_COLOR} fontSize="11.5" fontWeight="700">
                + Energi Panas &amp; Cahaya (Eksoterm)
              </text>
            </g>
          )}

          {/* ============================================================== */}
          {/* B. SUBSTITUSI ALKANA: CH4 + Cl2 -> CH3Cl + HCl                 */}
          {/* ============================================================== */}
          {reaksiId === 'rx-substitusi' && tahap === 1 && (
            <g>
              <text x="150" y="26" textAnchor="middle" fill={C_STROKE} fontSize="11.5" fontWeight="700">
                Metana (CH₄)
              </text>
              <BondLine x1={130} y1={115} x2={215} y2={115} color={BREAK_COLOR} />
              <AtomCircle cx={130} cy={115} label="CH₃" r={25} stroke={C_STROKE} />
              <AtomCircle cx={215} cy={115} label="H" r={17} stroke={BREAK_COLOR} subLabel="Siap ditukar" />

              <text x="290" y="121" textAnchor="middle" fill={TEXT_LIGHT} fontSize="22" fontWeight="700">
                +
              </text>

              <text x="430" y="26" textAnchor="middle" fill={NEW_COLOR} fontSize="11.5" fontWeight="700">
                Gas Klorin (Cl₂) · Sinar UV
              </text>
              <BondLine x1={380} y1={115} x2={475} y2={115} color={NEW_COLOR} />
              <AtomCircle cx={380} cy={115} label="Cl" r={20} stroke={NEW_COLOR} subLabel="Masuk ke C" />
              <AtomCircle cx={475} cy={115} label="Cl" r={20} stroke={H_STROKE} subLabel="Ikat H lepas" />

              <text x="300" y="205" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                Sinar UV dibutuhkan untuk memicu pertukaran antara 1 atom H dan 1 atom Cl
              </text>
            </g>
          )}

          {reaksiId === 'rx-substitusi' && tahap === 2 && (
            <g>
              <text x="300" y="24" textAnchor="middle" fill={NEW_COLOR} fontSize="12" fontWeight="700">
                Pertukaran Posisi: Atom Cl Masuk Menggantikan Atom H
              </text>

              <BondLine x1={120} y1={122} x2={205} y2={122} color={BREAK_COLOR} dashed />
              <AtomCircle cx={120} cy={122} label="CH₃" r={25} stroke={C_STROKE} />
              <AtomCircle cx={205} cy={122} label="H" r={17} stroke={BREAK_COLOR} />
              <text x="163" y="114" textAnchor="middle" fill={BREAK_COLOR} fontSize="12" fontWeight="700">✂</text>

              <BondLine x1={380} y1={122} x2={470} y2={122} color={BREAK_COLOR} dashed />
              <AtomCircle cx={380} cy={122} label="Cl" r={20} stroke={NEW_COLOR} />
              <AtomCircle cx={470} cy={122} label="Cl" r={20} stroke={H_STROKE} />
              <text x="425" y="114" textAnchor="middle" fill={BREAK_COLOR} fontSize="12" fontWeight="700">✂</text>

              {/* Swap curved arrows */}
              <path
                d="M 380 96 C 320 45, 195 45, 138 92"
                fill="none"
                stroke={NEW_COLOR}
                strokeWidth="2.4"
                markerEnd="url(#arrow-gold)"
              />
              <text x="260" y="54" textAnchor="middle" fill={NEW_COLOR} fontSize="11" fontWeight="700">
                Cl menggantikan posisi H
              </text>

              <path
                d="M 205 144 C 275 195, 400 195, 464 148"
                fill="none"
                stroke={BREAK_COLOR}
                strokeWidth="2.4"
                markerEnd="url(#arrow-pink)"
              />
              <text x="338" y="196" textAnchor="middle" fill={BREAK_COLOR} fontSize="11" fontWeight="700">
                H lepas lalu berikatan dengan Cl sisa
              </text>
            </g>
          )}

          {reaksiId === 'rx-substitusi' && tahap === 3 && (
            <g>
              <text x="165" y="28" textAnchor="middle" fill={C_STROKE} fontSize="11.5" fontWeight="700">
                Klorometana (CH₃Cl)
              </text>
              <BondLine x1={120} y1={115} x2={215} y2={115} color={NEW_COLOR} />
              <AtomCircle cx={120} cy={115} label="CH₃" r={25} stroke={C_STROKE} />
              <AtomCircle cx={215} cy={115} label="Cl" r={20} stroke={NEW_COLOR} subLabel="Ikatan baru" />

              <text x="295" y="121" textAnchor="middle" fill={TEXT_LIGHT} fontSize="22" fontWeight="700">
                +
              </text>

              <text x="430" y="28" textAnchor="middle" fill={H_STROKE} fontSize="11.5" fontWeight="700">
                Asam Klorida (HCl)
              </text>
              <BondLine x1={385} y1={115} x2={475} y2={115} color={NEW_COLOR} />
              <AtomCircle cx={385} cy={115} label="H" r={17} stroke={BREAK_COLOR} />
              <AtomCircle cx={475} cy={115} label="Cl" r={20} stroke={H_STROKE} />

              <text x="300" y="205" textAnchor="middle" fill={C_STROKE} fontSize="11.5" fontWeight="600">
                Semua ikatan tetap tunggal (jenuh) — hanya atom H dan Cl yang bertukar tempat
              </text>
            </g>
          )}

          {/* ============================================================== */}
          {/* C. ELIMINASI: CH3-CH2-CH3 -> CH3-CH=CH2 + H2                   */}
          {/* ============================================================== */}
          {reaksiId === 'rx-eliminasi' && tahap === 1 && (
            <g>
              <text x="300" y="24" textAnchor="middle" fill={C_STROKE} fontSize="12" fontWeight="700">
                Propana (C₃H₈) · Dipanaskan dengan Katalis
              </text>

              <BondLine x1={150} y1={122} x2={300} y2={122} color={C_STROKE} />
              <BondLine x1={300} y1={122} x2={450} y2={122} color={C_STROKE} />
              <BondLine x1={300} y1={122} x2={300} y2={62} color={BREAK_COLOR} />
              <BondLine x1={450} y1={122} x2={450} y2={62} color={BREAK_COLOR} />

              <AtomCircle cx={150} cy={122} label="CH₃" r={24} />
              <AtomCircle cx={300} cy={122} label="CH" r={24} />
              <AtomCircle cx={450} cy={122} label="CH₂" r={24} />
              <AtomCircle cx={300} cy={62} label="H" r={15} stroke={BREAK_COLOR} />
              <AtomCircle cx={450} cy={62} label="H" r={15} stroke={BREAK_COLOR} />

              <text x="300" y="198" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                Dua atom H pada karbon bersebelahan bersiap dilepaskan dari rantai utama
              </text>
            </g>
          )}

          {reaksiId === 'rx-eliminasi' && tahap === 2 && (
            <g>
              <text x="300" y="24" textAnchor="middle" fill={BREAK_COLOR} fontSize="12" fontWeight="700">
                2 Atom H Dilepas → Elektron Bergabung Membentuk Ikatan Rangkap
              </text>

              <BondLine x1={150} y1={134} x2={300} y2={134} color={C_STROKE} />
              {/* Forming double bond */}
              <BondLine x1={300} y1={130} x2={450} y2={130} color={C_STROKE} />
              <BondLine x1={300} y1={139} x2={450} y2={139} color={NEW_COLOR} dashed />

              {/* Breaking C-H bonds */}
              <BondLine x1={300} y1={110} x2={300} y2={62} color={BREAK_COLOR} dashed />
              <BondLine x1={450} y1={110} x2={450} y2={62} color={BREAK_COLOR} dashed />

              <AtomCircle cx={150} cy={134} label="CH₃" r={24} />
              <AtomCircle cx={300} cy={134} label="CH" r={24} />
              <AtomCircle cx={450} cy={134} label="CH₂" r={24} />
              <AtomCircle cx={300} cy={62} label="H" r={15} stroke={BREAK_COLOR} />
              <AtomCircle cx={450} cy={62} label="H" r={15} stroke={BREAK_COLOR} />

              <text x="275" y="92" textAnchor="middle" fill={BREAK_COLOR} fontSize="11" fontWeight="700">✂</text>
              <text x="425" y="92" textAnchor="middle" fill={BREAK_COLOR} fontSize="11" fontWeight="700">✂</text>
              <text x="375" y="160" textAnchor="middle" fill={NEW_COLOR} fontSize="10.5" fontWeight="700">
                + Ikatan Rangkap Baru
              </text>

              <text x="300" y="205" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                Atau melalui pemutusan C—C (cracking) menjadi etena (C₂H₄) + metana (CH₄)
              </text>
            </g>
          )}

          {reaksiId === 'rx-eliminasi' && tahap === 3 && (
            <g>
              <text x="200" y="28" textAnchor="middle" fill={H_STROKE} fontSize="11.5" fontWeight="700">
                Propena (Alkena Tak Jenuh)
              </text>

              <BondLine x1={90} y1={115} x2={200} y2={115} color={C_STROKE} />
              <BondLine x1={200} y1={115} x2={315} y2={115} order={2} color={NEW_COLOR} />
              <AtomCircle cx={90} cy={115} label="CH₃" r={24} />
              <AtomCircle cx={200} cy={115} label="CH" r={24} />
              <AtomCircle cx={315} cy={115} label="CH₂" r={24} />

              <text x="385" y="121" textAnchor="middle" fill={TEXT_LIGHT} fontSize="22" fontWeight="700">
                +
              </text>

              <text x="490" y="28" textAnchor="middle" fill={BREAK_COLOR} fontSize="11.5" fontWeight="700">
                Gas H₂ Terlepas
              </text>
              <BondLine x1={450} y1={115} x2={530} y2={115} color={BREAK_COLOR} />
              <AtomCircle cx={450} cy={115} label="H" r={17} stroke={BREAK_COLOR} />
              <AtomCircle cx={530} cy={115} label="H" r={17} stroke={BREAK_COLOR} />

              <text x="300" y="200" textAnchor="middle" fill={H_STROKE} fontSize="11.5" fontWeight="600">
                Ikatan tunggal berubah menjadi ikatan rangkap dua (=)
              </text>
            </g>
          )}

          {/* ============================================================== */}
          {/* D. ADISI ALKENA: CH2=CH2 + H2 -> CH3-CH3                       */}
          {/* ============================================================== */}
          {reaksiId === 'rx-adisi-alkena' && tahap === 1 && (
            <g>
              <text x="175" y="28" textAnchor="middle" fill={H_STROKE} fontSize="11.5" fontWeight="700">
                Etena (Ikatan Rangkap Dua)
              </text>
              <BondLine x1={110} y1={115} x2={240} y2={115} order={2} color={H_STROKE} />
              <AtomCircle cx={110} cy={115} label="CH₂" r={24} stroke={H_STROKE} />
              <AtomCircle cx={240} cy={115} label="CH₂" r={24} stroke={H_STROKE} />
              <text x="175" y="152" textAnchor="middle" fill={H_STROKE} fontSize="10.5">
                1 ikatan sigma + 1 ikatan pi
              </text>

              <text x="320" y="121" textAnchor="middle" fill={TEXT_LIGHT} fontSize="22" fontWeight="700">
                +
              </text>

              <text x="455" y="28" textAnchor="middle" fill={NEW_COLOR} fontSize="11.5" fontWeight="700">
                Pereaksi Adisi (H₂ / Cl₂)
              </text>
              <BondLine x1={410} y1={115} x2={500} y2={115} color={NEW_COLOR} />
              <AtomCircle cx={410} cy={115} label="H" r={18} stroke={NEW_COLOR} />
              <AtomCircle cx={500} cy={115} label="H" r={18} stroke={NEW_COLOR} />

              <text x="300" y="202" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                Ikatan pi pada rangkap dua siap terbuka untuk menangkap dua atom H baru
              </text>
            </g>
          )}

          {reaksiId === 'rx-adisi-alkena' && tahap === 2 && (
            <g>
              <text x="300" y="24" textAnchor="middle" fill={NEW_COLOR} fontSize="12" fontWeight="700">
                Ikatan Pi Terputus → Masing-Masing Atom H Masuk ke Tiap Karbon
              </text>

              {/* Sigma solid + Pi breaking */}
              <line x1="210" y1="138" x2="390" y2="138" stroke={C_STROKE} strokeWidth="3" />
              <line
                x1="210"
                y1="148"
                x2="390"
                y2="148"
                stroke={BREAK_COLOR}
                strokeWidth="2.5"
                strokeDasharray="5 4"
              />
              <text x="300" y="166" textAnchor="middle" fill={BREAK_COLOR} fontSize="10.5" fontWeight="700">
                ✂ Ikatan pi terbuka
              </text>

              <AtomCircle cx={210} cy={142} label="CH₂" r={24} stroke={H_STROKE} />
              <AtomCircle cx={390} cy={142} label="CH₂" r={24} stroke={H_STROKE} />

              {/* H2 breaking above */}
              <BondLine x1={250} y1={62} x2={350} y2={62} color={BREAK_COLOR} dashed />
              <AtomCircle cx={250} cy={62} label="H" r={17} stroke={NEW_COLOR} />
              <AtomCircle cx={350} cy={62} label="H" r={17} stroke={NEW_COLOR} />
              <text x="300" y="54" textAnchor="middle" fill={BREAK_COLOR} fontSize="11" fontWeight="700">✂</text>

              {/* Arrows into C1 and C2 */}
              <line
                x1="240"
                y1="80"
                x2="218"
                y2="112"
                stroke={NEW_COLOR}
                strokeWidth="2.5"
                markerEnd="url(#arrow-gold)"
              />
              <line
                x1="360"
                y1="80"
                x2="382"
                y2="112"
                stroke={NEW_COLOR}
                strokeWidth="2.5"
                markerEnd="url(#arrow-gold)"
              />

              <text x="300" y="205" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                Setiap atom C mendapat tambahan 1 atom H (atau Cl jika direaksikan dengan Cl₂)
              </text>
            </g>
          )}

          {reaksiId === 'rx-adisi-alkena' && tahap === 3 && (
            <g>
              <text x="300" y="28" textAnchor="middle" fill={C_STROKE} fontSize="12" fontWeight="700">
                Etana (Ikatan Tunggal Jenuh)
              </text>

              <BondLine x1={220} y1={122} x2={380} y2={122} color={C_STROKE} />
              <BondLine x1={220} y1={122} x2={220} y2={62} color={NEW_COLOR} />
              <BondLine x1={380} y1={122} x2={380} y2={62} color={NEW_COLOR} />

              <AtomCircle cx={220} cy={122} label="CH₂" r={24} stroke={C_STROKE} />
              <AtomCircle cx={380} cy={122} label="CH₂" r={24} stroke={C_STROKE} />
              <AtomCircle cx={220} cy={62} label="H" r={16} stroke={NEW_COLOR} />
              <AtomCircle cx={380} cy={62} label="H" r={16} stroke={NEW_COLOR} />

              <rect x="195" y="170" width="210" height="28" rx="8" fill="#1E1850" stroke={C_STROKE} strokeOpacity="0.6" />
              <text x="300" y="188" textAnchor="middle" fill={C_STROKE} fontSize="11.5" fontWeight="700">
                CH₂=CH₂  →  CH₃—CH₃ (Jenuh)
              </text>
            </g>
          )}

          {/* ============================================================== */}
          {/* E. ADISI ALKUNA (2 TAHAP): CH≡CH -> CH2=CH2 -> CH3-CH3         */}
          {/* ============================================================== */}
          {reaksiId === 'rx-adisi-alkuna' && tahap === 1 && (
            <g>
              <text x="175" y="28" textAnchor="middle" fill={BREAK_COLOR} fontSize="11.5" fontWeight="700">
                Etuna (Ikatan Rangkap Tiga)
              </text>
              <BondLine x1={105} y1={115} x2={245} y2={115} order={3} color={BREAK_COLOR} />
              <AtomCircle cx={105} cy={115} label="CH" r={24} stroke={BREAK_COLOR} />
              <AtomCircle cx={245} cy={115} label="CH" r={24} stroke={BREAK_COLOR} />
              <text x="175" y="154" textAnchor="middle" fill={BREAK_COLOR} fontSize="10.5">
                Punya 2 ikatan pi (adisi 2 kali)
              </text>

              <text x="320" y="121" textAnchor="middle" fill={TEXT_LIGHT} fontSize="22" fontWeight="700">
                +
              </text>

              <text x="450" y="28" textAnchor="middle" fill={NEW_COLOR} fontSize="11.5" fontWeight="700">
                2 Molekul H₂ (Berlebih)
              </text>
              <BondLine x1={405} y1={85} x2={495} y2={85} color={NEW_COLOR} />
              <AtomCircle cx={405} cy={85} label="H" r={16} stroke={NEW_COLOR} />
              <AtomCircle cx={495} cy={85} label="H" r={16} stroke={NEW_COLOR} />

              <BondLine x1={405} y1={142} x2={495} y2={142} color={NEW_COLOR} />
              <AtomCircle cx={405} cy={142} label="H" r={16} stroke={NEW_COLOR} />
              <AtomCircle cx={495} cy={142} label="H" r={16} stroke={NEW_COLOR} />

              <text x="300" y="204" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                Karena ada 2 ikatan pi, penjenuhan berlangsung dua tahap berurutan
              </text>
            </g>
          )}

          {reaksiId === 'rx-adisi-alkuna' && tahap === 2 && (
            <g>
              <text x="300" y="24" textAnchor="middle" fill={H_STROKE} fontSize="12" fontWeight="700">
                Adisi Tahap 1: Rangkap Tiga (≡) → Rangkap Dua (=)
              </text>

              {/* Left: Etuna */}
              <BondLine x1={70} y1={115} x2={180} y2={115} order={3} color={BREAK_COLOR} />
              <AtomCircle cx={70} cy={115} label="CH" r={21} stroke={BREAK_COLOR} />
              <AtomCircle cx={180} cy={115} label="CH" r={21} stroke={BREAK_COLOR} />

              <text x="235" y="119" textAnchor="middle" fill={NEW_COLOR} fontSize="12" fontWeight="700">
                + H₂
              </text>

              <line
                x1="270"
                y1="115"
                x2="330"
                y2="115"
                stroke={NEW_COLOR}
                strokeWidth="2.8"
                markerEnd="url(#arrow-gold)"
              />

              {/* Right: Etena */}
              <BondLine x1={380} y1={115} x2={510} y2={115} order={2} color={H_STROKE} />
              <AtomCircle cx={380} cy={115} label="CH₂" r={23} stroke={H_STROKE} />
              <AtomCircle cx={510} cy={115} label="CH₂" r={23} stroke={H_STROKE} />

              <text x="445" y="155" textAnchor="middle" fill={H_STROKE} fontSize="11" fontWeight="700">
                Terbentuk Etena (masih ada 1 ikatan pi)
              </text>
              <text x="300" y="204" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                Masih belum jenuh — siap menerima molekul H₂ kedua pada tahap berikutnya
              </text>
            </g>
          )}

          {reaksiId === 'rx-adisi-alkuna' && tahap === 3 && (
            <g>
              <text x="300" y="24" textAnchor="middle" fill={C_STROKE} fontSize="12" fontWeight="700">
                Adisi Tahap 2: Rangkap Dua (=) → Ikatan Tunggal Jenuh (—)
              </text>

              {/* Left: Etena */}
              <BondLine x1={70} y1={115} x2={180} y2={115} order={2} color={H_STROKE} />
              <AtomCircle cx={70} cy={115} label="CH₂" r={22} stroke={H_STROKE} />
              <AtomCircle cx={180} cy={115} label="CH₂" r={22} stroke={H_STROKE} />

              <text x="235" y="119" textAnchor="middle" fill={NEW_COLOR} fontSize="12" fontWeight="700">
                + H₂
              </text>

              <line
                x1="270"
                y1="115"
                x2="330"
                y2="115"
                stroke={C_STROKE}
                strokeWidth="2.8"
                markerEnd="url(#arrow-mint)"
              />

              {/* Right: Etana */}
              <BondLine x1={380} y1={115} x2={510} y2={115} order={1} color={C_STROKE} />
              <AtomCircle cx={380} cy={115} label="CH₃" r={24} stroke={C_STROKE} />
              <AtomCircle cx={510} cy={115} label="CH₃" r={24} stroke={C_STROKE} />

              <text x="445" y="155" textAnchor="middle" fill={C_STROKE} fontSize="11" fontWeight="700">
                Terbentuk Etana (Alkana Jenuh)
              </text>
              <text x="300" y="204" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                Ringkasan: Alkuna (≡) → Alkena (=) → Alkana (—)
              </text>
            </g>
          )}

          {/* ============================================================== */}
          {/* F. MARKOVNIKOV: CH3-CH=CH2 + HBr -> CH3-CH(Br)-CH3             */}
          {/* ============================================================== */}
          {reaksiId === 'rx-markovnikov' && tahap === 1 && (
            <g>
              <text x="210" y="26" textAnchor="middle" fill={H_STROKE} fontSize="11.5" fontWeight="700">
                Propena (Alkena Tak Simetris)
              </text>

              <BondLine x1={90} y1={110} x2={205} y2={110} color={C_STROKE} />
              <BondLine x1={205} y1={110} x2={330} y2={110} order={2} color={H_STROKE} />

              <AtomCircle cx={90} cy={110} label="CH₃" r={23} />
              <AtomCircle cx={205} cy={110} label="CH" r={23} stroke={BREAK_COLOR} />
              <AtomCircle cx={330} cy={110} label="CH₂" r={23} stroke={NEW_COLOR} />

              {/* H count badges on C=C */}
              <text x="205" y="152" textAnchor="middle" fill={BREAK_COLOR} fontSize="10.5" fontWeight="700">
                C-2: Punya 1 H
              </text>
              <text x="205" y="166" textAnchor="middle" fill={TEXT_MUTED} fontSize="9.5">
                (Lebih sedikit H)
              </text>

              <text x="330" y="152" textAnchor="middle" fill={NEW_COLOR} fontSize="10.5" fontWeight="700">
                C-1: Punya 2 H
              </text>
              <text x="330" y="166" textAnchor="middle" fill={TEXT_MUTED} fontSize="9.5">
                (Lebih kaya H!)
              </text>

              <text x="415" y="116" textAnchor="middle" fill={TEXT_LIGHT} fontSize="22" fontWeight="700">
                +
              </text>

              <BondLine x1={475} y1={110} x2={545} y2={110} color={NEW_COLOR} />
              <AtomCircle cx={475} cy={110} label="H⁺" r={17} stroke={NEW_COLOR} />
              <AtomCircle cx={545} cy={110} label="Br⁻" r={19} stroke={BREAK_COLOR} />

              <text x="300" y="205" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                Perhatikan perbedaan jumlah H pada dua atom C yang berikatan rangkap
              </text>
            </g>
          )}

          {reaksiId === 'rx-markovnikov' && tahap === 2 && (
            <g>
              <text x="300" y="24" textAnchor="middle" fill={NEW_COLOR} fontSize="12" fontWeight="700">
                Kaidah Markovnikov: “Yang Kaya H Makin Kaya H”
              </text>

              <BondLine x1={120} y1={140} x2={245} y2={140} color={C_STROKE} />
              <line x1="245" y1="136" x2="380" y2="136" stroke={C_STROKE} strokeWidth="3" />
              <line
                x1="245"
                y1="145"
                x2="380"
                y2="145"
                stroke={BREAK_COLOR}
                strokeWidth="2.5"
                strokeDasharray="5 4"
              />

              <AtomCircle cx={120} cy={140} label="CH₃" r={23} />
              <AtomCircle cx={245} cy={140} label="CH" r={23} stroke={BREAK_COLOR} />
              <AtomCircle cx={380} cy={140} label="CH₂" r={23} stroke={NEW_COLOR} />

              {/* HBr above */}
              <BondLine x1={245} y1={62} x2={380} y2={62} color={BREAK_COLOR} dashed />
              <AtomCircle cx={245} cy={62} label="Br⁻" r={18} stroke={BREAK_COLOR} />
              <AtomCircle cx={380} cy={62} label="H⁺" r={17} stroke={NEW_COLOR} />
              <text x="312" y="54" textAnchor="middle" fill={BREAK_COLOR} fontSize="11" fontWeight="700">✂</text>

              {/* Direct attachment arrows */}
              <line
                x1="245"
                y1="82"
                x2="245"
                y2="112"
                stroke={BREAK_COLOR}
                strokeWidth="2.6"
                markerEnd="url(#arrow-pink)"
              />
              <text x="195" y="100" textAnchor="end" fill={BREAK_COLOR} fontSize="10.5" fontWeight="700">
                Br ke C sedikit H
              </text>

              <line
                x1="380"
                y1="82"
                x2="380"
                y2="112"
                stroke={NEW_COLOR}
                strokeWidth="2.6"
                markerEnd="url(#arrow-gold)"
              />
              <text x="412" y="100" textAnchor="start" fill={NEW_COLOR} fontSize="10.5" fontWeight="700">
                H ke C kaya H
              </text>

              <text x="300" y="205" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                C-1 yang awalnya punya 2 H menerima atom H⁺, sedangkan Br⁻ masuk ke C-2
              </text>
            </g>
          )}

          {reaksiId === 'rx-markovnikov' && tahap === 3 && (
            <g>
              <text x="300" y="26" textAnchor="middle" fill={C_STROKE} fontSize="12" fontWeight="700">
                Produk Utama (~95%): 2-bromopropana
              </text>

              <BondLine x1={150} y1={134} x2={300} y2={134} color={C_STROKE} />
              <BondLine x1={300} y1={134} x2={450} y2={134} color={C_STROKE} />
              <BondLine x1={300} y1={134} x2={300} y2={68} color={BREAK_COLOR} />
              <BondLine x1={450} y1={134} x2={450} y2={68} color={NEW_COLOR} />

              <AtomCircle cx={150} cy={134} label="CH₃" r={24} />
              <AtomCircle cx={300} cy={134} label="CH" r={24} />
              <AtomCircle cx={450} cy={134} label="CH₂" r={24} />
              <AtomCircle cx={300} cy={68} label="Br" r={18} stroke={BREAK_COLOR} />
              <AtomCircle cx={450} cy={68} label="H" r={16} stroke={NEW_COLOR} />

              <text x="450" y="175" textAnchor="middle" fill={NEW_COLOR} fontSize="10.5" fontWeight="700">
                Menjadi —CH₃
              </text>
              <text x="300" y="175" textAnchor="middle" fill={BREAK_COLOR} fontSize="10.5" fontWeight="700">
                Br terikat di C-2
              </text>
              <text x="300" y="205" textAnchor="middle" fill={TEXT_MUTED} fontSize="11">
                Bentuk CH₃—CH(Br)—CH₃ jauh lebih stabil daripada 1-bromopropana
              </text>
            </g>
          )}
        </svg>
      </div>

      {/* Visual Color Legend (Dual-coded: Color + Text) */}
      <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-1.5 text-[11px] text-[#B8B5DE]">
        <span className="inline-flex items-center gap-1.5">
          <span className="w-3 h-0.5 bg-[#5EEAD4] inline-block" aria-hidden="true" />
          <span>Ikatan stabil / Rantai C</span>
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-3 h-0.5 border-t-2 border-dashed border-[#FFA8C5] inline-block" aria-hidden="true" />
          <span className="text-[#FFA8C5]">✂ Ikatan putus / gugus pindah</span>
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-3 h-0.5 bg-[#FDE68A] inline-block" aria-hidden="true" />
          <span className="text-[#FDE68A]">→ Atom masuk / ikatan baru</span>
        </span>
      </div>
    </div>
  );
};
