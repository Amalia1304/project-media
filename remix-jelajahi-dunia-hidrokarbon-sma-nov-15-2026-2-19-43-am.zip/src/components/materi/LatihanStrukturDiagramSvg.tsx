/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Diagram Rumus Struktur Gaya Buku Kimia SMA untuk "Latihan Menentukan Nama Senyawa"
 * Menampilkan struktur 3-metil-1-pentena secara terbuka (tidak dimampatkan),
 * lengkap dengan opsi Tampilan Semua Ikatan C–H dan penyorotan bertahap sesuai jawaban siswa.
 */

import React, { useState } from 'react';

interface LatihanStrukturDiagramSvgProps {
  showMainChain: boolean;
  showNumbering: boolean;
  showBranch: boolean;
}

const renderSvgFormula = (
  formula: string,
  x: number,
  y: number,
  color: string
) => {
  const match = formula.match(/^([A-Za-z]+)(\d*)$/);
  if (!match) {
    return (
      <text
        x={x}
        y={y}
        textAnchor="middle"
        fill={color}
        fontSize="17"
        fontWeight="700"
        fontFamily="JetBrains Mono, monospace"
      >
        {formula}
      </text>
    );
  }
  const [, letters, digits] = match;
  return (
    <text
      x={x}
      y={y}
      textAnchor="middle"
      fill={color}
      fontSize="17"
      fontWeight="700"
      fontFamily="JetBrains Mono, monospace"
    >
      {letters}
      {digits && (
        <tspan dy="4.5" fontSize="12" fontWeight="700">
          {digits}
        </tspan>
      )}
    </text>
  );
};

export const LatihanStrukturDiagramSvg: React.FC<
  LatihanStrukturDiagramSvgProps
> = ({ showMainChain, showNumbering, showBranch }) => {
  const [expandedCH, setExpandedCH] = useState(false);

  // Main chain X coordinates (left to right: C5, C4, C3, C2, C1)
  const xs = [90, 194, 298, 402, 506];
  const nums = [5, 4, 3, 2, 1];
  const groups = ['CH3', 'CH2', 'CH', 'CH', 'CH2'];

  const branchColor = showBranch ? '#FFA8C5' : '#EEEDFB';
  const branchBondColor = showBranch ? '#FFA8C5' : '#948EC7';

  return (
    <div className="space-y-3">
      {/* Toolbar: style switcher */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <span className="text-[#8E8BB5] font-semibold uppercase tracking-wider">
          Struktur Senyawa Uji (Rumus Terbuka):
        </span>
        <div className="inline-flex bg-[#150F38] border border-[#3A3280] rounded-lg p-0.5">
          <button
            type="button"
            onClick={() => setExpandedCH(false)}
            className={`px-2.5 py-1.5 rounded-md text-[11px] font-bold transition-colors cursor-pointer ${
              !expandedCH
                ? 'bg-[#5EEAD4] text-[#0F0B2A]'
                : 'text-[#B8B5DE] hover:text-[#EEEDFB]'
            }`}
          >
            Rumus Struktur SMA
          </button>
          <button
            type="button"
            onClick={() => setExpandedCH(true)}
            className={`px-2.5 py-1.5 rounded-md text-[11px] font-bold transition-colors cursor-pointer ${
              expandedCH
                ? 'bg-[#5EEAD4] text-[#0F0B2A]'
                : 'text-[#B8B5DE] hover:text-[#EEEDFB]'
            }`}
          >
            Semua Ikatan C–H
          </button>
        </div>
      </div>

      {/* SVG Canvas */}
      <div className="w-full overflow-x-auto bg-[#0F0B2A] border border-[#3A3280] rounded-xl p-3 sm:p-4">
        {!expandedCH ? (
          /* Mode 1: Gaya Buku Kimia SMA (Semi-struktural terbuka, cabang vertikal) */
          <svg
            viewBox="0 0 596 205"
            className="mx-auto block w-full h-auto select-none"
            style={{ maxWidth: '580px', minWidth: '360px' }}
            role="img"
            aria-label="Struktur kimia terbuka 3-metil-1-pentena gaya buku SMA"
          >
            {/* Optional Directional Numbering Arrow (revealed after Step 2) */}
            {showNumbering && (
              <g>
                <line
                  x1="72"
                  y1="24"
                  x2="524"
                  y2="24"
                  stroke="#FDE68A"
                  strokeWidth="2"
                />
                <polygon points="72,24 82,19.5 82,28.5" fill="#FDE68A" />
                <text
                  x="298"
                  y="16"
                  textAnchor="middle"
                  fill="#FDE68A"
                  fontSize="10.5"
                  fontWeight="700"
                  fontFamily="Nunito, sans-serif"
                >
                  Arah penomoran dari kanan (dekat ikatan rangkap =)
                </text>
              </g>
            )}

            {/* Optional Main Chain Dashed Box (revealed after Step 1) */}
            {showMainChain && (
              <rect
                x="54"
                y="62"
                width="488"
                height="52"
                rx="12"
                fill="rgba(94, 234, 212, 0.06)"
                stroke="#5EEAD4"
                strokeOpacity="0.55"
                strokeWidth="1.5"
                strokeDasharray="6 4"
              />
            )}

            {/* Horizontal Single Bonds: C5-C4, C4-C3, C3-C2 */}
            {[0, 1, 2].map((i) => (
              <line
                key={`sb-${i}`}
                x1={xs[i] + 25}
                y1="86"
                x2={xs[i + 1] - 25}
                y2="86"
                stroke={showMainChain ? '#5EEAD4' : '#948EC7'}
                strokeWidth="2.8"
                strokeLinecap="round"
              />
            ))}

            {/* Horizontal Double Bond: C2=C1 */}
            <line
              x1={xs[3] + 24}
              y1="82"
              x2={xs[4] - 24}
              y2="82"
              stroke="#B4A7FF"
              strokeWidth="2.8"
              strokeLinecap="round"
            />
            <line
              x1={xs[3] + 24}
              y1="90"
              x2={xs[4] - 24}
              y2="90"
              stroke="#B4A7FF"
              strokeWidth="2.8"
              strokeLinecap="round"
            />

            {/* Main Chain Groups & Carbon Numbers */}
            {xs.map((cx, idx) => (
              <g key={`c-node-${idx}`}>
                {showNumbering && (
                  <g>
                    <circle
                      cx={cx}
                      cy="47"
                      r="11"
                      fill="#1E1850"
                      stroke="#FDE68A"
                      strokeWidth="1.5"
                    />
                    <text
                      x={cx}
                      y="51"
                      textAnchor="middle"
                      fill="#FDE68A"
                      fontSize="11"
                      fontWeight="800"
                      fontFamily="JetBrains Mono, monospace"
                    >
                      {nums[idx]}
                    </text>
                  </g>
                )}

                {renderSvgFormula(
                  groups[idx],
                  cx,
                  92,
                  showMainChain ? '#5EEAD4' : '#EEEDFB'
                )}
              </g>
            ))}

            {/* Vertical Branch Bond & CH3 attached to C3 (index 2) */}
            <line
              x1={xs[2]}
              y1="104"
              x2={xs[2]}
              y2="136"
              stroke={branchBondColor}
              strokeWidth="2.6"
              strokeLinecap="round"
            />
            {renderSvgFormula('CH3', xs[2], 158, branchColor)}

            {showBranch && (
              <text
                x={xs[2]}
                y="182"
                textAnchor="middle"
                fill="#FFA8C5"
                fontSize="11"
                fontWeight="700"
                fontFamily="Nunito, sans-serif"
              >
                (cabang metil di C-3)
              </text>
            )}
          </svg>
        ) : (
          /* Mode 2: Struktur Ikatan Lengkap (semua ikatan kovalen C–H diuraikan) */
          <svg
            viewBox="0 0 600 266"
            className="mx-auto block w-full h-auto select-none"
            style={{ maxWidth: '580px', minWidth: '380px' }}
            role="img"
            aria-label="Struktur ikatan kovalen lengkap C dan H untuk 3-metil-1-pentena"
          >
            {/* Optional Numbering Arrow */}
            {showNumbering && (
              <g>
                <line
                  x1="78"
                  y1="18"
                  x2="522"
                  y2="18"
                  stroke="#FDE68A"
                  strokeWidth="1.8"
                />
                <polygon points="78,18 87,14 87,22" fill="#FDE68A" />
              </g>
            )}

            {/* Main chain C positions */}
            {/* C5=96, C4=192, C3=288, C2=384, C1=480; mainY=102 */}
            {(() => {
              const cXs = [96, 192, 288, 384, 480];
              const mainY = 102;
              const hColor = '#948EC7';
              const cColor = showMainChain ? '#5EEAD4' : '#EEEDFB';

              return (
                <g>
                  {/* Main chain enclosure */}
                  {showMainChain && (
                    <rect
                      x="68"
                      y="82"
                      width="440"
                      height="40"
                      rx="10"
                      fill="rgba(94, 234, 212, 0.06)"
                      stroke="#5EEAD4"
                      strokeOpacity="0.5"
                      strokeWidth="1.4"
                      strokeDasharray="5 4"
                    />
                  )}

                  {/* C–C single bonds */}
                  {[0, 1, 2].map((i) => (
                    <line
                      key={`cc-${i}`}
                      x1={cXs[i] + 15}
                      y1={mainY}
                      x2={cXs[i + 1] - 15}
                      y2={mainY}
                      stroke={showMainChain ? '#5EEAD4' : '#948EC7'}
                      strokeWidth="2.6"
                    />
                  ))}

                  {/* C2=C1 double bond */}
                  <line
                    x1={cXs[3] + 15}
                    y1={mainY - 3.5}
                    x2={cXs[4] - 15}
                    y2={mainY - 3.5}
                    stroke="#B4A7FF"
                    strokeWidth="2.6"
                  />
                  <line
                    x1={cXs[3] + 15}
                    y1={mainY + 3.5}
                    x2={cXs[4] - 15}
                    y2={mainY + 3.5}
                    stroke="#B4A7FF"
                    strokeWidth="2.6"
                  />

                  {/* H atoms on Top for C5, C4, C3, C2, C1 */}
                  {cXs.map((cx, i) => (
                    <g key={`htop-${i}`}>
                      <line
                        x1={cx}
                        y1={mainY - 14}
                        x2={cx}
                        y2={mainY - 34}
                        stroke={hColor}
                        strokeWidth="2"
                      />
                      <text
                        x={cx}
                        y={mainY - 40}
                        textAnchor="middle"
                        fill="#B8B5DE"
                        fontSize="14"
                        fontWeight="700"
                        fontFamily="JetBrains Mono, monospace"
                      >
                        H
                      </text>
                      {showNumbering && (
                        <g>
                          <circle
                            cx={cx + 22}
                            cy={mainY - 22}
                            r="9.5"
                            fill="#1E1850"
                            stroke="#FDE68A"
                            strokeWidth="1.4"
                          />
                          <text
                            x={cx + 22}
                            y={mainY - 18.5}
                            textAnchor="middle"
                            fill="#FDE68A"
                            fontSize="10"
                            fontWeight="800"
                            fontFamily="JetBrains Mono, monospace"
                          >
                            {nums[i]}
                          </text>
                        </g>
                      )}
                    </g>
                  ))}

                  {/* H left of C5 */}
                  <line
                    x1={cXs[0] - 14}
                    y1={mainY}
                    x2={cXs[0] - 34}
                    y2={mainY}
                    stroke={hColor}
                    strokeWidth="2"
                  />
                  <text
                    x={cXs[0] - 44}
                    y={mainY + 5}
                    textAnchor="middle"
                    fill="#B8B5DE"
                    fontSize="14"
                    fontWeight="700"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    H
                  </text>

                  {/* H bottom of C5 and C4 */}
                  {[0, 1].map((i) => (
                    <g key={`hbot-${i}`}>
                      <line
                        x1={cXs[i]}
                        y1={mainY + 14}
                        x2={cXs[i]}
                        y2={mainY + 34}
                        stroke={hColor}
                        strokeWidth="2"
                      />
                      <text
                        x={cXs[i]}
                        y={mainY + 49}
                        textAnchor="middle"
                        fill="#B8B5DE"
                        fontSize="14"
                        fontWeight="700"
                        fontFamily="JetBrains Mono, monospace"
                      >
                        H
                      </text>
                    </g>
                  ))}

                  {/* H right of C1 */}
                  <line
                    x1={cXs[4] + 14}
                    y1={mainY}
                    x2={cXs[4] + 34}
                    y2={mainY}
                    stroke={hColor}
                    strokeWidth="2"
                  />
                  <text
                    x={cXs[4] + 44}
                    y={mainY + 5}
                    textAnchor="middle"
                    fill="#B8B5DE"
                    fontSize="14"
                    fontWeight="700"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    H
                  </text>

                  {/* Main Carbon Letters */}
                  {cXs.map((cx, i) => (
                    <text
                      key={`clabel-${i}`}
                      x={cx}
                      y={mainY + 6}
                      textAnchor="middle"
                      fill={cColor}
                      fontSize="17"
                      fontWeight="800"
                      fontFamily="JetBrains Mono, monospace"
                    >
                      C
                    </text>
                  ))}

                  {/* Methyl Branch under C3 (cXs[2]) expanded: C with left H, right H, bottom H */}
                  <line
                    x1={cXs[2]}
                    y1={mainY + 14}
                    x2={cXs[2]}
                    y2={mainY + 64}
                    stroke={branchBondColor}
                    strokeWidth="2.4"
                  />
                  <text
                    x={cXs[2]}
                    y={mainY + 84}
                    textAnchor="middle"
                    fill={branchColor}
                    fontSize="17"
                    fontWeight="800"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    C
                  </text>
                  {/* Branch left H */}
                  <line
                    x1={cXs[2] - 14}
                    y1={mainY + 78}
                    x2={cXs[2] - 34}
                    y2={mainY + 78}
                    stroke={branchBondColor}
                    strokeWidth="2"
                  />
                  <text
                    x={cXs[2] - 44}
                    y={mainY + 83}
                    textAnchor="middle"
                    fill={showBranch ? '#FFA8C5' : '#B8B5DE'}
                    fontSize="14"
                    fontWeight="700"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    H
                  </text>
                  {/* Branch right H */}
                  <line
                    x1={cXs[2] + 14}
                    y1={mainY + 78}
                    x2={cXs[2] + 34}
                    y2={mainY + 78}
                    stroke={branchBondColor}
                    strokeWidth="2"
                  />
                  <text
                    x={cXs[2] + 44}
                    y={mainY + 83}
                    textAnchor="middle"
                    fill={showBranch ? '#FFA8C5' : '#B8B5DE'}
                    fontSize="14"
                    fontWeight="700"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    H
                  </text>
                  {/* Branch bottom H */}
                  <line
                    x1={cXs[2]}
                    y1={mainY + 92}
                    x2={cXs[2]}
                    y2={mainY + 114}
                    stroke={branchBondColor}
                    strokeWidth="2"
                  />
                  <text
                    x={cXs[2]}
                    y={mainY + 129}
                    textAnchor="middle"
                    fill={showBranch ? '#FFA8C5' : '#B8B5DE'}
                    fontSize="14"
                    fontWeight="700"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    H
                  </text>

                  {showBranch && (
                    <text
                      x={cXs[2]}
                      y="255"
                      textAnchor="middle"
                      fill="#FFA8C5"
                      fontSize="11"
                      fontWeight="700"
                      fontFamily="Nunito, sans-serif"
                    >
                      (cabang metil —CH₃ di C-3)
                    </text>
                  )}
                </g>
              );
            })()}
          </svg>
        )}
      </div>
    </div>
  );
};
