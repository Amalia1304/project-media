/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Komponen Visualisasi Interaktif Bentuk Susunan Rantai Karbon (Sub-Bab 1.2)
 * Menampilkan diagram SVG rantai lurus, rantai bercabang, alisiklik, dan aromatik
 * dengan toggle tampilan kerangka atom C vs gugus CH lengkap.
 */

import React, { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

type ChainShapeId = 'lurus' | 'bercabang' | 'alisiklik' | 'aromatik';

interface ChainVariant {
  id: ChainShapeId;
  kategori: 'Rantai Terbuka (Alifatik)' | 'Rantai Tertutup (Siklis)';
  nama: string;
  contohNama: string;
  rumus: string;
  accent: string;
  ciriKunci: string;
  penjelasan: string;
}

const CHAIN_VARIANTS: ChainVariant[] = [
  {
    id: 'lurus',
    kategori: 'Rantai Terbuka (Alifatik)',
    nama: 'Rantai Lurus',
    contohNama: 'n-butana',
    rumus: 'C₄H₁₀',
    accent: '#5EEAD4',
    ciriKunci: 'Kedua ujung rantai terbuka dan seluruh atom C tersambung satu jalur tanpa cabang.',
    penjelasan:
      'Semua atom karbon terhubung berurutan dari ujung ke ujung membentuk satu garis kontinu tanpa ada atom C yang bercabang keluar.',
  },
  {
    id: 'bercabang',
    kategori: 'Rantai Terbuka (Alifatik)',
    nama: 'Rantai Bercabang',
    contohNama: '2-metilpropana (isobutana)',
    rumus: 'C₄H₁₀',
    accent: '#FDE68A',
    ciriKunci: 'Rantai terbuka dengan minimal satu gugus karbon terikat di luar rantai utama.',
    penjelasan:
      'Tiga atom C membentuk rantai utama, sedangkan satu atom C lainnya menempel pada atom C tengah sebagai cabang (gugus metil).',
  },
  {
    id: 'alisiklik',
    kategori: 'Rantai Tertutup (Siklis)',
    nama: 'Alisiklik',
    contohNama: 'Sikloheksana',
    rumus: 'C₆H₁₂',
    accent: '#B4A7FF',
    ciriKunci: 'Ujung-ujung rantai karbon saling bertemu membentuk cincin tertutup berikatan tunggal.',
    penjelasan:
      'Enam atom karbon saling mengikat membentuk bangun segi enam tertutup. Sifat kimianya mirip senyawa alifatik namun tidak memiliki ujung bebas.',
  },
  {
    id: 'aromatik',
    kategori: 'Rantai Tertutup (Siklis)',
    nama: 'Aromatik',
    contohNama: 'Benzena',
    rumus: 'C₆H₆',
    accent: '#FFA8C5',
    ciriKunci: 'Cincin tertutup beranggota 6 atom C dengan ikatan tunggal dan rangkap dua berselang-seling.',
    penjelasan:
      'Setiap atom karbon dalam cincin segi enam terhubung bergantian oleh ikatan tunggal dan ikatan rangkap dua sehingga membentuk sistem cincin aromatik yang stabil.',
  },
];

// Reusable miniature skeleton icon for selector buttons
const MiniChainGlyph: React.FC<{ id: ChainShapeId; color: string }> = ({ id, color }) => {
  if (id === 'lurus') {
    return (
      <svg viewBox="0 0 64 24" className="w-12 h-5 shrink-0" aria-hidden="true">
        <line x1="8" y1="12" x2="56" y2="12" stroke={color} strokeWidth="2.2" />
        {[8, 24, 40, 56].map((cx) => (
          <circle key={cx} cx={cx} cy="12" r="3.5" fill="#0F0B2A" stroke={color} strokeWidth="2" />
        ))}
      </svg>
    );
  }
  if (id === 'bercabang') {
    return (
      <svg viewBox="0 0 64 28" className="w-12 h-5 shrink-0" aria-hidden="true">
        <line x1="12" y1="9" x2="52" y2="9" stroke={color} strokeWidth="2.2" />
        <line x1="32" y1="9" x2="32" y2="22" stroke={color} strokeWidth="2.2" />
        {[12, 32, 52].map((cx) => (
          <circle key={cx} cx={cx} cy="9" r="3.5" fill="#0F0B2A" stroke={color} strokeWidth="2" />
        ))}
        <circle cx="32" cy="22" r="3.5" fill="#0F0B2A" stroke={color} strokeWidth="2" />
      </svg>
    );
  }
  if (id === 'alisiklik') {
    return (
      <svg viewBox="0 0 40 28" className="w-9 h-5 shrink-0" aria-hidden="true">
        <polygon
          points="20,3 31,9 31,19 20,25 9,19 9,9"
          fill="none"
          stroke={color}
          strokeWidth="2.2"
        />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 40 28" className="w-9 h-5 shrink-0" aria-hidden="true">
      <polygon
        points="20,3 31,9 31,19 20,25 9,19 9,9"
        fill="none"
        stroke={color}
        strokeWidth="2"
      />
      <circle cx="20" cy="14" r="6" fill="none" stroke={color} strokeWidth="1.6" strokeDasharray="3 2" />
    </svg>
  );
};

export const BentukRantaiVisualizer: React.FC = () => {
  const [activeId, setActiveId] = useState<ChainShapeId>('lurus');
  const [showHydrogens, setShowHydrogens] = useState<boolean>(true);

  const active = CHAIN_VARIANTS.find((v) => v.id === activeId) || CHAIN_VARIANTS[0];

  // Helper for hexagonal ring coordinates
  const hexCenter = { x: 260, y: 118 };
  const hexRadius = 72;
  const hexPoints = Array.from({ length: 6 }, (_, i) => {
    const angle = (Math.PI / 180) * (60 * i - 90);
    return {
      x: hexCenter.x + hexRadius * Math.cos(angle),
      y: hexCenter.y + hexRadius * Math.sin(angle),
    };
  });

  // Helper to draw double bond parallel offset between two points
  const renderBond = (
    p1: { x: number; y: number },
    p2: { x: number; y: number },
    order: 1 | 2,
    color: string,
    key: string
  ) => {
    if (order === 1) {
      return (
        <line
          key={key}
          x1={p1.x}
          y1={p1.y}
          x2={p2.x}
          y2={p2.y}
          stroke={color}
          strokeWidth="3.5"
          strokeLinecap="round"
        />
      );
    }
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const len = Math.hypot(dx, dy) || 1;
    const nx = (-dy / len) * 3.5;
    const ny = (dx / len) * 3.5;
    return (
      <g key={key}>
        <line
          x1={p1.x + nx}
          y1={p1.y + ny}
          x2={p2.x + nx}
          y2={p2.y + ny}
          stroke={color}
          strokeWidth="2.8"
          strokeLinecap="round"
        />
        <line
          x1={p1.x - nx}
          y1={p1.y - ny}
          x2={p2.x - nx}
          y2={p2.y - ny}
          stroke={color}
          strokeWidth="2.8"
          strokeLinecap="round"
        />
      </g>
    );
  };

  const renderAtomNode = (
    x: number,
    y: number,
    labelH: string,
    strokeColor: string,
    key: string,
    subLabel?: string
  ) => {
    const text = showHydrogens ? labelH : 'C';
    return (
      <g key={key}>
        <circle
          cx={x}
          cy={y}
          r={22}
          fill="#150F38"
          stroke={strokeColor}
          strokeWidth="2.5"
        />
        <text
          x={x}
          y={y + 4.5}
          textAnchor="middle"
          fill="#EEEDFB"
          fontSize={text.length > 2 ? '11.5' : '13'}
          fontWeight="700"
          fontFamily="JetBrains Mono, monospace"
        >
          {text}
        </text>
        {subLabel && (
          <text
            x={x}
            y={y + 37}
            textAnchor="middle"
            fill="#8E8BB5"
            fontSize="10"
            fontWeight="600"
            fontFamily="Nunito, sans-serif"
          >
            {subLabel}
          </text>
        )}
      </g>
    );
  };

  return (
    <div className="space-y-4">
      {/* 4 Selector Buttons (2 Open, 2 Closed) */}
      <div
        role="tablist"
        aria-label="Pilih bentuk susunan rantai karbon"
        className="grid grid-cols-2 sm:grid-cols-4 gap-2.5"
      >
        {CHAIN_VARIANTS.map((variant) => {
          const isSelected = variant.id === activeId;
          return (
            <button
              key={variant.id}
              type="button"
              role="tab"
              aria-selected={isSelected}
              onClick={() => setActiveId(variant.id)}
              className={`p-3 rounded-xl border text-left transition-colors cursor-pointer flex flex-col gap-2 ${
                isSelected
                  ? 'bg-[#150F38] text-[#EEEDFB]'
                  : 'bg-[#0F0B2A]/80 border-[#3A3280] text-[#B8B5DE] hover:border-[#8E8BB5] hover:text-[#EEEDFB]'
              }`}
              style={
                isSelected
                  ? { borderColor: variant.accent }
                  : undefined
              }
            >
              <div className="flex items-center justify-between gap-2">
                <MiniChainGlyph id={variant.id} color={variant.accent} />
                <span
                  className="text-[10px] font-mono font-bold"
                  style={{ color: variant.accent }}
                >
                  {variant.rumus}
                </span>
              </div>
              <div>
                <div className="text-xs sm:text-sm font-bold leading-snug">
                  {variant.nama}
                </div>
                <div className="text-[11px] text-[#8E8BB5] truncate">
                  {variant.kategori.includes('Terbuka') ? 'Terbuka' : 'Tertutup'} · {variant.contohNama}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Interactive SVG Stage */}
      <div className="bg-[#0F0B2A] border border-[#3A3280] rounded-xl p-4 sm:p-5 space-y-4">
        {/* Top Bar Info & Toggle */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#3A3280]/60 pb-3">
          <div>
            <div className="flex flex-wrap items-center gap-x-2 text-xs">
              <span className="font-semibold" style={{ color: active.accent }}>
                {active.kategori}
              </span>
              <span className="text-[#3A3280]" aria-hidden="true">·</span>
              <span className="font-mono text-[#B8B5DE]">{active.rumus}</span>
            </div>
            <h5 className="text-sm sm:text-base font-bold text-[#EEEDFB] mt-0.5">
              {active.nama}: {active.contohNama}
            </h5>
          </div>

          <button
            type="button"
            onClick={() => setShowHydrogens((prev) => !prev)}
            className="px-3 py-1.5 rounded-lg bg-[#1E1850] hover:bg-[#251E60] border border-[#3A3280] text-xs font-semibold text-[#EEEDFB] transition-colors inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap self-start sm:self-auto"
          >
            {showHydrogens ? (
              <>
                <EyeOff className="w-3.5 h-3.5 text-[#B4A7FF]" />
                <span>Tampilkan Kerangka C Saja</span>
              </>
            ) : (
              <>
                <Eye className="w-3.5 h-3.5 text-[#5EEAD4]" />
                <span>Tampilkan Gugus H</span>
              </>
            )}
          </button>
        </div>

        {/* SVG Canvas */}
        <div className="w-full flex justify-center">
          <svg
            viewBox="0 0 520 235"
            className="w-full max-w-[520px] h-auto select-none"
            role="img"
            aria-label={`Diagram struktur ${active.nama} pada ${active.contohNama}`}
          >
            {/* Subtle background grid dots */}
            <defs>
              <pattern
                id="chain-grid"
                width="24"
                height="24"
                patternUnits="userSpaceOnUse"
              >
                <circle cx="2" cy="2" r="1" fill="#3A3280" fillOpacity="0.45" />
              </pattern>
            </defs>
            <rect width="520" height="235" rx="12" fill="url(#chain-grid)" />

            {/* 1. RANTAI LURUS (n-butana) */}
            {activeId === 'lurus' && (
              <g>
                {/* Open end arrows/markers */}
                <text
                  x="48"
                  y="112"
                  textAnchor="middle"
                  fill="#8E8BB5"
                  fontSize="10"
                  fontWeight="600"
                >
                  Ujung 1
                </text>
                <text
                  x="472"
                  y="112"
                  textAnchor="middle"
                  fill="#8E8BB5"
                  fontSize="10"
                  fontWeight="600"
                >
                  Ujung 2
                </text>

                {renderBond({ x: 110, y: 108 }, { x: 210, y: 108 }, 1, '#5EEAD4', 'l-1')}
                {renderBond({ x: 210, y: 108 }, { x: 310, y: 108 }, 1, '#5EEAD4', 'l-2')}
                {renderBond({ x: 310, y: 108 }, { x: 410, y: 108 }, 1, '#5EEAD4', 'l-3')}

                {renderAtomNode(110, 108, 'CH₃', '#5EEAD4', 'la-1', 'C-1')}
                {renderAtomNode(210, 108, 'CH₂', '#5EEAD4', 'la-2', 'C-2')}
                {renderAtomNode(310, 108, 'CH₂', '#5EEAD4', 'la-3', 'C-3')}
                {renderAtomNode(410, 108, 'CH₃', '#5EEAD4', 'la-4', 'C-4')}

                <text
                  x="260"
                  y="192"
                  textAnchor="middle"
                  fill="#5EEAD4"
                  fontSize="11.5"
                  fontWeight="600"
                >
                  Rantai terbuka lurus — seluruh 4 atom C berderet tanpa cabang
                </text>
              </g>
            )}

            {/* 2. RANTAI BERCABANG (2-metilpropana) */}
            {activeId === 'bercabang' && (
              <g>
                {/* Main chain highlight band */}
                <rect
                  x="110"
                  y="54"
                  width="300"
                  height="60"
                  rx="30"
                  fill="#5EEAD4"
                  fillOpacity="0.06"
                  stroke="#5EEAD4"
                  strokeOpacity="0.25"
                  strokeDasharray="5 4"
                />
                <text
                  x="260"
                  y="38"
                  textAnchor="middle"
                  fill="#5EEAD4"
                  fontSize="11"
                  fontWeight="700"
                >
                  Rantai Utama (3 Atom C)
                </text>

                {renderBond({ x: 150, y: 84 }, { x: 260, y: 84 }, 1, '#5EEAD4', 'b-1')}
                {renderBond({ x: 260, y: 84 }, { x: 370, y: 84 }, 1, '#5EEAD4', 'b-2')}
                {renderBond({ x: 260, y: 84 }, { x: 260, y: 170 }, 1, '#FDE68A', 'b-branch')}

                {renderAtomNode(150, 84, 'CH₃', '#5EEAD4', 'ba-1')}
                {renderAtomNode(260, 84, 'CH', '#5EEAD4', 'ba-2')}
                {renderAtomNode(370, 84, 'CH₃', '#5EEAD4', 'ba-3')}
                {renderAtomNode(260, 170, 'CH₃', '#FDE68A', 'ba-branch')}

                <text
                  x="336"
                  y="174"
                  textAnchor="start"
                  fill="#FDE68A"
                  fontSize="11.5"
                  fontWeight="700"
                >
                  ← Gugus Cabang (Metil)
                </text>
              </g>
            )}

            {/* 3. ALISIKLIK (Sikloheksana) */}
            {activeId === 'alisiklik' && (
              <g>
                {hexPoints.map((pt, idx) => {
                  const next = hexPoints[(idx + 1) % 6];
                  return renderBond(pt, next, 1, '#B4A7FF', `ali-b-${idx}`);
                })}
                {hexPoints.map((pt, idx) =>
                  renderAtomNode(pt.x, pt.y, 'CH₂', '#B4A7FF', `ali-a-${idx}`)
                )}
                <text
                  x="260"
                  y="115"
                  textAnchor="middle"
                  fill="#B4A7FF"
                  fontSize="11"
                  fontWeight="700"
                >
                  Cincin Tertutup
                </text>
                <text
                  x="260"
                  y="130"
                  textAnchor="middle"
                  fill="#8E8BB5"
                  fontSize="10"
                >
                  Semua ikatan tunggal
                </text>
              </g>
            )}

            {/* 4. AROMATIK (Benzena) */}
            {activeId === 'aromatik' && (
              <g>
                {hexPoints.map((pt, idx) => {
                  const next = hexPoints[(idx + 1) % 6];
                  const order = idx % 2 === 0 ? 2 : 1;
                  return renderBond(
                    pt,
                    next,
                    order,
                    order === 2 ? '#FFA8C5' : '#B4A7FF',
                    `aro-b-${idx}`
                  );
                })}
                {hexPoints.map((pt, idx) =>
                  renderAtomNode(pt.x, pt.y, 'CH', '#FFA8C5', `aro-a-${idx}`)
                )}
                <text
                  x="260"
                  y="114"
                  textAnchor="middle"
                  fill="#FFA8C5"
                  fontSize="11"
                  fontWeight="700"
                >
                  Ikatan Rangkap
                </text>
                <text
                  x="260"
                  y="129"
                  textAnchor="middle"
                  fill="#B8B5DE"
                  fontSize="10"
                >
                  Selang-seling (= / —)
                </text>
              </g>
            )}
          </svg>
        </div>

        {/* Explanatory Caption */}
        <div className="pt-3 border-t border-[#3A3280]/60 space-y-1">
          <div className="text-xs font-semibold" style={{ color: active.accent }}>
            {active.ciriKunci}
          </div>
          <p className="text-xs sm:text-sm text-[#B8B5DE] leading-relaxed">
            {active.penjelasan}
          </p>
        </div>
      </div>
    </div>
  );
};
