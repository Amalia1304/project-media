/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Diagram SVG 2D Interaktif Struktur & Geometri Isomer Hidrokarbon
 * Memvisualisasikan seluruh 13 isomer struktur (C4H10, C5H12, C4H8, C5H10)
 * serta isomer geometri cis-trans untuk 2-butena dan 2-pentena.
 */

import React from 'react';

export type GeometriMode = 'datar' | 'cis' | 'trans';
export type ViewStyleMode = 'gugus' | 'kerangka';

interface IsomerDiagramSvgProps {
  svgType: string;
  geometriMode?: GeometriMode;
  viewStyle?: ViewStyleMode;
  compact?: boolean;
}

interface ChainNode {
  x: number;
  y: number;
  num: number;
  gugus: string;
  hCount: number;
}

interface BranchNode {
  parentIndex: number;
  dir: 'up' | 'down';
  gugus: string;
  label?: string;
}

interface LinearSpec {
  mainChainName: string;
  totalC: number;
  totalH: number;
  nodes: ChainNode[];
  doubleBondAfterIndex?: number; // index i means bond between nodes[i] and nodes[i+1]
  branches: BranchNode[];
  highlightNote: string;
}

const COLORS = {
  bg: '#0F0B2A',
  nodeFill: '#150F38',
  mainStroke: '#5EEAD4', // Mint - rantai utama
  branchStroke: '#FDE68A', // Gold - cabang alkil
  doubleBond: '#B4A7FF', // Lavender - ikatan rangkap C=C
  transAccent: '#FFA8C5', // Pink - trans / kontras ruang
  textLight: '#EEEDFB',
  textMuted: '#B8B5DE',
  textDim: '#8E8BB5',
  border: '#3A3280',
};

function getLinearSpec(svgType: string): LinearSpec | null {
  switch (svgType) {
    case 'butana-lurus':
      return {
        mainChainName: 'Rantai Utama: 4 C (Butana)',
        totalC: 4,
        totalH: 10,
        nodes: [
          { x: 95, y: 102, num: 1, gugus: 'CH₃', hCount: 3 },
          { x: 190, y: 102, num: 2, gugus: 'CH₂', hCount: 2 },
          { x: 285, y: 102, num: 3, gugus: 'CH₂', hCount: 2 },
          { x: 380, y: 102, num: 4, gugus: 'CH₃', hCount: 3 },
        ],
        branches: [],
        highlightNote: 'Semua 4 atom C tersusun lurus tanpa cabang',
      };

    case 'butana-cabang':
      return {
        mainChainName: 'Rantai Utama: 3 C (Propana)',
        totalC: 4,
        totalH: 10,
        nodes: [
          { x: 135, y: 82, num: 1, gugus: 'CH₃', hCount: 3 },
          { x: 240, y: 82, num: 2, gugus: 'CH', hCount: 1 },
          { x: 345, y: 82, num: 3, gugus: 'CH₃', hCount: 3 },
        ],
        branches: [{ parentIndex: 1, dir: 'down', gugus: 'CH₃', label: 'Cabang metil di C-2' }],
        highlightNote: 'Rantai utama memendek jadi 3 C, 1 atom C menjadi cabang di C-2',
      };

    case 'pentana-lurus':
      return {
        mainChainName: 'Rantai Utama: 5 C (Pentana)',
        totalC: 5,
        totalH: 12,
        nodes: [
          { x: 64, y: 102, num: 1, gugus: 'CH₃', hCount: 3 },
          { x: 152, y: 102, num: 2, gugus: 'CH₂', hCount: 2 },
          { x: 240, y: 102, num: 3, gugus: 'CH₂', hCount: 2 },
          { x: 328, y: 102, num: 4, gugus: 'CH₂', hCount: 2 },
          { x: 416, y: 102, num: 5, gugus: 'CH₃', hCount: 3 },
        ],
        branches: [],
        highlightNote: 'Semua 5 atom C tersusun lurus dalam satu rantai utama',
      };

    case 'pentana-iso':
      return {
        mainChainName: 'Rantai Utama: 4 C (Butana)',
        totalC: 5,
        totalH: 12,
        nodes: [
          { x: 95, y: 82, num: 1, gugus: 'CH₃', hCount: 3 },
          { x: 190, y: 82, num: 2, gugus: 'CH', hCount: 1 },
          { x: 285, y: 82, num: 3, gugus: 'CH₂', hCount: 2 },
          { x: 380, y: 82, num: 4, gugus: 'CH₃', hCount: 3 },
        ],
        branches: [{ parentIndex: 1, dir: 'down', gugus: 'CH₃', label: '1 cabang metil di C-2' }],
        highlightNote: 'Rantai utama 4 C dengan 1 cabang metil menempel di atom C-2',
      };

    case 'pentana-neo':
      return {
        mainChainName: 'Rantai Utama: 3 C (Propana)',
        totalC: 5,
        totalH: 12,
        nodes: [
          { x: 135, y: 120, num: 1, gugus: 'CH₃', hCount: 3 },
          { x: 240, y: 120, num: 2, gugus: 'C', hCount: 0 },
          { x: 345, y: 120, num: 3, gugus: 'CH₃', hCount: 3 },
        ],
        branches: [
          { parentIndex: 1, dir: 'up', gugus: 'CH₃', label: 'Metil atas' },
          { parentIndex: 1, dir: 'down', gugus: 'CH₃', label: 'Metil bawah' },
        ],
        highlightNote: 'Rantai utama 3 C, atom C-2 mengikat 2 cabang metil sekaligus',
      };

    case '1-butena':
      return {
        mainChainName: 'Rantai Utama: 4 C (Butena)',
        totalC: 4,
        totalH: 8,
        nodes: [
          { x: 95, y: 102, num: 1, gugus: 'CH₂', hCount: 2 },
          { x: 190, y: 102, num: 2, gugus: 'CH', hCount: 1 },
          { x: 285, y: 102, num: 3, gugus: 'CH₂', hCount: 2 },
          { x: 380, y: 102, num: 4, gugus: 'CH₃', hCount: 3 },
        ],
        doubleBondAfterIndex: 0,
        branches: [],
        highlightNote: 'Ikatan rangkap dua (C=C) berada di posisi ujung (C-1 dan C-2)',
      };

    case '2-butena':
      return {
        mainChainName: 'Rantai Utama: 4 C (Butena)',
        totalC: 4,
        totalH: 8,
        nodes: [
          { x: 95, y: 102, num: 1, gugus: 'CH₃', hCount: 3 },
          { x: 190, y: 102, num: 2, gugus: 'CH', hCount: 1 },
          { x: 285, y: 102, num: 3, gugus: 'CH', hCount: 1 },
          { x: 380, y: 102, num: 4, gugus: 'CH₃', hCount: 3 },
        ],
        doubleBondAfterIndex: 1,
        branches: [],
        highlightNote: 'Ikatan rangkap dua (C=C) bergeser ke tengah (C-2 dan C-3)',
      };

    case '2-metilpropena':
      return {
        mainChainName: 'Rantai Utama: 3 C (Propena)',
        totalC: 4,
        totalH: 8,
        nodes: [
          { x: 135, y: 82, num: 1, gugus: 'CH₂', hCount: 2 },
          { x: 240, y: 82, num: 2, gugus: 'C', hCount: 0 },
          { x: 345, y: 82, num: 3, gugus: 'CH₃', hCount: 3 },
        ],
        doubleBondAfterIndex: 0,
        branches: [{ parentIndex: 1, dir: 'down', gugus: 'CH₃', label: 'Cabang metil di C-2' }],
        highlightNote: 'Rantai utama 3 C (C=C di C-1) dengan 1 cabang metil di C-2',
      };

    case '1-pentena':
      return {
        mainChainName: 'Rantai Utama: 5 C (Pentena)',
        totalC: 5,
        totalH: 10,
        nodes: [
          { x: 64, y: 102, num: 1, gugus: 'CH₂', hCount: 2 },
          { x: 152, y: 102, num: 2, gugus: 'CH', hCount: 1 },
          { x: 240, y: 102, num: 3, gugus: 'CH₂', hCount: 2 },
          { x: 328, y: 102, num: 4, gugus: 'CH₂', hCount: 2 },
          { x: 416, y: 102, num: 5, gugus: 'CH₃', hCount: 3 },
        ],
        doubleBondAfterIndex: 0,
        branches: [],
        highlightNote: 'Rantai lurus 5 C dengan ikatan rangkap dua di C-1 dan C-2',
      };

    case '2-pentena':
      return {
        mainChainName: 'Rantai Utama: 5 C (Pentena)',
        totalC: 5,
        totalH: 10,
        nodes: [
          { x: 64, y: 102, num: 1, gugus: 'CH₃', hCount: 3 },
          { x: 152, y: 102, num: 2, gugus: 'CH', hCount: 1 },
          { x: 240, y: 102, num: 3, gugus: 'CH', hCount: 1 },
          { x: 328, y: 102, num: 4, gugus: 'CH₂', hCount: 2 },
          { x: 416, y: 102, num: 5, gugus: 'CH₃', hCount: 3 },
        ],
        doubleBondAfterIndex: 1,
        branches: [],
        highlightNote: 'Rantai lurus 5 C dengan ikatan rangkap dua bergeser ke C-2 dan C-3',
      };

    case '2-metil-1-butena':
      return {
        mainChainName: 'Rantai Utama: 4 C (1-Butena)',
        totalC: 5,
        totalH: 10,
        nodes: [
          { x: 95, y: 82, num: 1, gugus: 'CH₂', hCount: 2 },
          { x: 190, y: 82, num: 2, gugus: 'C', hCount: 0 },
          { x: 285, y: 82, num: 3, gugus: 'CH₂', hCount: 2 },
          { x: 380, y: 82, num: 4, gugus: 'CH₃', hCount: 3 },
        ],
        doubleBondAfterIndex: 0,
        branches: [{ parentIndex: 1, dir: 'down', gugus: 'CH₃', label: 'Metil di C-2' }],
        highlightNote: 'Ikatan rangkap di C-1, cabang metil terikat di atom C-2',
      };

    case '3-metil-1-butena':
      return {
        mainChainName: 'Rantai Utama: 4 C (1-Butena)',
        totalC: 5,
        totalH: 10,
        nodes: [
          { x: 95, y: 82, num: 1, gugus: 'CH₂', hCount: 2 },
          { x: 190, y: 82, num: 2, gugus: 'CH', hCount: 1 },
          { x: 285, y: 82, num: 3, gugus: 'CH', hCount: 1 },
          { x: 380, y: 82, num: 4, gugus: 'CH₃', hCount: 3 },
        ],
        doubleBondAfterIndex: 0,
        branches: [{ parentIndex: 2, dir: 'down', gugus: 'CH₃', label: 'Metil di C-3' }],
        highlightNote: 'Ikatan rangkap tetap di C-1, cabang metil bergeser ke atom C-3',
      };

    case '2-metil-2-butena':
      return {
        mainChainName: 'Rantai Utama: 4 C (2-Butena)',
        totalC: 5,
        totalH: 10,
        nodes: [
          { x: 95, y: 82, num: 1, gugus: 'CH₃', hCount: 3 },
          { x: 190, y: 82, num: 2, gugus: 'C', hCount: 0 },
          { x: 285, y: 82, num: 3, gugus: 'CH', hCount: 1 },
          { x: 380, y: 82, num: 4, gugus: 'CH₃', hCount: 3 },
        ],
        doubleBondAfterIndex: 1,
        branches: [{ parentIndex: 1, dir: 'down', gugus: 'CH₃', label: 'Metil di C-2' }],
        highlightNote: 'Ikatan rangkap berada di tengah (C-2=C-3) dan cabang metil di C-2',
      };

    default:
      return null;
  }
}

export const IsomerDiagramSvg: React.FC<IsomerDiagramSvgProps> = ({
  svgType,
  geometriMode = 'datar',
  viewStyle = 'gugus',
  compact = false,
}) => {
  const isGeometricTarget = svgType === '2-butena' || svgType === '2-pentena';

  // Render spatial cis-trans diagram for 2-butena and 2-pentena
  if (isGeometricTarget && (geometriMode === 'cis' || geometriMode === 'trans')) {
    const isPentena = svgType === '2-pentena';
    const isCis = geometriMode === 'cis';
    const accent = isCis ? COLORS.mainStroke : COLORS.transAccent;
    const rightAlkylLabel = isPentena ? 'C₂H₅' : 'CH₃';
    const rightAlkylSub = isPentena ? 'Etil (C4–C5)' : 'Metil (C4)';
    const leftAlkylSub = 'Metil (C1)';
    const compoundName = `${geometriMode}-${svgType}`;

    return (
      <svg
        viewBox="0 0 460 228"
        className={`mx-auto block w-full ${compact ? 'max-w-[420px]' : 'max-w-[460px]'} min-w-[290px] h-auto select-none`}
        role="img"
        aria-label={`Diagram struktur geometri ${compoundName}`}
      >
        <rect x="0" y="0" width="460" height="228" rx="12" fill={COLORS.bg} />

        {/* Header Strip inside SVG */}
        <text
          x="230"
          y="22"
          textAnchor="middle"
          fill={accent}
          fontSize="12"
          fontWeight="800"
          fontFamily="Nunito, sans-serif"
        >
          {isCis
            ? `${compoundName} — Kedua Gugus Alkil Sepihak (Sisi Atas)`
            : `${compoundName} — Kedua Gugus Alkil Berseberangan (Diagonal)`}
        </text>

        {/* Reference dashed plane across C=C */}
        <line
          x1="46"
          y1="112"
          x2="414"
          y2="112"
          stroke={COLORS.border}
          strokeWidth="1.5"
          strokeDasharray="5 4"
        />
        <text
          x="46"
          y="105"
          textAnchor="start"
          fill={COLORS.textDim}
          fontSize="9.5"
          fontWeight="700"
          fontFamily="Nunito, sans-serif"
        >
          Bidang C=C
        </text>
        <text
          x="414"
          y="105"
          textAnchor="end"
          fill={COLORS.textDim}
          fontSize="9.5"
          fontWeight="700"
          fontFamily="Nunito, sans-serif"
        >
          (Kaku / tak bisa berputar)
        </text>

        {/* Rigid C=C double bond */}
        <line x1="184" y1="107" x2="276" y2="107" stroke={COLORS.doubleBond} strokeWidth="4" strokeLinecap="round" />
        <line x1="184" y1="117" x2="276" y2="117" stroke={COLORS.doubleBond} strokeWidth="4" strokeLinecap="round" />

        {/* Bond lines to substituents */}
        {/* Left Top: always CH3 */}
        <line x1="184" y1="112" x2="118" y2="60" stroke={accent} strokeWidth="3" strokeLinecap="round" />
        {/* Left Bottom: always H */}
        <line x1="184" y1="112" x2="122" y2="162" stroke={COLORS.textMuted} strokeWidth="2.5" strokeLinecap="round" />

        {/* Right Side depends on cis vs trans */}
        {isCis ? (
          <>
            {/* Right Top: Alkyl */}
            <line x1="276" y1="112" x2="342" y2="60" stroke={accent} strokeWidth="3" strokeLinecap="round" />
            {/* Right Bottom: H */}
            <line x1="276" y1="112" x2="338" y2="162" stroke={COLORS.textMuted} strokeWidth="2.5" strokeLinecap="round" />
          </>
        ) : (
          <>
            {/* Right Top: H */}
            <line x1="276" y1="112" x2="338" y2="60" stroke={COLORS.textMuted} strokeWidth="2.5" strokeLinecap="round" />
            {/* Right Bottom: Alkyl */}
            <line x1="276" y1="112" x2="342" y2="162" stroke={accent} strokeWidth="3" strokeLinecap="round" />
          </>
        )}

        {/* Highlight dashed connection between the two alkyl groups to show spatial relationship */}
        {isCis ? (
          <line
            x1="142"
            y1="54"
            x2="318"
            y2="54"
            stroke={accent}
            strokeWidth="1.5"
            strokeDasharray="3 3"
            opacity="0.7"
          />
        ) : (
          <line
            x1="138"
            y1="66"
            x2="322"
            y2="154"
            stroke={accent}
            strokeWidth="1.5"
            strokeDasharray="3 3"
            opacity="0.7"
          />
        )}

        {/* Central C-2 and C-3 nodes */}
        <circle cx="184" cy="112" r="20" fill={COLORS.nodeFill} stroke={COLORS.doubleBond} strokeWidth="2.5" />
        <text x="184" y="116.5" textAnchor="middle" fill={COLORS.textLight} fontSize="13" fontWeight="800" fontFamily="JetBrains Mono, monospace">
          {viewStyle === 'kerangka' ? 'C' : 'CH'}
        </text>
        <circle cx="184" cy="87" r="9" fill={COLORS.doubleBond} />
        <text x="184" y="90.5" textAnchor="middle" fill={COLORS.bg} fontSize="10" fontWeight="800" fontFamily="JetBrains Mono, monospace">
          2
        </text>

        <circle cx="276" cy="112" r="20" fill={COLORS.nodeFill} stroke={COLORS.doubleBond} strokeWidth="2.5" />
        <text x="276" y="116.5" textAnchor="middle" fill={COLORS.textLight} fontSize="13" fontWeight="800" fontFamily="JetBrains Mono, monospace">
          {viewStyle === 'kerangka' ? 'C' : 'CH'}
        </text>
        <circle cx="276" cy="87" r="9" fill={COLORS.doubleBond} />
        <text x="276" y="90.5" textAnchor="middle" fill={COLORS.bg} fontSize="10" fontWeight="800" fontFamily="JetBrains Mono, monospace">
          3
        </text>

        {/* Left Top Alkyl (CH3 / C1) */}
        <circle cx="114" cy="56" r="21" fill={COLORS.nodeFill} stroke={accent} strokeWidth="2.5" />
        <text x="114" y="60.5" textAnchor="middle" fill={accent} fontSize="12" fontWeight="800" fontFamily="JetBrains Mono, monospace">
          {viewStyle === 'kerangka' ? 'C1' : 'CH₃'}
        </text>
        <text x="84" y="59" textAnchor="end" fill={COLORS.textMuted} fontSize="10" fontWeight="700" fontFamily="Nunito, sans-serif">
          {leftAlkylSub}
        </text>

        {/* Left Bottom H */}
        <circle cx="120" cy="166" r="15" fill={COLORS.nodeFill} stroke={COLORS.textMuted} strokeWidth="1.75" />
        <text x="120" y="170" textAnchor="middle" fill={COLORS.textLight} fontSize="12" fontWeight="700" fontFamily="JetBrains Mono, monospace">
          H
        </text>

        {/* Right Alkyl & Right H */}
        {isCis ? (
          <>
            <circle cx="346" cy="56" r="21" fill={COLORS.nodeFill} stroke={accent} strokeWidth="2.5" />
            <text x="346" y="60.5" textAnchor="middle" fill={accent} fontSize={isPentena && viewStyle === 'gugus' ? '11' : '12'} fontWeight="800" fontFamily="JetBrains Mono, monospace">
              {viewStyle === 'kerangka' ? (isPentena ? 'C–C' : 'C4') : rightAlkylLabel}
            </text>
            <text x="376" y="59" textAnchor="start" fill={COLORS.textMuted} fontSize="10" fontWeight="700" fontFamily="Nunito, sans-serif">
              {rightAlkylSub}
            </text>

            <circle cx="340" cy="166" r="15" fill={COLORS.nodeFill} stroke={COLORS.textMuted} strokeWidth="1.75" />
            <text x="340" y="170" textAnchor="middle" fill={COLORS.textLight} fontSize="12" fontWeight="700" fontFamily="JetBrains Mono, monospace">
              H
            </text>
          </>
        ) : (
          <>
            <circle cx="340" cy="56" r="15" fill={COLORS.nodeFill} stroke={COLORS.textMuted} strokeWidth="1.75" />
            <text x="340" y="60" textAnchor="middle" fill={COLORS.textLight} fontSize="12" fontWeight="700" fontFamily="JetBrains Mono, monospace">
              H
            </text>

            <circle cx="346" cy="166" r="21" fill={COLORS.nodeFill} stroke={accent} strokeWidth="2.5" />
            <text x="346" y="170.5" textAnchor="middle" fill={accent} fontSize={isPentena && viewStyle === 'gugus' ? '11' : '12'} fontWeight="800" fontFamily="JetBrains Mono, monospace">
              {viewStyle === 'kerangka' ? (isPentena ? 'C–C' : 'C4') : rightAlkylLabel}
            </text>
            <text x="376" y="169" textAnchor="start" fill={COLORS.textMuted} fontSize="10" fontWeight="700" fontFamily="Nunito, sans-serif">
              {rightAlkylSub}
            </text>
          </>
        )}

        {/* Bottom Caption */}
        <text
          x="230"
          y="212"
          textAnchor="middle"
          fill={COLORS.textMuted}
          fontSize="10.5"
          fontWeight="600"
          fontFamily="Nunito, sans-serif"
        >
          {isCis
            ? 'Gugus alkil berada di sisi bidang yang sama -> Isomer cis'
            : 'Gugus alkil berada di sisi berlawanan -> Isomer trans'}
        </text>
      </svg>
    );
  }

  // Render structural 2D diagram for all 13 isomers
  const spec = getLinearSpec(svgType);
  if (!spec) {
    return null;
  }

  const firstNode = spec.nodes[0];
  const lastNode = spec.nodes[spec.nodes.length - 1];
  const chainBoxX = firstNode.x - 32;
  const chainBoxW = lastNode.x - firstNode.x + 64;
  const chainY = firstNode.y;

  // Compute dynamic viewBox height so pentana-neo (up + down branch) and others fit neatly
  const hasUpBranch = spec.branches.some((b) => b.dir === 'up');
  const hasDownBranch = spec.branches.some((b) => b.dir === 'down');
  const svgHeight = hasUpBranch && hasDownBranch ? 252 : hasDownBranch ? 222 : 196;

  return (
    <svg
      viewBox={`0 0 480 ${svgHeight}`}
      className={`mx-auto block w-full ${compact ? 'max-w-[440px]' : 'max-w-[480px]'} min-w-[300px] h-auto select-none`}
      role="img"
      aria-label={`Diagram struktur 2D ${spec.mainChainName}`}
    >
      <rect x="0" y="0" width="480" height={svgHeight} rx="12" fill={COLORS.bg} />

      {/* Top main chain label & atom count badge */}
      <text
        x="20"
        y="22"
        textAnchor="start"
        fill={COLORS.mainStroke}
        fontSize="11"
        fontWeight="800"
        fontFamily="Nunito, sans-serif"
      >
        {spec.mainChainName}
      </text>
      <text
        x="460"
        y="22"
        textAnchor="end"
        fill={COLORS.textMuted}
        fontSize="11"
        fontWeight="700"
        fontFamily="JetBrains Mono, monospace"
      >
        {spec.totalC} Atom C · {spec.totalH} Atom H
      </text>

      {/* Main chain highlight container */}
      <rect
        x={chainBoxX}
        y={chainY - 34}
        width={chainBoxW}
        height="68"
        rx="18"
        fill="rgba(94, 234, 212, 0.05)"
        stroke="rgba(94, 234, 212, 0.28)"
        strokeWidth="1.25"
        strokeDasharray="4 4"
      />

      {/* Main chain bonds */}
      {spec.nodes.map((node, idx) => {
        if (idx === spec.nodes.length - 1) return null;
        const next = spec.nodes[idx + 1];
        const isDouble = spec.doubleBondAfterIndex === idx;

        if (isDouble) {
          const midX = (node.x + next.x) / 2;
          return (
            <g key={`bond-${idx}`}>
              {/* Subtle double-bond glow */}
              <line
                x1={node.x + 18}
                y1={chainY}
                x2={next.x - 18}
                y2={chainY}
                stroke={COLORS.doubleBond}
                strokeWidth="14"
                opacity="0.14"
                strokeLinecap="round"
              />
              <line
                x1={node.x + 16}
                y1={chainY - 4.5}
                x2={next.x - 16}
                y2={chainY - 4.5}
                stroke={COLORS.doubleBond}
                strokeWidth="3.5"
                strokeLinecap="round"
              />
              <line
                x1={node.x + 16}
                y1={chainY + 4.5}
                x2={next.x - 16}
                y2={chainY + 4.5}
                stroke={COLORS.doubleBond}
                strokeWidth="3.5"
                strokeLinecap="round"
              />
              <text
                x={midX}
                y={chainY - 15}
                textAnchor="middle"
                fill={COLORS.doubleBond}
                fontSize="10"
                fontWeight="800"
                fontFamily="Nunito, sans-serif"
              >
                C=C
              </text>
            </g>
          );
        }

        return (
          <line
            key={`bond-${idx}`}
            x1={node.x + 16}
            y1={chainY}
            x2={next.x - 16}
            y2={chainY}
            stroke={COLORS.mainStroke}
            strokeWidth="3"
            strokeLinecap="round"
          />
        );
      })}

      {/* Branches */}
      {spec.branches.map((branch, bIdx) => {
        const parent = spec.nodes[branch.parentIndex];
        const isUp = branch.dir === 'up';
        const branchOffset = hasUpBranch && hasDownBranch ? 62 : 68;
        const branchY = isUp ? parent.y - branchOffset : parent.y + branchOffset;
        const labelY = isUp ? branchY - 26 : branchY + 34;

        return (
          <g key={`branch-${bIdx}`}>
            <line
              x1={parent.x}
              y1={parent.y}
              x2={parent.x}
              y2={branchY}
              stroke={COLORS.branchStroke}
              strokeWidth="3"
              strokeLinecap="round"
            />
            <circle
              cx={parent.x}
              cy={branchY}
              r="21"
              fill={COLORS.nodeFill}
              stroke={COLORS.branchStroke}
              strokeWidth="2.5"
            />
            <text
              x={parent.x}
              y={branchY + 4.5}
              textAnchor="middle"
              fill={COLORS.branchStroke}
              fontSize="12.5"
              fontWeight="800"
              fontFamily="JetBrains Mono, monospace"
            >
              {viewStyle === 'kerangka' ? 'C' : branch.gugus}
            </text>
            {viewStyle === 'kerangka' && (
              <text
                x={parent.x + 26}
                y={branchY + 4}
                textAnchor="start"
                fill={COLORS.textDim}
                fontSize="9.5"
                fontWeight="700"
                fontFamily="JetBrains Mono, monospace"
              >
                (+3H)
              </text>
            )}
            {branch.label && !isUp && (
              <text
                x={parent.x}
                y={labelY}
                textAnchor="middle"
                fill={COLORS.branchStroke}
                fontSize="10"
                fontWeight="700"
                fontFamily="Nunito, sans-serif"
              >
                {branch.label}
              </text>
            )}
          </g>
        );
      })}

      {/* Main Chain Carbon Nodes + Numbering */}
      {spec.nodes.map((node, idx) => {
        const isDoubleEnd =
          spec.doubleBondAfterIndex === idx ||
          spec.doubleBondAfterIndex === idx - 1;
        const nodeStroke = isDoubleEnd ? COLORS.doubleBond : COLORS.mainStroke;
        const hasUpOnThisNode = spec.branches.some(
          (b) => b.parentIndex === idx && b.dir === 'up'
        );
        const hasDownOnThisNode = spec.branches.some(
          (b) => b.parentIndex === idx && b.dir === 'down'
        );
        const badgeX = hasUpOnThisNode ? node.x - 26 : node.x;
        const badgeY = hasUpOnThisNode ? node.y - 24 : node.y - 31;

        return (
          <g key={`node-${node.num}`}>
            <circle
              cx={node.x}
              cy={node.y}
              r="22"
              fill={COLORS.nodeFill}
              stroke={nodeStroke}
              strokeWidth="2.5"
            />
            <text
              x={node.x}
              y={node.y + 4.5}
              textAnchor="middle"
              fill={COLORS.textLight}
              fontSize={viewStyle === 'kerangka' ? '14' : '12.5'}
              fontWeight="800"
              fontFamily="JetBrains Mono, monospace"
            >
              {viewStyle === 'kerangka' ? 'C' : node.gugus}
            </text>

            {/* IUPAC Number Badge */}
            <circle cx={badgeX} cy={badgeY} r="9.5" fill={nodeStroke} />
            <text
              x={badgeX}
              y={badgeY + 3.5}
              textAnchor="middle"
              fill={COLORS.bg}
              fontSize="10"
              fontWeight="800"
              fontFamily="JetBrains Mono, monospace"
            >
              {node.num}
            </text>

            {/* Subtle H-count helper in skeleton mode */}
            {viewStyle === 'kerangka' && !hasUpOnThisNode && (
              <text
                x={hasDownOnThisNode ? node.x + 27 : node.x}
                y={hasDownOnThisNode ? node.y + 24 : node.y + 34}
                textAnchor={hasDownOnThisNode ? 'start' : 'middle'}
                fill={COLORS.textDim}
                fontSize="9"
                fontWeight="700"
                fontFamily="JetBrains Mono, monospace"
              >
                {node.hCount > 0 ? `+${node.hCount}H` : '0H'}
              </text>
            )}
          </g>
        );
      })}

      {/* Bottom explanatory takeaway */}
      <text
        x="240"
        y={svgHeight - 10}
        textAnchor="middle"
        fill={COLORS.textMuted}
        fontSize="10.5"
        fontWeight="600"
        fontFamily="Nunito, sans-serif"
      >
        {spec.highlightNote}
      </text>
    </svg>
  );
};
