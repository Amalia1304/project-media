/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Diagram Rumus Struktur Gaya Buku Kimia SMA untuk Koleksi 9 Contoh Resmi IUPAC
 * Menampilkan:
 * - Penyorotan kotak putus-putus pada rantai induk (rantai terpanjang)
 * - Nomor atom C di atas rantai induk beserta panah arah penomoran (→ atau ←)
 * - Ikatan kovalen tunggal (—), rangkap dua (=), dan rangkap tiga (≡)
 * - Cabang alkil vertikal (—CH₃ dan —CH₂—CH₃) beserta label cabangnya
 */

import React from 'react';

interface ChainCarbon {
  formula: string;
  num: number;
  bondNext?: 1 | 2 | 3;
  branch?: {
    label: string;
    groups: string[];
  };
}

interface TextbookDiagramSpec {
  arah: 'kiri-ke-kanan' | 'kanan-ke-kiri' | 'simetris';
  arahLabel: string;
  chain: ChainCarbon[];
}

const DIAGRAM_SPECS: Record<string, TextbookDiagramSpec> = {
  'ex-1': {
    arah: 'kiri-ke-kanan',
    arahLabel: 'Arah penomoran dari kiri ke kanan (cabang lebih dekat ke ujung kiri)',
    chain: [
      { formula: 'CH3', num: 1, bondNext: 1 },
      {
        formula: 'CH',
        num: 2,
        bondNext: 1,
        branch: { label: 'metil', groups: ['CH3'] },
      },
      { formula: 'CH2', num: 3, bondNext: 1 },
      { formula: 'CH3', num: 4 },
    ],
  },
  'ex-2': {
    arah: 'simetris',
    arahLabel: 'Simetris: penomoran dari kiri atau kanan menghasilkan nomor cabang 2 dan 3',
    chain: [
      { formula: 'CH3', num: 1, bondNext: 1 },
      {
        formula: 'CH',
        num: 2,
        bondNext: 1,
        branch: { label: 'metil', groups: ['CH3'] },
      },
      {
        formula: 'CH',
        num: 3,
        bondNext: 1,
        branch: { label: 'metil', groups: ['CH3'] },
      },
      { formula: 'CH3', num: 4 },
    ],
  },
  'ex-3': {
    arah: 'kiri-ke-kanan',
    arahLabel: 'Arah penomoran dari kiri ke kanan (himpunan nomor cabang terkecil: 2, 3)',
    chain: [
      { formula: 'CH3', num: 1, bondNext: 1 },
      {
        formula: 'CH',
        num: 2,
        bondNext: 1,
        branch: { label: 'metil', groups: ['CH3'] },
      },
      {
        formula: 'CH',
        num: 3,
        bondNext: 1,
        branch: { label: 'etil', groups: ['CH2', 'CH3'] },
      },
      { formula: 'CH2', num: 4, bondNext: 1 },
      { formula: 'CH3', num: 5 },
    ],
  },
  'ex-4': {
    arah: 'kanan-ke-kiri',
    arahLabel: 'Arah penomoran dari kanan ke kiri (ikatan rangkap = lebih dekat ke ujung kanan)',
    chain: [
      { formula: 'CH3', num: 5, bondNext: 1 },
      { formula: 'CH2', num: 4, bondNext: 1 },
      { formula: 'CH', num: 3, bondNext: 2 },
      { formula: 'CH', num: 2, bondNext: 1 },
      { formula: 'CH3', num: 1 },
    ],
  },
  'ex-5': {
    arah: 'kiri-ke-kanan',
    arahLabel: 'Arah penomoran dari kiri ke kanan (ikatan rangkap = di ujung kiri, C-1)',
    chain: [
      { formula: 'CH2', num: 1, bondNext: 2 },
      {
        formula: 'C',
        num: 2,
        bondNext: 1,
        branch: { label: 'metil', groups: ['CH3'] },
      },
      { formula: 'CH2', num: 3, bondNext: 1 },
      { formula: 'CH3', num: 4 },
    ],
  },
  'ex-6': {
    arah: 'kanan-ke-kiri',
    arahLabel: 'Arah penomoran dari kanan ke kiri (ikatan rangkap = paling dekat ke ujung kanan)',
    chain: [
      { formula: 'CH3', num: 5, bondNext: 1 },
      { formula: 'CH2', num: 4, bondNext: 1 },
      {
        formula: 'C',
        num: 3,
        bondNext: 2,
        branch: { label: 'metil', groups: ['CH3'] },
      },
      {
        formula: 'C',
        num: 2,
        bondNext: 1,
        branch: { label: 'metil', groups: ['CH3'] },
      },
      { formula: 'CH3', num: 1 },
    ],
  },
  'ex-7': {
    arah: 'kiri-ke-kanan',
    arahLabel: 'Arah penomoran dari kiri ke kanan (ikatan rangkap ≡ lebih dekat ke ujung kiri)',
    chain: [
      { formula: 'CH3', num: 1, bondNext: 1 },
      { formula: 'C', num: 2, bondNext: 3 },
      { formula: 'C', num: 3, bondNext: 1 },
      { formula: 'CH2', num: 4, bondNext: 1 },
      { formula: 'CH3', num: 5 },
    ],
  },
  'ex-8': {
    arah: 'kanan-ke-kiri',
    arahLabel: 'Arah penomoran dari kanan ke kiri (prioritas ikatan rangkap ≡, bukan cabang)',
    chain: [
      { formula: 'CH3', num: 4, bondNext: 1 },
      {
        formula: 'CH',
        num: 3,
        bondNext: 1,
        branch: { label: 'metil', groups: ['CH3'] },
      },
      { formula: 'C', num: 2, bondNext: 3 },
      { formula: 'CH', num: 1 },
    ],
  },
  'ex-9': {
    arah: 'kiri-ke-kanan',
    arahLabel: 'Arah penomoran dari kiri ke kanan (ikatan rangkap ≡ berada di ujung kiri, C-1)',
    chain: [
      { formula: 'CH', num: 1, bondNext: 3 },
      { formula: 'C', num: 2, bondNext: 1 },
      {
        formula: 'CH',
        num: 3,
        bondNext: 1,
        branch: { label: 'metil', groups: ['CH3'] },
      },
      {
        formula: 'CH',
        num: 4,
        bondNext: 1,
        branch: { label: 'metil', groups: ['CH3'] },
      },
      { formula: 'CH3', num: 5 },
    ],
  },
};

// Render formula string such as "CH3", "CH2", "CH", "C" with SVG tspans for crisp subscripts
const renderSvgFormula = (
  formula: string,
  x: number,
  y: number,
  color: string
) => {
  const match = formula.match(/^([A-Za-z]+)(\d*)$/);
  if (!match) {
    return (
      <text
        x={x}
        y={y}
        textAnchor="middle"
        fill={color}
        fontSize="17"
        fontWeight="700"
        fontFamily="JetBrains Mono, monospace"
      >
        {formula}
      </text>
    );
  }
  const [, letters, digits] = match;
  return (
    <text
      x={x}
      y={y}
      textAnchor="middle"
      fill={color}
      fontSize="17"
      fontWeight="700"
      fontFamily="JetBrains Mono, monospace"
    >
      {letters}
      {digits && (
        <tspan dy="4.5" fontSize="12" fontWeight="700">
          {digits}
        </tspan>
      )}
    </text>
  );
};

interface ContohStrukturDiagramSvgProps {
  contohId: string;
  golongan: 'alkana' | 'alkena' | 'alkuna';
}

export const ContohStrukturDiagramSvg: React.FC<ContohStrukturDiagramSvgProps> = ({
  contohId,
  golongan,
}) => {
  const spec = DIAGRAM_SPECS[contohId];
  if (!spec) return null;

  const chainCount = spec.chain.length;
  const maxBranchDepth = spec.chain.reduce(
    (max, item) => Math.max(max, item.branch?.groups.length || 0),
    0
  );

  const spacing = 104;
  const startX = 76;
  const width = startX * 2 + (chainCount - 1) * spacing;
  const mainY = 92;
  const branchStep = 56;
  const height = mainY + 42 + maxBranchDepth * branchStep + (maxBranchDepth > 0 ? 18 : 10);

  const multiBondColor =
    golongan === 'alkena' ? '#B4A7FF' : golongan === 'alkuna' ? '#FFA8C5' : '#5EEAD4';

  const arrowStartX = startX - 18;
  const arrowEndX = startX + (chainCount - 1) * spacing + 18;
  const arrowY = 26;

  return (
    <div className="bg-[#1E1850] border border-[#3A3280] rounded-xl p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <span className="font-semibold text-[#EEEDFB]">
          Rumus Struktur & Penomoran Rantai Induk:
        </span>
        <span className="text-[#FDE68A] font-medium">
          {spec.arahLabel}
        </span>
      </div>

      <div className="w-full overflow-x-auto bg-[#0F0B2A] border border-[#3A3280] rounded-xl p-3">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto select-none mx-auto block"
          style={{ maxWidth: `${Math.max(460, width)}px` }}
          role="img"
          aria-label={`Struktur kimia dengan penomoran ${spec.arahLabel}`}
        >
          {/* Directional Numbering Arrow */}
          <g>
            <line
              x1={arrowStartX}
              y1={arrowY}
              x2={arrowEndX}
              y2={arrowY}
              stroke="#FDE68A"
              strokeWidth="2"
              strokeDasharray={spec.arah === 'simetris' ? '4 4' : undefined}
            />
            {spec.arah !== 'kanan-ke-kiri' && (
              <polygon
                points={`${arrowEndX},${arrowY} ${arrowEndX - 9},${arrowY - 4.5} ${arrowEndX - 9},${arrowY + 4.5}`}
                fill="#FDE68A"
              />
            )}
            {spec.arah !== 'kiri-ke-kanan' && (
              <polygon
                points={`${arrowStartX},${arrowY} ${arrowStartX + 9},${arrowY - 4.5} ${arrowStartX + 9},${arrowY + 4.5}`}
                fill="#FDE68A"
              />
            )}
          </g>

          {/* Main Chain Dashed Enclosure (Buku SMA Style) */}
          <rect
            x={startX - 34}
            y={mainY - 26}
            width={(chainCount - 1) * spacing + 68}
            height={50}
            rx={12}
            fill="rgba(94, 234, 212, 0.05)"
            stroke="#5EEAD4"
            strokeOpacity="0.45"
            strokeWidth="1.5"
            strokeDasharray="6 4"
          />

          {/* Horizontal Bonds on Main Chain */}
          {spec.chain.map((atom, idx) => {
            if (!atom.bondNext || idx === chainCount - 1) return null;
            const x1 = startX + idx * spacing + 25;
            const x2 = startX + (idx + 1) * spacing - 25;

            if (atom.bondNext === 1) {
              return (
                <line
                  key={`b-${idx}`}
                  x1={x1}
                  y1={mainY - 3}
                  x2={x2}
                  y2={mainY - 3}
                  stroke="#948EC7"
                  strokeWidth="2.8"
                  strokeLinecap="round"
                />
              );
            }

            if (atom.bondNext === 2) {
              return (
                <g key={`b-${idx}`}>
                  <line
                    x1={x1}
                    y1={mainY - 7}
                    x2={x2}
                    y2={mainY - 7}
                    stroke={multiBondColor}
                    strokeWidth="2.8"
                    strokeLinecap="round"
                  />
                  <line
                    x1={x1}
                    y1={mainY + 1}
                    x2={x2}
                    y2={mainY + 1}
                    stroke={multiBondColor}
                    strokeWidth="2.8"
                    strokeLinecap="round"
                  />
                </g>
              );
            }

            // Triple bond
            return (
              <g key={`b-${idx}`}>
                <line
                  x1={x1}
                  y1={mainY - 9}
                  x2={x2}
                  y2={mainY - 9}
                  stroke={multiBondColor}
                  strokeWidth="2.4"
                  strokeLinecap="round"
                />
                <line
                  x1={x1}
                  y1={mainY - 3}
                  x2={x2}
                  y2={mainY - 3}
                  stroke={multiBondColor}
                  strokeWidth="2.4"
                  strokeLinecap="round"
                />
                <line
                  x1={x1}
                  y1={mainY + 3}
                  x2={x2}
                  y2={mainY + 3}
                  stroke={multiBondColor}
                  strokeWidth="2.4"
                  strokeLinecap="round"
                />
              </g>
            );
          })}

          {/* Main Chain Atoms, Carbon Numbers & Vertical Branches */}
          {spec.chain.map((atom, idx) => {
            const cx = startX + idx * spacing;

            return (
              <g key={`c-${idx}`}>
                {/* Carbon Number Badge above Main Chain */}
                <circle
                  cx={cx}
                  cy={mainY - 41}
                  r="11"
                  fill="#1E1850"
                  stroke="#FDE68A"
                  strokeWidth="1.5"
                />
                <text
                  x={cx}
                  y={mainY - 37}
                  textAnchor="middle"
                  fill="#FDE68A"
                  fontSize="11"
                  fontWeight="800"
                  fontFamily="JetBrains Mono, monospace"
                >
                  {atom.num}
                </text>

                {/* Main Chain Atom Formula */}
                {renderSvgFormula(atom.formula, cx, mainY + 4, '#EEEDFB')}

                {/* Vertical Branch (if present) */}
                {atom.branch && (
                  <g>
                    {atom.branch.groups.map((grp, gIdx) => {
                      const prevY = gIdx === 0 ? mainY + 14 : mainY + gIdx * branchStep + 14;
                      const currY = mainY + (gIdx + 1) * branchStep;
                      return (
                        <g key={`br-${gIdx}`}>
                          <line
                            x1={cx}
                            y1={prevY}
                            x2={cx}
                            y2={currY - 17}
                            stroke="#FFA8C5"
                            strokeWidth="2.5"
                            strokeLinecap="round"
                          />
                          {renderSvgFormula(grp, cx, currY + 3, '#FFA8C5')}
                        </g>
                      );
                    })}
                    {/* Subtle branch name annotation below branch */}
                    <text
                      x={cx}
                      y={mainY + atom.branch.groups.length * branchStep + 24}
                      textAnchor="middle"
                      fill="#B8B5DE"
                      fontSize="10.5"
                      fontWeight="600"
                    >
                      ({atom.branch.label})
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </svg>
      </div>

      {/* Compact Legend */}
      <div className="flex flex-wrap items-center gap-x-5 gap-y-1.5 text-[11px] text-[#B8B5DE]">
        <span className="inline-flex items-center gap-1.5">
          <span className="w-3.5 h-2.5 rounded-sm border border-dashed border-[#5EEAD4] bg-[#5EEAD4]/10 inline-block" />
          <span>Rantai induk terpanjang</span>
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full border border-[#FDE68A] bg-[#1E1850] text-[#FDE68A] text-[8px] font-mono font-bold inline-flex items-center justify-center">
            1
          </span>
          <span>Nomor atom C & arah penomoran</span>
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-[#FFA8C5] inline-block" />
          <span>Cabang alkil</span>
        </span>
      </div>
    </div>
  );
};
