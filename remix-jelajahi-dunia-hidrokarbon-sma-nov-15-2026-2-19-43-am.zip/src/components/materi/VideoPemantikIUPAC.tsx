/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Komponen Video Pemantik sebelum Sub-Bab 2.5 (Tata Nama IUPAC)
 * Menampilkan video pengantar tata nama hidrokarbon secara bersih di atas Sub-Bab 2.5.
 */

import React from 'react';
import { PlayCircle } from 'lucide-react';

export const VideoPemantikIUPAC: React.FC = () => {
  return (
    <section
      aria-label="Video Pemantik Tata Nama Hidrokarbon"
      className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-6 sm:p-8 space-y-5 shadow-lg"
    >
      <div className="space-y-2">
        <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs font-semibold text-[#B4A7FF]">
          <span className="inline-flex items-center gap-1.5">
            <PlayCircle className="w-3.5 h-3.5" />
            <span>Video Pemantik</span>
          </span>
          <span className="text-[#3A3280]" aria-hidden="true">·</span>
          <span className="text-[#B8B5DE]">Pengantar Sub-Bab 2.5 (Tata Nama IUPAC)</span>
        </div>

        <h3 className="text-xl sm:text-2xl font-bold text-[#EEEDFB]">
          Mengapa Senyawa Hidrokarbon Butuh Nama IUPAC?
        </h3>

        <p className="text-xs sm:text-sm text-[#B8B5DE] leading-relaxed">
          Simak video singkat berikut sebagai pengantar sebelum mempelajari aturan tata nama IUPAC.
        </p>
      </div>

      <div className="rounded-xl overflow-hidden border border-[#3A3280] bg-[#0F0B2A]">
        <video
          controls
          playsInline
          preload="metadata"
          className="w-full aspect-video block bg-[#0F0B2A]"
          src="/assets/aistudio/tata-nama-hidrokarbon_1b1fc46a.mp4"
        >
          Peramban Anda tidak mendukung pemutar video HTML5.
        </video>
      </div>
    </section>
  );
};
