/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Visualisasi Interaktif Kekhasan Atom Karbon (Sub-Bab 1.1)
 * 1. Konfigurasi elektron ₆C (K=2, L=4) & model titik Lewis (4 elektron valensi)
 * 2. Pembentukan 4 ikatan kovalen stabil (oktet pada CH₄)
 * 3. Jari-jari atom relatif kecil (2 kulit) & pembentukan rantai C yang kuat
 */

import React, { useState } from 'react';
import { Atom, Link2, Sparkles } from 'lucide-react';

type KekhasanTab = 'konfigurasi' | 'oktet' | 'rantai';

export const KekhasanKarbonVisualizer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<KekhasanTab>('konfigurasi');

  const tabs: {
    id: KekhasanTab;
    nomor: string;
    judul: string;
    subjudul: string;
    icon: React.ReactNode;
  }[] = [
    {
      id: 'konfigurasi',
      nomor: '01',
      judul: '4 Elektron Valensi',
      subjudul: 'Konfigurasi ₆C (2, 4)',
      icon: <Atom className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'oktet',
      nomor: '02',
      judul: '4 Ikatan Kovalen',
      subjudul: 'Mencapai Oktet (CH₄)',
      icon: <Link2 className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'rantai',
      nomor: '03',
      judul: 'Jari-Jari Kecil',
      subjudul: 'Rantai Karbon Kuat',
      icon: <Sparkles className="w-4 h-4 shrink-0" />,
    },
  ];

  return (
    <div className="bg-[#0F0B2A] border border-[#3A3280] rounded-2xl p-4 sm:p-5 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#5EEAD4]">
            Visualisasi Konsep Sub-Bab 1.1
          </span>
          <h4 className="text-base sm:text-lg font-bold text-[#EEEDFB]">
            Mengapa Atom Karbon Begitu Istimewa?
          </h4>
        </div>
        <span className="text-xs text-[#8E8BB5]">
          Pilih aspek kekhasan untuk melihat diagramnya
        </span>
      </div>

      {/* 3-Tab Selector */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`p-3 min-h-[54px] rounded-xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
                isActive
                  ? 'bg-[#1E1850] border-[#5EEAD4] text-[#EEEDFB] shadow-md shadow-[#5EEAD4]/10'
                  : 'bg-[#150F38] border-[#3A3280] text-[#B8B5DE] hover:text-[#EEEDFB] hover:border-[#8E8BB5]'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                  isActive
                    ? 'bg-[#5EEAD4] text-[#0F0B2A]'
                    : 'bg-[#0F0B2A] text-[#5EEAD4] border border-[#3A3280]'
                }`}
              >
                {tab.icon}
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold truncate">{tab.judul}</div>
                <div className="text-[11px] text-[#8E8BB5] truncate">
                  {tab.subjudul}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* SVG Visualization Stage */}
      <div className="w-full overflow-x-auto bg-[#150F38] border border-[#3A3280] rounded-xl p-3 sm:p-4">
        {activeTab === 'konfigurasi' && (
          <svg
            viewBox="0 0 540 235"
            className="mx-auto block w-full max-w-[540px] min-w-[300px] h-auto select-none"
            role="img"
            aria-label="Diagram Bohr dan Struktur Lewis Atom Karbon dengan 4 elektron valensi"
          >
            {/* Left Side: Bohr Shell Model */}
            <text
              x="145"
              y="22"
              textAnchor="middle"
              fill="#EEEDFB"
              fontSize="12"
              fontWeight="800"
              fontFamily="Nunito, sans-serif"
            >
              Model Kulit Atom ₆C (K = 2, L = 4)
            </text>

            {/* Outer Shell L (Valence) */}
            <circle
              cx="145"
              cy="115"
              r="70"
              fill="none"
              stroke="#5EEAD4"
              strokeWidth="2"
              strokeDasharray="5 4"
            />
            {/* Inner Shell K */}
            <circle
              cx="145"
              cy="115"
              r="38"
              fill="none"
              stroke="#B4A7FF"
              strokeWidth="1.75"
            />

            {/* Nucleus */}
            <circle
              cx="145"
              cy="115"
              r="19"
              fill="#1E1850"
              stroke="#FDE68A"
              strokeWidth="2.5"
            />
            <text
              x="145"
              y="113"
              textAnchor="middle"
              fill="#FDE68A"
              fontSize="11"
              fontWeight="800"
              fontFamily="JetBrains Mono, monospace"
            >
              ₆C
            </text>
            <text
              x="145"
              y="125"
              textAnchor="middle"
              fill="#B8B5DE"
              fontSize="8.5"
              fontWeight="700"
              fontFamily="JetBrains Mono, monospace"
            >
              6p⁺ 6n⁰
            </text>

            {/* 2 Electrons on Shell K */}
            <circle cx="145" cy="77" r="5.5" fill="#B4A7FF" />
            <text
              x="145"
              y="80"
              textAnchor="middle"
              fill="#0F0B2A"
              fontSize="8"
              fontWeight="800"
            >
              –
            </text>
            <circle cx="145" cy="153" r="5.5" fill="#B4A7FF" />
            <text
              x="145"
              y="156"
              textAnchor="middle"
              fill="#0F0B2A"
              fontSize="8"
              fontWeight="800"
            >
              –
            </text>

            {/* 4 Valence Electrons on Shell L (Top, Right, Bottom, Left) */}
            {[
              { x: 145, y: 45 },
              { x: 215, y: 115 },
              { x: 145, y: 185 },
              { x: 75, y: 115 },
            ].map((pos, idx) => (
              <g key={`val-${idx}`}>
                <circle cx={pos.x} cy={pos.y} r="10" fill="#5EEAD4" opacity="0.22" />
                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r="6"
                  fill="#5EEAD4"
                  stroke="#0F0B2A"
                  strokeWidth="1.5"
                />
              </g>
            ))}

            {/* Shell Legend cleanly centered below Bohr atom */}
            <circle cx="62" cy="204" r="4.5" fill="#B4A7FF" />
            <text
              x="72"
              y="208"
              textAnchor="start"
              fill="#B4A7FF"
              fontSize="10.5"
              fontWeight="700"
              fontFamily="Nunito, sans-serif"
            >
              Kulit K = 2 elektron (dalam)
            </text>
            <circle cx="62" cy="222" r="4.5" fill="#5EEAD4" />
            <text
              x="72"
              y="226"
              textAnchor="start"
              fill="#5EEAD4"
              fontSize="10.5"
              fontWeight="800"
              fontFamily="Nunito, sans-serif"
            >
              Kulit L = 4 elektron valensi (luar)
            </text>

            {/* Divider Arrow */}
            <line
              x1="286"
              y1="42"
              x2="286"
              y2="210"
              stroke="#3A3280"
              strokeWidth="1.5"
              strokeDasharray="4 4"
            />

            {/* Right Side: Lewis Dot Structure & 4 Bonding Hands */}
            <text
              x="412"
              y="22"
              textAnchor="middle"
              fill="#EEEDFB"
              fontSize="12"
              fontWeight="800"
              fontFamily="Nunito, sans-serif"
            >
              Struktur Lewis (4 Tangan Ikatan)
            </text>

            {/* Central C */}
            <circle
              cx="412"
              cy="115"
              r="24"
              fill="#0F0B2A"
              stroke="#5EEAD4"
              strokeWidth="2.5"
            />
            <text
              x="412"
              y="122"
              textAnchor="middle"
              fill="#EEEDFB"
              fontSize="20"
              fontWeight="800"
              fontFamily="JetBrains Mono, monospace"
            >
              C
            </text>

            {/* 4 Valence Dots + Dashed Empty Slots (Need 4 more for Octet) */}
            {/* Top */}
            <circle cx="404" cy="76" r="5" fill="#5EEAD4" />
            <circle
              cx="420"
              cy="76"
              r="5"
              fill="none"
              stroke="#FDE68A"
              strokeWidth="1.6"
              strokeDasharray="2 2"
            />
            {/* Bottom */}
            <circle cx="404" cy="154" r="5" fill="#5EEAD4" />
            <circle
              cx="420"
              cy="154"
              r="5"
              fill="none"
              stroke="#FDE68A"
              strokeWidth="1.6"
              strokeDasharray="2 2"
            />
            {/* Left */}
            <circle cx="373" cy="107" r="5" fill="#5EEAD4" />
            <circle
              cx="373"
              cy="123"
              r="5"
              fill="none"
              stroke="#FDE68A"
              strokeWidth="1.6"
              strokeDasharray="2 2"
            />
            {/* Right */}
            <circle cx="451" cy="107" r="5" fill="#5EEAD4" />
            <circle
              cx="451"
              cy="123"
              r="5"
              fill="none"
              stroke="#FDE68A"
              strokeWidth="1.6"
              strokeDasharray="2 2"
            />

            {/* Legend at Bottom Right */}
            <circle cx="322" cy="192" r="4.5" fill="#5EEAD4" />
            <text
              x="333"
              y="196"
              fill="#B8B5DE"
              fontSize="10.5"
              fontWeight="600"
              fontFamily="Nunito, sans-serif"
            >
              4 e⁻ valensi milik C
            </text>
            <circle
              cx="322"
              cy="212"
              r="4.5"
              fill="none"
              stroke="#FDE68A"
              strokeWidth="1.6"
              strokeDasharray="2 2"
            />
            <text
              x="333"
              y="216"
              fill="#FDE68A"
              fontSize="10.5"
              fontWeight="600"
              fontFamily="Nunito, sans-serif"
            >
              4 posisi kosong (butuh 4 e⁻ → Oktet)
            </text>
          </svg>
        )}

        {activeTab === 'oktet' && (
          <svg
            viewBox="0 0 540 235"
            className="mx-auto block w-full max-w-[540px] min-w-[300px] h-auto select-none"
            role="img"
            aria-label="Pembentukan 4 ikatan kovalen pada metana CH4 untuk mencapai kestabilan oktet"
          >
            {/* Left: Lewis Electron Sharing (CH4) */}
            <text
              x="150"
              y="22"
              textAnchor="middle"
              fill="#EEEDFB"
              fontSize="12"
              fontWeight="800"
              fontFamily="Nunito, sans-serif"
            >
              Pemakaian Bersama Elektron (Oktet)
            </text>

            {/* Dashed Octet Circle around C */}
            <circle
              cx="150"
              cy="122"
              r="44"
              fill="rgba(94, 234, 212, 0.05)"
              stroke="#5EEAD4"
              strokeWidth="1.4"
              strokeDasharray="4 4"
            />

            {/* Central C */}
            <text
              x="150"
              y="129"
              textAnchor="middle"
              fill="#5EEAD4"
              fontSize="22"
              fontWeight="800"
              fontFamily="JetBrains Mono, monospace"
            >
              C
            </text>

            {/* 4 Hydrogen Atoms + Shared Electron Pairs */}
            {/* Top H */}
            <circle cx="143" cy="84" r="4.5" fill="#5EEAD4" />
            <circle cx="157" cy="84" r="4.5" fill="#FDE68A" />
            <circle cx="150" cy="56" r="15" fill="#0F0B2A" stroke="#FDE68A" strokeWidth="1.8" />
            <text x="150" y="61" textAnchor="middle" fill="#FDE68A" fontSize="14" fontWeight="800" fontFamily="JetBrains Mono, monospace">H</text>

            {/* Bottom H */}
            <circle cx="143" cy="160" r="4.5" fill="#5EEAD4" />
            <circle cx="157" cy="160" r="4.5" fill="#FDE68A" />
            <circle cx="150" cy="188" r="15" fill="#0F0B2A" stroke="#FDE68A" strokeWidth="1.8" />
            <text x="150" y="193" textAnchor="middle" fill="#FDE68A" fontSize="14" fontWeight="800" fontFamily="JetBrains Mono, monospace">H</text>

            {/* Left H */}
            <circle cx="112" cy="115" r="4.5" fill="#5EEAD4" />
            <circle cx="112" cy="129" r="4.5" fill="#FDE68A" />
            <circle cx="82" cy="122" r="15" fill="#0F0B2A" stroke="#FDE68A" strokeWidth="1.8" />
            <text x="82" y="127" textAnchor="middle" fill="#FDE68A" fontSize="14" fontWeight="800" fontFamily="JetBrains Mono, monospace">H</text>

            {/* Right H */}
            <circle cx="188" cy="115" r="4.5" fill="#5EEAD4" />
            <circle cx="188" cy="129" r="4.5" fill="#FDE68A" />
            <circle cx="218" cy="122" r="15" fill="#0F0B2A" stroke="#FDE68A" strokeWidth="1.8" />
            <text x="218" y="127" textAnchor="middle" fill="#FDE68A" fontSize="14" fontWeight="800" fontFamily="JetBrains Mono, monospace">H</text>

            <text
              x="150"
              y="222"
              textAnchor="middle"
              fill="#5EEAD4"
              fontSize="10.5"
              fontWeight="700"
              fontFamily="Nunito, sans-serif"
            >
              4 e⁻ (C) + 4 e⁻ (H) = 8 e⁻ di kulit terluar
            </text>

            {/* Arrow between Lewis and Structural Formula */}
            <line x1="264" y1="122" x2="306" y2="122" stroke="#B4A7FF" strokeWidth="2.5" />
            <polygon points="312,122 302,116.5 302,127.5" fill="#B4A7FF" />
            <text
              x="286"
              y="110"
              textAnchor="middle"
              fill="#B4A7FF"
              fontSize="10"
              fontWeight="700"
              fontFamily="Nunito, sans-serif"
            >
              4 Ikatan
            </text>

            {/* Right: Structural Formula with 4 Covalent Bonds */}
            <text
              x="422"
              y="22"
              textAnchor="middle"
              fill="#EEEDFB"
              fontSize="12"
              fontWeight="800"
              fontFamily="Nunito, sans-serif"
            >
              Rumus Struktur Metana (CH₄)
            </text>

            {/* 4 Covalent Lines */}
            <line x1="422" y1="100" x2="422" y2="74" stroke="#B4A7FF" strokeWidth="3" strokeLinecap="round" />
            <line x1="422" y1="144" x2="422" y2="170" stroke="#B4A7FF" strokeWidth="3" strokeLinecap="round" />
            <line x1="400" y1="122" x2="374" y2="122" stroke="#B4A7FF" strokeWidth="3" strokeLinecap="round" />
            <line x1="444" y1="122" x2="470" y2="122" stroke="#B4A7FF" strokeWidth="3" strokeLinecap="round" />

            <circle cx="422" cy="122" r="20" fill="#0F0B2A" stroke="#5EEAD4" strokeWidth="2.5" />
            <text x="422" y="128" textAnchor="middle" fill="#5EEAD4" fontSize="18" fontWeight="800" fontFamily="JetBrains Mono, monospace">C</text>

            <text x="422" y="64" textAnchor="middle" fill="#EEEDFB" fontSize="15" fontWeight="800" fontFamily="JetBrains Mono, monospace">H</text>
            <text x="422" y="188" textAnchor="middle" fill="#EEEDFB" fontSize="15" fontWeight="800" fontFamily="JetBrains Mono, monospace">H</text>
            <text x="360" y="127" textAnchor="middle" fill="#EEEDFB" fontSize="15" fontWeight="800" fontFamily="JetBrains Mono, monospace">H</text>
            <text x="484" y="127" textAnchor="middle" fill="#EEEDFB" fontSize="15" fontWeight="800" fontFamily="JetBrains Mono, monospace">H</text>

            <text
              x="422"
              y="222"
              textAnchor="middle"
              fill="#B8B5DE"
              fontSize="10.5"
              fontWeight="600"
              fontFamily="Nunito, sans-serif"
            >
              1 pasang elektron bersama = 1 garis ikatan (—)
            </text>
          </svg>
        )}

        {activeTab === 'rantai' && (
          <svg
            viewBox="0 0 540 235"
            className="mx-auto block w-full max-w-[540px] min-w-[300px] h-auto select-none"
            role="img"
            aria-label="Perbandingan ukuran jari-jari atom karbon dan kemampuan membentuk rantai panjang"
          >
            {/* Left Side: C vs Si atomic radius comparison */}
            <text
              x="138"
              y="22"
              textAnchor="middle"
              fill="#EEEDFB"
              fontSize="12"
              fontWeight="800"
              fontFamily="Nunito, sans-serif"
            >
              Jari-Jari Atom C Kecil (2 Kulit)
            </text>

            {/* Small C Atom (2 shells) */}
            <circle cx="90" cy="108" r="34" fill="rgba(94, 234, 212, 0.08)" stroke="#5EEAD4" strokeWidth="2" />
            <circle cx="90" cy="108" r="19" fill="none" stroke="#5EEAD4" strokeWidth="1.2" strokeDasharray="3 3" />
            <circle cx="90" cy="108" r="9" fill="#5EEAD4" />
            <text x="90" y="158" textAnchor="middle" fill="#5EEAD4" fontSize="11.5" fontWeight="800" fontFamily="JetBrains Mono, monospace">
              ₆C (2, 4)
            </text>
            <text x="90" y="173" textAnchor="middle" fill="#B8B5DE" fontSize="9.5" fontWeight="600" fontFamily="Nunito, sans-serif">
              2 kulit → ikatan kuat
            </text>

            {/* Larger Si Atom (3 shells) for contrast */}
            <circle cx="195" cy="108" r="46" fill="rgba(255, 168, 197, 0.05)" stroke="#FFA8C5" strokeWidth="1.5" strokeDasharray="4 3" />
            <circle cx="195" cy="108" r="31" fill="none" stroke="#FFA8C5" strokeWidth="1.1" strokeDasharray="3 3" />
            <circle cx="195" cy="108" r="17" fill="none" stroke="#FFA8C5" strokeWidth="1.1" strokeDasharray="3 3" />
            <circle cx="195" cy="108" r="9" fill="#FFA8C5" opacity="0.8" />
            <text x="195" y="170" textAnchor="middle" fill="#FFA8C5" fontSize="11" fontWeight="700" fontFamily="JetBrains Mono, monospace">
              ₁₄Si (2, 8, 4)
            </text>
            <text x="195" y="185" textAnchor="middle" fill="#8E8BB5" fontSize="9.5" fontWeight="600" fontFamily="Nunito, sans-serif">
              3 kulit → lebih besar
            </text>

            {/* Divider */}
            <line
              x1="265"
              y1="38"
              x2="265"
              y2="212"
              stroke="#3A3280"
              strokeWidth="1.5"
              strokeDasharray="4 4"
            />

            {/* Right Side: C-C Chain & Multiple Bond Versatility */}
            <text
              x="402"
              y="22"
              textAnchor="middle"
              fill="#EEEDFB"
              fontSize="12"
              fontWeight="800"
              fontFamily="Nunito, sans-serif"
            >
              Membentuk Rantai & Ikatan Beragam
            </text>

            {/* Long Chain C-C-C-C */}
            <line x1="305" y1="68" x2="498" y2="68" stroke="#5EEAD4" strokeWidth="3" />
            {[305, 369, 433, 498].map((cx, i) => (
              <g key={`chain-${i}`}>
                <circle cx={cx} cy="68" r="14" fill="#0F0B2A" stroke="#5EEAD4" strokeWidth="2.2" />
                <text x={cx} y="72.5" textAnchor="middle" fill="#EEEDFB" fontSize="12.5" fontWeight="800" fontFamily="JetBrains Mono, monospace">
                  C
                </text>
              </g>
            ))}
            <text x="402" y="96" textAnchor="middle" fill="#5EEAD4" fontSize="10" fontWeight="700" fontFamily="Nunito, sans-serif">
              Rantai C—C—C—C stabil & dapat sangat panjang
            </text>

            {/* Single, Double, Triple examples */}
            {/* Single C-C */}
            <line x1="302" y1="138" x2="342" y2="138" stroke="#5EEAD4" strokeWidth="2.8" />
            <circle cx="296" cy="138" r="11" fill="#0F0B2A" stroke="#5EEAD4" strokeWidth="2" />
            <circle cx="348" cy="138" r="11" fill="#0F0B2A" stroke="#5EEAD4" strokeWidth="2" />
            <text x="296" y="142" textAnchor="middle" fill="#EEEDFB" fontSize="11" fontWeight="800" fontFamily="JetBrains Mono, monospace">C</text>
            <text x="348" y="142" textAnchor="middle" fill="#EEEDFB" fontSize="11" fontWeight="800" fontFamily="JetBrains Mono, monospace">C</text>
            <text x="322" y="164" textAnchor="middle" fill="#B8B5DE" fontSize="10" fontWeight="700" fontFamily="Nunito, sans-serif">Tunggal (—)</text>

            {/* Double C=C */}
            <line x1="384" y1="135" x2="424" y2="135" stroke="#B4A7FF" strokeWidth="2.6" />
            <line x1="384" y1="141" x2="424" y2="141" stroke="#B4A7FF" strokeWidth="2.6" />
            <circle cx="378" cy="138" r="11" fill="#0F0B2A" stroke="#B4A7FF" strokeWidth="2" />
            <circle cx="430" cy="138" r="11" fill="#0F0B2A" stroke="#B4A7FF" strokeWidth="2" />
            <text x="378" y="142" textAnchor="middle" fill="#EEEDFB" fontSize="11" fontWeight="800" fontFamily="JetBrains Mono, monospace">C</text>
            <text x="430" y="142" textAnchor="middle" fill="#EEEDFB" fontSize="11" fontWeight="800" fontFamily="JetBrains Mono, monospace">C</text>
            <text x="404" y="164" textAnchor="middle" fill="#B4A7FF" fontSize="10" fontWeight="700" fontFamily="Nunito, sans-serif">Rangkap 2 (=)</text>

            {/* Triple C≡C */}
            <line x1="466" y1="133" x2="506" y2="133" stroke="#FFA8C5" strokeWidth="2.2" />
            <line x1="466" y1="138" x2="506" y2="138" stroke="#FFA8C5" strokeWidth="2.2" />
            <line x1="466" y1="143" x2="506" y2="143" stroke="#FFA8C5" strokeWidth="2.2" />
            <circle cx="460" cy="138" r="11" fill="#0F0B2A" stroke="#FFA8C5" strokeWidth="2" />
            <circle cx="512" cy="138" r="11" fill="#0F0B2A" stroke="#FFA8C5" strokeWidth="2" />
            <text x="460" y="142" textAnchor="middle" fill="#EEEDFB" fontSize="11" fontWeight="800" fontFamily="JetBrains Mono, monospace">C</text>
            <text x="512" y="142" textAnchor="middle" fill="#EEEDFB" fontSize="11" fontWeight="800" fontFamily="JetBrains Mono, monospace">C</text>
            <text x="486" y="164" textAnchor="middle" fill="#FFA8C5" fontSize="10" fontWeight="700" fontFamily="Nunito, sans-serif">Rangkap 3 (≡)</text>

            <text
              x="402"
              y="206"
              textAnchor="middle"
              fill="#B8B5DE"
              fontSize="10.5"
              fontWeight="600"
              fontFamily="Nunito, sans-serif"
            >
              Sesama atom C dapat berikatan tunggal, rangkap 2, hingga rangkap 3
            </text>
          </svg>
        )}
      </div>

      {/* Concise Pedagogical Takeaway for Active Tab */}
      <div className="p-3.5 bg-[#150F38] border border-[#3A3280] rounded-xl text-xs sm:text-sm text-[#B8B5DE] leading-relaxed">
        {activeTab === 'konfigurasi' && (
          <>
            <strong className="text-[#5EEAD4]">Inti Konsep:</strong> Atom karbon (₆C) hanya memiliki{' '}
            <strong className="text-[#EEEDFB]">4 elektron valensi</strong> di kulit terluar (L), sehingga memiliki{' '}
            <strong className="text-[#EEEDFB]">4 posisi kosong</strong> untuk berikatan secara kovalen agar mencapai susunan oktet (8 elektron) seperti gas mulia Neon.
          </>
        )}
        {activeTab === 'oktet' && (
          <>
            <strong className="text-[#5EEAD4]">Inti Konsep:</strong> Dengan menyumbangkan masing-masing 1 elektron untuk dipakai bersama, 1 atom C membentuk{' '}
            <strong className="text-[#EEEDFB]">4 pasang ikatan kovalen</strong> (misalnya dengan 4 atom H pada CH₄) sehingga setiap atom C selalu memiliki tepat 4 ikatan yang stabil.
          </>
        )}
        {activeTab === 'rantai' && (
          <>
            <strong className="text-[#5EEAD4]">Inti Konsep:</strong> Karena hanya memiliki{' '}
            <strong className="text-[#EEEDFB]">2 kulit elektron (K dan L)</strong>, jari-jari atom karbon relatif kecil (lebih kecil daripada Silikon yang punya 3 kulit). Hal ini membuat tarikan inti terhadap pasangan elektron ikatan sangat kuat sehingga terbentuk{' '}
            <strong className="text-[#EEEDFB]">rantai karbon yang panjang dan beraneka ragam</strong> (tunggal, rangkap 2, hingga rangkap 3).
          </>
        )}
      </div>
    </div>
  );
};
