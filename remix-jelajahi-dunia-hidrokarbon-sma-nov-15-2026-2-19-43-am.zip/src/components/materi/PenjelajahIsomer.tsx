/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Penjelajah Isomer Interaktif (KD 4.1)
 * Visualisasi struktur 2D & geometri cis-trans lengkap untuk seluruh isomer
 * C4H10, C5H12, C4H8, dan C5H10, dilengkapi mode Kerangka Karbon dan Bandingkan 2 Isomer.
 */

import React, { useState, useMemo } from 'react';
import { KEGIATAN_3_DATA, IsomerItem } from '../../data';
import {
  ChevronLeft,
  ChevronRight,
  Columns2,
  Eye,
  GitBranch,
  Info,
} from 'lucide-react';
import {
  IsomerDiagramSvg,
  GeometriMode,
  ViewStyleMode,
} from './IsomerDiagramSvg';

type FormulaKey = 'C4H10' | 'C5H12' | 'C4H8' | 'C5H10';

const ISOMER_TYPE_EXPLANATION: Record<
  'rangka' | 'posisi' | 'geometri',
  { judul: string; ringkas: string; colorClass: string }
> = {
  rangka: {
    judul: 'Isomer Rangka (Kerangka)',
    ringkas:
      'Rumus molekul sama, tetapi panjang rantai utama atau jumlah/susunan cabang atom karbonnya berbeda.',
    colorClass: 'text-[#FDE68A] border-[#FDE68A]/35 bg-[#FDE68A]/10',
  },
  posisi: {
    judul: 'Isomer Posisi',
    ringkas:
      'Kerangka rantai utama sama, tetapi letak (nomor atom C) ikatan rangkap dua atau posisi cabangnya bergeser.',
    colorClass: 'text-[#B4A7FF] border-[#B4A7FF]/35 bg-[#B4A7FF]/10',
  },
  geometri: {
    judul: 'Isomer Geometri (cis–trans)',
    ringkas:
      'Ikatan rangkap C=C bersifat kaku (tidak bisa berputar), sehingga letak gugus di sekitar C=C dapat sepihak (cis) atau berseberangan (trans).',
    colorClass: 'text-[#5EEAD4] border-[#5EEAD4]/35 bg-[#5EEAD4]/10',
  },
};

function getComparisonInsight(
  a: IsomerItem,
  b: IsomerItem,
  geoA: GeometriMode,
  geoB: GeometriMode,
  rumusMolekul: string
): { jenis: string; penjelasan: string } {
  const isSame = a.id === b.id;
  const isGeoA = a.svgType === '2-butena' || a.svgType === '2-pentena';

  if (isSame) {
    if (isGeoA && geoA !== geoB && geoA !== 'datar' && geoB !== 'datar') {
      return {
        jenis: 'Isomer Geometri (cis vs trans)',
        penjelasan: `Keduanya adalah ${a.namaIUPAC} (${rumusMolekul}), tetapi susunan ruang gugus alkil di sekitar ikatan rangkap C=C berbeda: bentuk cis (sepihak) vs trans (berseberangan).`,
      };
    }
    return {
      jenis: 'Senyawa Identik',
      penjelasan: `Kamu memilih struktur yang sama (${a.namaIUPAC}). Pilih isomer yang berbeda di sisi kanan untuk melihat perbedaannya.`,
    };
  }

  // Compare two different structural isomers
  const sameBaseType =
    a.tipeIsomer === 'posisi' && b.tipeIsomer === 'posisi';

  if (
    (a.svgType === '1-butena' && b.svgType === '2-butena') ||
    (a.svgType === '2-butena' && b.svgType === '1-butena') ||
    (a.svgType === '1-pentena' && b.svgType === '2-pentena') ||
    (a.svgType === '2-pentena' && b.svgType === '1-pentena')
  ) {
    return {
      jenis: 'Isomer Posisi (Letak Ikatan Rangkap C=C)',
      penjelasan: `Sama-sama memiliki rumus molekul ${rumusMolekul} dan panjang rantai utama lurus yang sama, tetapi posisi ikatan rangkap C=C bergeser antara C-1 dan C-2.`,
    };
  }

  if (
    (a.svgType === '2-metil-1-butena' && b.svgType === '3-metil-1-butena') ||
    (a.svgType === '3-metil-1-butena' && b.svgType === '2-metil-1-butena')
  ) {
    return {
      jenis: 'Isomer Posisi (Letak Cabang Metil)',
      penjelasan: `Keduanya punya rantai utama 1-butena (4 C, C=C di C-1), tetapi posisi cabang metil (—CH₃) bergeser dari atom C-2 ke atom C-3.`,
    };
  }

  if (
    (a.svgType === '2-metil-1-butena' && b.svgType === '2-metil-2-butena') ||
    (a.svgType === '2-metil-2-butena' && b.svgType === '2-metil-1-butena')
  ) {
    return {
      jenis: 'Isomer Posisi (Letak Ikatan Rangkap C=C)',
      penjelasan: `Keduanya berantai utama 4 C dengan cabang metil di C-2, namun posisi ikatan rangkap C=C berpindah dari C-1 ke C-2.`,
    };
  }

  if (sameBaseType) {
    return {
      jenis: 'Isomer Posisi',
      penjelasan: `Sama-sama memiliki rumus ${rumusMolekul}, perbedaannya terletak pada nomor posisi ikatan rangkap C=C atau posisi cabang pada rantai utama.`,
    };
  }

  return {
    jenis: 'Isomer Rangka (Panjang Rantai & Cabang Berbeda)',
    penjelasan: `Meskipun rumus molekulnya sama-sama ${rumusMolekul}, panjang rantai utama dan susunan percabangan atom karbon antara ${a.namaIUPAC} dan ${b.namaIUPAC} berbeda.`,
  };
}

export const PenjelajahIsomer: React.FC = () => {
  const [selectedFormulaKey, setSelectedFormulaKey] =
    useState<FormulaKey>('C4H10');
  const [selectedIsomerId, setSelectedIsomerId] = useState<string>('c4h10-1');
  const [compareIdA, setCompareIdA] = useState<string>('c4h10-1');
  const [compareIdB, setCompareIdB] = useState<string>('c4h10-2');

  const [explorerMode, setExplorerMode] = useState<'single' | 'compare'>(
    'single'
  );
  const [viewStyle, setViewStyle] = useState<ViewStyleMode>('gugus');
  const [geometriMode, setGeometriMode] = useState<GeometriMode>('cis');
  const [compareGeoA, setCompareGeoA] = useState<GeometriMode>('datar');
  const [compareGeoB, setCompareGeoB] = useState<GeometriMode>('cis');

  const formulaData = KEGIATAN_3_DATA.dataIsomer[selectedFormulaKey];
  const activeIndex = Math.max(
    0,
    formulaData.isomers.findIndex((i) => i.id === selectedIsomerId)
  );
  const activeIsomer = formulaData.isomers[activeIndex] || formulaData.isomers[0];

  const compareIsomerA =
    formulaData.isomers.find((i) => i.id === compareIdA) ||
    formulaData.isomers[0];
  const compareIsomerB =
    formulaData.isomers.find((i) => i.id === compareIdB) ||
    formulaData.isomers[Math.min(1, formulaData.isomers.length - 1)];

  const handleSelectFormula = (key: FormulaKey) => {
    setSelectedFormulaKey(key);
    const list = KEGIATAN_3_DATA.dataIsomer[key].isomers;
    setSelectedIsomerId(list[0].id);
    setCompareIdA(list[0].id);
    setCompareIdB(list[Math.min(1, list.length - 1)].id);
    setCompareGeoA('datar');
    setCompareGeoB('cis');
  };

  const handleStepIsomer = (delta: number) => {
    const total = formulaData.isomers.length;
    const nextIdx = (activeIndex + delta + total) % total;
    setSelectedIsomerId(formulaData.isomers[nextIdx].id);
  };

  const isGeoCapable =
    activeIsomer.svgType === '2-butena' || activeIsomer.svgType === '2-pentena';

  const activeTipeKey: 'rangka' | 'posisi' | 'geometri' =
    isGeoCapable && (geometriMode === 'cis' || geometriMode === 'trans')
      ? 'geometri'
      : activeIsomer.tipeIsomer === 'geometri'
      ? 'geometri'
      : activeIsomer.tipeIsomer === 'posisi'
      ? 'posisi'
      : 'rangka';

  const typeInfo = ISOMER_TYPE_EXPLANATION[activeTipeKey];

  const comparisonInsight = useMemo(
    () =>
      getComparisonInsight(
        compareIsomerA,
        compareIsomerB,
        compareGeoA,
        compareGeoB,
        formulaData.rumusMolekul
      ),
    [
      compareIsomerA,
      compareIsomerB,
      compareGeoA,
      compareGeoB,
      formulaData.rumusMolekul,
    ]
  );

  return (
    <div className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-4 sm:p-7 shadow-lg space-y-5">
      {/* Header + Mode Toggle */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-[#A99CFF]">
            Visualisasi Interaktif KD 4.1
          </span>
          <h3 className="text-xl sm:text-2xl font-bold text-[#EEEDFB] mt-1">
            Penjelajah Isomer Hidrokarbon
          </h3>
          <p className="text-xs sm:text-sm text-[#B8B5DE] mt-1 leading-relaxed max-w-2xl">
            Amati bagaimana senyawa dengan <strong>rumus molekul sama</strong> dapat memiliki bentuk rantai, posisi ikatan rangkap, maupun orientasi ruang <em>cis–trans</em> yang berbeda.
          </p>
        </div>

        {/* Mode Eksplorasi vs Bandingkan */}
        <div
          className="flex flex-col sm:flex-row w-full lg:w-fit bg-[#0F0B2A] p-1 rounded-xl border border-[#3A3280] gap-1 shrink-0"
          role="tablist"
          aria-label="Mode penjelajah isomer"
        >
          <button
            type="button"
            role="tab"
            aria-selected={explorerMode === 'single'}
            onClick={() => setExplorerMode('single')}
            className={`px-3.5 py-2 min-h-[40px] rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              explorerMode === 'single'
                ? 'bg-[#1E1850] text-[#5EEAD4] border border-[#5EEAD4]/50'
                : 'text-[#B8B5DE] hover:text-[#EEEDFB] border border-transparent'
            }`}
          >
            <Eye className="w-3.5 h-3.5 shrink-0" />
            <span>Eksplorasi Tunggal</span>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={explorerMode === 'compare'}
            onClick={() => setExplorerMode('compare')}
            className={`px-3.5 py-2 min-h-[40px] rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              explorerMode === 'compare'
                ? 'bg-[#1E1850] text-[#A99CFF] border border-[#A99CFF]/50'
                : 'text-[#B8B5DE] hover:text-[#EEEDFB] border border-transparent'
            }`}
          >
            <Columns2 className="w-3.5 h-3.5 shrink-0" />
            <span>Bandingkan 2 Isomer</span>
          </button>
        </div>
      </div>

      {/* Formula Selector Tabs (C4H10, C5H12, C4H8, C5H10) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
        {(['C4H10', 'C5H12', 'C4H8', 'C5H10'] as const).map((key) => {
          const item = KEGIATAN_3_DATA.dataIsomer[key];
          const isSelected = selectedFormulaKey === key;
          return (
            <button
              key={key}
              type="button"
              onClick={() => handleSelectFormula(key)}
              className={`p-3.5 min-h-[72px] rounded-xl border text-left transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#150F38] border-[#A99CFF] shadow-md shadow-[#A99CFF]/15'
                  : 'bg-[#0F0B2A] border-[#3A3280] text-[#B8B5DE] hover:text-[#EEEDFB]'
              }`}
            >
              <div className="flex items-center justify-between gap-2 mb-1">
                <span
                  className={`font-mono text-base sm:text-lg font-extrabold ${
                    isSelected ? 'text-[#A99CFF]' : 'text-[#EEEDFB]'
                  }`}
                >
                  {item.rumusMolekul}
                </span>
                <span className="text-[11px] font-mono font-bold text-[#5EEAD4] tabular-nums shrink-0">
                  {item.totalIsomerStruktur} struktur
                </span>
              </div>
              <div className="text-[11px] text-[#8E8BB5] truncate">
                {item.golongan}
              </div>
            </button>
          );
        })}
      </div>

      {/* View Style + Color Legend Bar */}
      <div className="p-3.5 bg-[#0F0B2A] border border-[#3A3280] rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Gugus vs Kerangka Karbon toggle */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#8E8BB5]">
            Tampilan Atom:
          </span>
          <div className="inline-flex bg-[#150F38] border border-[#3A3280] rounded-lg p-0.5">
            <button
              type="button"
              onClick={() => setViewStyle('gugus')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer ${
                viewStyle === 'gugus'
                  ? 'bg-[#5EEAD4] text-[#0F0B2A]'
                  : 'text-[#B8B5DE] hover:text-[#EEEDFB]'
              }`}
            >
              Gugus (CH₃ / CH₂)
            </button>
            <button
              type="button"
              onClick={() => setViewStyle('kerangka')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer ${
                viewStyle === 'kerangka'
                  ? 'bg-[#5EEAD4] text-[#0F0B2A]'
                  : 'text-[#B8B5DE] hover:text-[#EEEDFB]'
              }`}
            >
              Kerangka Atom C
            </button>
          </div>
        </div>

        {/* Visual Color Legend */}
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] text-[#B8B5DE]">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#5EEAD4] inline-block" />
            Rantai Utama
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#FDE68A] inline-block" />
            Cabang Metil
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#B4A7FF] inline-block" />
            Ikatan Rangkap (=)
          </span>
        </div>
      </div>

      {explorerMode === 'single' ? (
        <>
          {/* Isomer Variants Grid / Wrap Bar */}
          <div className="p-4 bg-[#0F0B2A] border border-[#3A3280] rounded-2xl space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs uppercase font-bold tracking-wider text-[#B8B5DE]">
                Pilih Isomer {formulaData.rumusMolekul}:
              </span>
              <span className="text-xs text-[#8E8BB5]">
                {formulaData.catatanKhusus}
              </span>
            </div>

            <div className="flex flex-wrap gap-2">
              {formulaData.isomers.map((iso, idx) => {
                const isSelected = activeIsomer.id === iso.id;
                return (
                  <button
                    key={iso.id}
                    type="button"
                    onClick={() => setSelectedIsomerId(iso.id)}
                    className={`px-3.5 py-2.5 min-h-[40px] rounded-xl text-xs font-bold transition-all cursor-pointer border flex items-center gap-2 ${
                      isSelected
                        ? 'bg-[#150F38] border-[#5EEAD4] text-[#5EEAD4] shadow-md shadow-[#5EEAD4]/10'
                        : 'bg-[#1E1850] border-[#3A3280] text-[#B8B5DE] hover:text-[#EEEDFB]'
                    }`}
                  >
                    <span className="font-mono text-[11px] text-[#8E8BB5] tabular-nums">
                      #{idx + 1}
                    </span>
                    <span>{iso.namaIUPAC}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Isomer Visualization Card */}
          <div className="p-4 sm:p-6 bg-[#0F0B2A] border border-[#3A3280] rounded-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#3A3280] pb-4">
              <div>
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span
                    className={`font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-md border ${typeInfo.colorClass}`}
                  >
                    {typeInfo.judul}
                  </span>
                  <span className="font-mono text-[#B8B5DE]">
                    Rumus: {formulaData.rumusMolekul}
                  </span>
                </div>
                <h4 className="text-xl sm:text-2xl font-extrabold text-[#EEEDFB] mt-1.5">
                  {isGeoCapable && geometriMode !== 'datar'
                    ? `${geometriMode}-${activeIsomer.namaIUPAC}`
                    : activeIsomer.namaIUPAC}
                </h4>
              </div>

              {/* Prev / Next Stepper */}
              <div className="flex items-center gap-2 self-start sm:self-center">
                <button
                  type="button"
                  onClick={() => handleStepIsomer(-1)}
                  aria-label="Isomer sebelumnya"
                  className="p-2 min-w-[40px] min-h-[40px] rounded-xl bg-[#150F38] border border-[#3A3280] text-[#B8B5DE] hover:text-[#EEEDFB] hover:border-[#A99CFF] transition-colors cursor-pointer flex items-center justify-center"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="font-mono text-xs font-bold text-[#EEEDFB] px-2 tabular-nums">
                  {activeIndex + 1} / {formulaData.isomers.length}
                </span>
                <button
                  type="button"
                  onClick={() => handleStepIsomer(1)}
                  aria-label="Isomer berikutnya"
                  className="p-2 min-w-[40px] min-h-[40px] rounded-xl bg-[#150F38] border border-[#3A3280] text-[#B8B5DE] hover:text-[#EEEDFB] hover:border-[#A99CFF] transition-colors cursor-pointer flex items-center justify-center"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Geometric cis/trans toggle for 2-butena & 2-pentena */}
            {isGeoCapable && (
              <div className="p-3 bg-[#150F38] border border-[#3A3280] rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div className="flex items-center gap-2 text-xs text-[#B8B5DE]">
                  <GitBranch className="w-4 h-4 text-[#5EEAD4] shrink-0" />
                  <span>
                    Senyawa ini memiliki <strong>isomer geometri ruang</strong> di sekitar ikatan rangkap C=C:
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  {(
                    [
                      { key: 'datar', label: 'Rantai Datar' },
                      { key: 'cis', label: `cis-${activeIsomer.svgType}` },
                      { key: 'trans', label: `trans-${activeIsomer.svgType}` },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.key}
                      type="button"
                      onClick={() => setGeometriMode(opt.key)}
                      className={`px-3 py-1.5 min-h-[36px] rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        geometriMode === opt.key
                          ? opt.key === 'trans'
                            ? 'bg-[#FFA8C5] text-[#0F0B2A]'
                            : opt.key === 'cis'
                            ? 'bg-[#5EEAD4] text-[#0F0B2A]'
                            : 'bg-[#A99CFF] text-[#0F0B2A]'
                          : 'bg-[#0F0B2A] text-[#B8B5DE] border border-[#3A3280] hover:text-[#EEEDFB]'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* 2D Molecular SVG Canvas (Scrollable safely on ultra-narrow viewports) */}
            <div className="w-full overflow-x-auto bg-[#150F38] border border-[#3A3280] rounded-xl p-3 sm:p-4">
              <IsomerDiagramSvg
                svgType={activeIsomer.svgType}
                geometriMode={isGeoCapable ? geometriMode : 'datar'}
                viewStyle={viewStyle}
              />
            </div>

            {/* Condensed Formula Strip */}
            <div className="p-3.5 bg-[#150F38] border border-[#3A3280] rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-[11px] font-bold text-[#8E8BB5] uppercase tracking-wider">
                Rumus Struktur Mampat:
              </span>
              <span className="font-mono text-sm sm:text-base font-bold text-[#5EEAD4] break-words">
                {activeIsomer.rumusStruktur}
              </span>
            </div>

            {/* Pedagogical Explanation Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3.5 bg-[#150F38] border border-[#3A3280]/70 rounded-xl text-xs text-[#B8B5DE] leading-relaxed">
                <div className="font-bold text-[#EEEDFB] mb-1">
                  Ciri Struktur {activeIsomer.namaIUPAC}
                </div>
                <p>{activeIsomer.catatan}</p>
              </div>
              <div className="p-3.5 bg-[#150F38] border border-[#3A3280]/70 rounded-xl text-xs text-[#B8B5DE] leading-relaxed">
                <div className="font-bold text-[#EEEDFB] mb-1">
                  Mengapa disebut {typeInfo.judul}?
                </div>
                <p>{typeInfo.ringkas}</p>
              </div>
            </div>
          </div>
        </>
      ) : (
        /* Side-by-Side Comparison Mode */
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {[
              {
                label: 'Struktur Pembanding A',
                accent: 'text-[#5EEAD4]',
                selected: compareIsomerA,
                onSelect: setCompareIdA,
                geo: compareGeoA,
                onGeo: setCompareGeoA,
              },
              {
                label: 'Struktur Pembanding B',
                accent: 'text-[#FFA8C5]',
                selected: compareIsomerB,
                onSelect: setCompareIdB,
                geo: compareGeoB,
                onGeo: setCompareGeoB,
              },
            ].map((pane, idx) => {
              const paneHasGeo =
                pane.selected.svgType === '2-butena' ||
                pane.selected.svgType === '2-pentena';
              return (
                <div
                  key={idx}
                  className="p-4 bg-[#0F0B2A] border border-[#3A3280] rounded-2xl space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <span
                      className={`text-xs font-extrabold uppercase tracking-wider ${pane.accent}`}
                    >
                      {pane.label}
                    </span>
                    <select
                      aria-label={pane.label}
                      value={pane.selected.id}
                      onChange={(e) => pane.onSelect(e.target.value)}
                      className="bg-[#150F38] border border-[#3A3280] rounded-xl px-3 py-2 min-h-[40px] text-xs font-bold text-[#EEEDFB] focus:outline-none focus:border-[#A99CFF] cursor-pointer"
                    >
                      {formulaData.isomers.map((iso, iIdx) => (
                        <option key={iso.id} value={iso.id}>
                          #{iIdx + 1} {iso.namaIUPAC}
                        </option>
                      ))}
                    </select>
                  </div>

                  {paneHasGeo && (
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[11px] font-bold text-[#8E8BB5] mr-1">
                        Bentuk:
                      </span>
                      {(['datar', 'cis', 'trans'] as const).map((g) => (
                        <button
                          key={g}
                          type="button"
                          onClick={() => pane.onGeo(g)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-colors ${
                            pane.geo === g
                              ? 'bg-[#A99CFF] text-[#0F0B2A]'
                              : 'bg-[#150F38] text-[#B8B5DE] border border-[#3A3280]'
                          }`}
                        >
                          {g === 'datar' ? 'Rantai Datar' : g}
                        </button>
                      ))}
                    </div>
                  )}

                  <div className="w-full overflow-x-auto bg-[#150F38] border border-[#3A3280] rounded-xl p-2.5">
                    <IsomerDiagramSvg
                      svgType={pane.selected.svgType}
                      geometriMode={paneHasGeo ? pane.geo : 'datar'}
                      viewStyle={viewStyle}
                      compact
                    />
                  </div>

                  <div className="text-xs text-[#B8B5DE] space-y-1">
                    <div className="font-mono font-bold text-[#EEEDFB] break-words">
                      {pane.selected.rumusStruktur}
                    </div>
                    <p className="text-[#8E8BB5] leading-relaxed">
                      {pane.selected.catatan}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Dynamic Comparison Insight */}
          <div className="p-4 bg-[#150F38] border border-[#A99CFF]/40 rounded-2xl flex items-start gap-3">
            <Info className="w-5 h-5 text-[#A99CFF] shrink-0 mt-0.5" />
            <div className="text-xs sm:text-sm text-[#B8B5DE] leading-relaxed">
              <div className="font-bold text-[#EEEDFB] mb-0.5">
                Kesimpulan Perbandingan: {comparisonInsight.jenis}
              </div>
              <p>{comparisonInsight.penjelasan}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
