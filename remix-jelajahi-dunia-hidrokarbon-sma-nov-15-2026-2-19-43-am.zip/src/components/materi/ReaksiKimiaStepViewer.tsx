/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Reaksi Kimia Hidrokarbon Langkah Demi Langkah (Interaktif)
 * Dilengkapi diagram molekul SVG (ReaksiDiagramSvg), ringkasan inti tiap reaksi,
 * stepper tahapan yang dapat diklik langsung, serta navigasi responsif di semua perangkat.
 */

import React, { useState } from 'react';
import { KEGIATAN_3_DATA } from '../../data';
import { ReaksiDiagramSvg } from './ReaksiDiagramSvg';
import { ChevronRight, ChevronLeft, RefreshCw } from 'lucide-react';

const INTI_REAKSI_RINGKAS: Record<string, string> = {
  'rx-pembakaran': 'Hidrokarbon + O₂ → CO₂ + H₂O',
  'rx-substitusi': 'Alkana tukar 1 atom H ↔ Cl',
  'rx-eliminasi': 'Ikatan tunggal (—) → rangkap (=)',
  'rx-adisi-alkena': 'Ikatan rangkap (=) → tunggal (—)',
  'rx-adisi-alkuna': 'Rangkap tiga (≡) → (=) → (—)',
  'rx-markovnikov': 'H masuk ke C yang lebih kaya H',
};

export const ReaksiKimiaStepViewer: React.FC = () => {
  const reaksiList = KEGIATAN_3_DATA.reaksiKimiaList;
  const [selectedRxId, setSelectedRxId] = useState<string>('rx-pembakaran');
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);

  const activeRx = reaksiList.find((r) => r.id === selectedRxId) || reaksiList[0];
  const step = activeRx.steps[currentStepIndex];

  const handleSelectRx = (id: string) => {
    setSelectedRxId(id);
    setCurrentStepIndex(0);
  };

  const handleNext = () => {
    if (currentStepIndex < activeRx.steps.length - 1) {
      setCurrentStepIndex((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex((prev) => prev - 1);
    }
  };

  const handleReset = () => {
    setCurrentStepIndex(0);
  };

  return (
    <div className="bg-[#1E1850] border border-[#3A3280] rounded-2xl p-5 sm:p-7 shadow-lg space-y-6">
      <div>
        <div className="flex items-center gap-2 mb-1.5">
          <span className="text-xs font-bold uppercase tracking-wider text-[#5EEAD4]">
            Simulasi Mekanisme Reaksi
          </span>
        </div>
        <h3 className="text-xl sm:text-2xl font-bold text-[#EEEDFB]">
          Reaksi-Reaksi Senyawa Hidrokarbon
        </h3>
        <p className="text-xs sm:text-sm text-[#B8B5DE] mt-1 leading-relaxed">
          Pilih jenis reaksi di bawah, lalu telusuri setiap tahap untuk melihat ikatan mana yang terputus dan bagaimana atom baru masuk membentuk produk.
        </p>
      </div>

      {/* Reaksi Type Tabs (6 Reaksi: A - F) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
        {reaksiList.map((r) => {
          const isSelected = selectedRxId === r.id;
          return (
            <button
              key={r.id}
              type="button"
              onClick={() => handleSelectRx(r.id)}
              className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                isSelected
                  ? 'bg-[#150F38] border-[#5EEAD4] shadow-md shadow-[#5EEAD4]/10'
                  : 'bg-[#0F0B2A] border-[#3A3280] text-[#B8B5DE] hover:text-[#EEEDFB] hover:border-[#8E8BB5]'
              }`}
            >
              <div className="flex items-center justify-between w-full gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className={`w-6 h-6 rounded-md flex items-center justify-center font-mono text-xs font-bold shrink-0 ${
                      isSelected ? 'bg-[#5EEAD4] text-[#0F0B2A]' : 'bg-[#1E1850] text-[#EEEDFB]'
                    }`}
                  >
                    {r.nomor}
                  </span>
                  <span
                    className={`text-xs sm:text-sm font-bold leading-tight truncate ${
                      isSelected ? 'text-[#5EEAD4]' : 'text-[#EEEDFB]'
                    }`}
                  >
                    {r.judul.split('(')[0].trim()}
                  </span>
                </div>
              </div>
              <div className="text-[11px] font-mono text-[#B8B5DE] truncate">
                {INTI_REAKSI_RINGKAS[r.id] || r.golongan}
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Interactive Stage for Selected Reaction */}
      <div className="p-4 sm:p-6 bg-[#0F0B2A] border border-[#3A3280] rounded-2xl space-y-5">
        {/* Header Reaction Info */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-[#3A3280] pb-4">
          <div>
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs">
              <span className="font-mono font-bold text-[#5EEAD4]">
                Reaksi {activeRx.nomor}
              </span>
              <span className="text-[#3A3280]" aria-hidden="true">·</span>
              <span className="font-semibold text-[#B8B5DE]">
                {activeRx.golongan}
              </span>
            </div>
            <h4 className="text-lg sm:text-xl font-bold text-[#EEEDFB] mt-1">
              {activeRx.judul}
            </h4>
          </div>

          {/* Clickable 3-Stage Stepper Tabs */}
          <div
            role="tablist"
            aria-label="Pilih tahapan reaksi"
            className="flex items-center gap-1.5 bg-[#150F38] border border-[#3A3280] rounded-xl p-1 self-start md:self-auto"
          >
            {activeRx.steps.map((st, idx) => {
              const isCurrent = idx === currentStepIndex;
              const shortLabel =
                idx === 0 ? '1. Awal' : idx === 1 ? '2. Proses' : '3. Hasil';
              return (
                <button
                  key={st.tahap}
                  type="button"
                  role="tab"
                  aria-selected={isCurrent}
                  onClick={() => setCurrentStepIndex(idx)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    isCurrent
                      ? 'bg-[#1E1850] text-[#5EEAD4] border border-[#5EEAD4]/50'
                      : 'text-[#B8B5DE] hover:text-[#EEEDFB]'
                  }`}
                >
                  {shortLabel}
                </button>
              );
            })}
          </div>
        </div>

        {/* Persamaan Reaksi Bersih */}
        <div className="p-3.5 bg-[#150F38] border border-[#3A3280] rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#B8B5DE] shrink-0">
            Persamaan Reaksi:
          </span>
          <span className="font-mono text-xs sm:text-sm font-bold text-[#5EEAD4] overflow-x-auto">
            {activeRx.persamaanReaksi}
          </span>
        </div>

        {/* Dynamic Visual Stage Box */}
        <div className="p-4 sm:p-6 bg-[#1E1850] border border-[#3A3280] rounded-2xl space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="font-semibold text-[#B8B5DE]">
              {step.keadaan === 'awal' && 'Keadaan Awal · Molekul Pereaksi'}
              {step.keadaan === 'pemutusan' && 'Proses Reaksi · Pemutusan & Penataan Ikatan'}
              {step.keadaan === 'hasil_akhir' && 'Keadaan Akhir · Produk Reaksi Terbentuk'}
            </span>
            <span
              className={`font-mono text-xs font-bold ${
                step.keadaan === 'awal'
                  ? 'text-[#B4A7FF]'
                  : step.keadaan === 'pemutusan'
                  ? 'text-[#FFA8C5]'
                  : 'text-[#5EEAD4]'
              }`}
            >
              Tahap {step.tahap}: {step.subJudul}
            </span>
          </div>

          {/* Visual Molecular SVG Mechanism Diagram */}
          <ReaksiDiagramSvg reaksiId={activeRx.id} tahap={step.tahap} />

          {/* Compact Equation Bar */}
          <div className="py-2.5 px-3.5 font-mono text-xs sm:text-sm font-bold text-[#EEEDFB] text-center bg-[#0F0B2A]/80 rounded-xl border border-[#3A3280]/70 overflow-x-auto">
            {step.visualFormula}
          </div>

          {/* Mechanism Explanation */}
          <div className="p-4 bg-[#150F38] rounded-xl text-left border border-[#3A3280]/60 space-y-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#A99CFF] block">
              Penjelasan Tahap Ini:
            </span>
            <p className="text-xs sm:text-sm text-[#EEEDFB] leading-relaxed">
              {step.deskripsiMekanisme}
            </p>
          </div>
        </div>

        {/* Stepper Navigation Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
          <button
            type="button"
            onClick={handlePrev}
            disabled={currentStepIndex === 0}
            className="px-3.5 sm:px-4 py-2 rounded-xl border border-[#3A3280] text-xs font-semibold text-[#B8B5DE] hover:text-[#EEEDFB] hover:bg-[#150F38] disabled:opacity-30 disabled:cursor-not-allowed transition-all cursor-pointer flex items-center gap-1.5 min-h-[40px]"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Sebelumnya</span>
          </button>

          <button
            type="button"
            onClick={handleReset}
            className="p-2.5 rounded-xl border border-[#3A3280] bg-[#150F38] text-xs text-[#B8B5DE] hover:text-[#EEEDFB] transition-colors cursor-pointer min-h-[40px]"
            title="Ulangi dari tahap 1"
            aria-label="Ulangi dari tahap 1"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={handleNext}
            disabled={currentStepIndex === activeRx.steps.length - 1}
            className="px-4 sm:px-5 py-2.5 rounded-xl bg-[#A99CFF] text-[#0F0B2A] text-xs sm:text-sm font-bold hover:bg-[#9889FC] disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer flex items-center gap-1.5 shadow-md shadow-[#A99CFF]/15 min-h-[40px] whitespace-nowrap"
          >
            <span>
              {currentStepIndex === activeRx.steps.length - 1
                ? 'Tahap Selesai'
                : 'Langkah Berikutnya'}
            </span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
