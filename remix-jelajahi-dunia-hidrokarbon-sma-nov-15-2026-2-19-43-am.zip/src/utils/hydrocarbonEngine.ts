/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Mesin Kimia & Validator Graf Molekul Hidrokarbon
 * - Menghitung valensi atom C & jumlah atom H implisit secara otomatis
 * - Membentuk rumus molekul (CₙHₘ) dan mendeteksi golongan (Alkana/Alkena/Alkuna)
 * - Menghitung posisi atom C (1°, 2°, 3°, 4°) dan rantai induk terpanjang
 * - Memvalidasi kesesuaian struktur siswa terhadap target menggunakan isomorfisme graf eksak
 */

export interface GridAtom {
  id: string;
  row: number;
  col: number;
}

export interface GridBond {
  id: string;
  from: string;
  to: string;
  order: 1 | 2 | 3;
}

export interface StructureChallenge {
  id: string;
  level: number;
  tingkat: 'Mudah' | 'Sedang' | 'Tantangan';
  golongan: 'alkana' | 'alkena' | 'alkuna';
  namaIUPAC: string;
  rumusMolekul: string;
  jumlahC: number;
  jumlahH: number;
  panjangRantaiInduk: number;
  soalTeks: string;
  petunjuk: string;
  pembahasan: string;
  catatanTambahan?: string;
  referenceAtoms: GridAtom[];
  referenceBonds: GridBond[];
}

export interface AtomComputedInfo {
  atomId: string;
  bondOrderSum: number;
  neighborCount: number;
  implicitH: number;
  formulaLabel: string;
  degreeType: '0°' | '1°' | '2°' | '3°' | '4°';
  isValidValence: boolean;
}

export interface MoleculeAnalysis {
  atomCount: number;
  hydrogenCount: number;
  formula: string;
  isConnected: boolean;
  hasCycle: boolean;
  isValidValence: boolean;
  doubleBondCount: number;
  tripleBondCount: number;
  golonganLabel: string;
  longestChainLength: number;
  longestChainIds: string[];
  atomInfoMap: Record<string, AtomComputedInfo>;
  degreeCounts: {
    primer: number;
    sekunder: number;
    tersier: number;
    kuarterner: number;
  };
}

export interface ValidationResult {
  isCorrect: boolean;
  status: 'correct' | 'incorrect' | 'incomplete';
  headline: string;
  diagnostics: string[];
  matchedChainIds?: string[];
}

const SUBSCRIPT_DIGITS: Record<string, string> = {
  '0': '₀',
  '1': '₁',
  '2': '₂',
  '3': '₃',
  '4': '₄',
  '5': '₅',
  '6': '₆',
  '7': '₇',
  '8': '₈',
  '9': '₉',
};

export function toSubscript(num: number): string {
  return String(num)
    .split('')
    .map((d) => SUBSCRIPT_DIGITS[d] || d)
    .join('');
}

export function makeBondId(aId: string, bId: string): string {
  return aId < bId ? `${aId}__${bId}` : `${bId}__${aId}`;
}

/**
 * Membangun adjacency map dari atoms & bonds
 */
function buildAdjacency(atoms: GridAtom[], bonds: GridBond[]) {
  const adj: Record<string, { neighborId: string; order: 1 | 2 | 3 }[]> = {};
  for (const atom of atoms) {
    adj[atom.id] = [];
  }
  for (const bond of bonds) {
    if (adj[bond.from] && adj[bond.to]) {
      adj[bond.from].push({ neighborId: bond.to, order: bond.order });
      adj[bond.to].push({ neighborId: bond.from, order: bond.order });
    }
  }
  return adj;
}

/**
 * Menghitung rantai karbon terpanjang (untuk graf asiklik/pohon).
 * Jika ada ikatan rangkap, memprioritaskan rantai terpanjang yang memuat ikatan rangkap terbanyak.
 */
export function findLongestCarbonChain(
  atoms: GridAtom[],
  bonds: GridBond[]
): string[] {
  if (atoms.length === 0) return [];
  if (atoms.length === 1) return [atoms[0].id];

  const adj = buildAdjacency(atoms, bonds);
  let bestPath: string[] = [];
  let bestDoubleTripleScore = -1;

  // DFS dari setiap atom ujung (atau semua atom jika ada siklus kecil)
  const candidates = atoms.filter((a) => adj[a.id].length <= 1);
  const startNodes = candidates.length > 0 ? candidates : atoms;

  const dfs = (
    currentId: string,
    visited: Set<string>,
    path: string[],
    multiBondScore: number
  ) => {
    const isBetter =
      multiBondScore > bestDoubleTripleScore ||
      (multiBondScore === bestDoubleTripleScore && path.length > bestPath.length);

    if (isBetter) {
      bestPath = [...path];
      bestDoubleTripleScore = multiBondScore;
    }

    for (const edge of adj[currentId]) {
      if (!visited.has(edge.neighborId)) {
        visited.add(edge.neighborId);
        path.push(edge.neighborId);
        const addScore = edge.order > 1 ? 1 : 0;
        dfs(edge.neighborId, visited, path, multiBondScore + addScore);
        path.pop();
        visited.delete(edge.neighborId);
      }
    }
  };

  for (const start of startNodes) {
    const visited = new Set<string>([start.id]);
    dfs(start.id, visited, [start.id], 0);
  }

  return bestPath;
}

/**
 * Menganalisis keseluruhan molekul yang disusun siswa
 */
export function analyzeMolecule(
  atoms: GridAtom[],
  bonds: GridBond[]
): MoleculeAnalysis {
  const adj = buildAdjacency(atoms, bonds);
  const atomInfoMap: Record<string, AtomComputedInfo> = {};

  let totalH = 0;
  let allValidValence = true;
  let primer = 0;
  let sekunder = 0;
  let tersier = 0;
  let kuarterner = 0;

  for (const atom of atoms) {
    const edges = adj[atom.id] || [];
    const bondOrderSum = edges.reduce((acc, e) => acc + e.order, 0);
    const neighborCount = edges.length;
    const isValidValence = bondOrderSum <= 4;
    if (!isValidValence) allValidValence = false;

    const implicitH = Math.max(0, 4 - bondOrderSum);
    totalH += implicitH;

    let formulaLabel = 'C';
    if (implicitH === 1) formulaLabel = 'CH';
    else if (implicitH > 1) formulaLabel = `CH${toSubscript(implicitH)}`;

    let degreeType: AtomComputedInfo['degreeType'] = '0°';
    if (neighborCount === 1) {
      degreeType = '1°';
      primer++;
    } else if (neighborCount === 2) {
      degreeType = '2°';
      sekunder++;
    } else if (neighborCount === 3) {
      degreeType = '3°';
      tersier++;
    } else if (neighborCount === 4) {
      degreeType = '4°';
      kuarterner++;
    }

    atomInfoMap[atom.id] = {
      atomId: atom.id,
      bondOrderSum,
      neighborCount,
      implicitH,
      formulaLabel,
      degreeType,
      isValidValence,
    };
  }

  // Connectivity check via BFS
  let isConnected = true;
  if (atoms.length > 1) {
    const visited = new Set<string>();
    const queue = [atoms[0].id];
    visited.add(atoms[0].id);
    while (queue.length > 0) {
      const curr = queue.shift()!;
      for (const edge of adj[curr]) {
        if (!visited.has(edge.neighborId)) {
          visited.add(edge.neighborId);
          queue.push(edge.neighborId);
        }
      }
    }
    isConnected = visited.size === atoms.length;
  }

  const hasCycle = isConnected && atoms.length > 0 && bonds.length >= atoms.length;
  const doubleBondCount = bonds.filter((b) => b.order === 2).length;
  const tripleBondCount = bonds.filter((b) => b.order === 3).length;

  let golonganLabel = 'Belum Terbentuk';
  if (atoms.length > 0) {
    if (!isConnected) {
      golonganLabel = 'Rantai Belum Tersambung Utuh';
    } else if (!allValidValence) {
      golonganLabel = 'Valensi Karbon Melebihi 4';
    } else if (hasCycle) {
      golonganLabel = doubleBondCount > 0 ? 'Sikloalkena' : 'Sikloalkana (Rantai Tertutup)';
    } else if (doubleBondCount > 0 && tripleBondCount > 0) {
      golonganLabel = 'Alkenuna (Rangkap 2 & 3)';
    } else if (tripleBondCount > 0) {
      golonganLabel = tripleBondCount > 1 ? 'Alkadiuna' : 'Alkuna';
    } else if (doubleBondCount > 0) {
      golonganLabel = doubleBondCount > 1 ? 'Alkadiena' : 'Alkena';
    } else {
      golonganLabel = 'Alkana';
    }
  }

  let formula = '—';
  if (atoms.length > 0) {
    const cSub = atoms.length === 1 ? '' : toSubscript(atoms.length);
    const hSub = totalH === 1 ? '' : toSubscript(totalH);
    formula = totalH > 0 ? `C${cSub}H${hSub}` : `C${cSub}`;
  }

  const longestChainIds = isConnected ? findLongestCarbonChain(atoms, bonds) : [];

  return {
    atomCount: atoms.length,
    hydrogenCount: totalH,
    formula,
    isConnected,
    hasCycle,
    isValidValence: allValidValence,
    doubleBondCount,
    tripleBondCount,
    golonganLabel,
    longestChainLength: longestChainIds.length,
    longestChainIds,
    atomInfoMap,
    degreeCounts: { primer, sekunder, tersier, kuarterner },
  };
}

/**
 * Menguji isomorfisme graf eksak antara struktur siswa dan struktur target
 * dengan mempertimbangkan orde ikatan (1, 2, 3) pada setiap sisi.
 */
export function areHydrocarbonGraphsIsomorphic(
  studentAtoms: GridAtom[],
  studentBonds: GridBond[],
  targetAtoms: GridAtom[],
  targetBonds: GridBond[]
): boolean {
  if (studentAtoms.length !== targetAtoms.length) return false;
  if (studentBonds.length !== targetBonds.length) return false;
  if (studentAtoms.length === 0) return true;

  const sAdj = buildAdjacency(studentAtoms, studentBonds);
  const tAdj = buildAdjacency(targetAtoms, targetBonds);

  // Build quick edge-order lookup for student graph
  const sEdgeOrder: Record<string, number> = {};
  for (const b of studentBonds) {
    sEdgeOrder[`${b.from}|${b.to}`] = b.order;
    sEdgeOrder[`${b.to}|${b.from}`] = b.order;
  }

  // Compute signature: sorted list of incident bond orders (e.g., "1,1,2")
  const getSignature = (
    id: string,
    adj: Record<string, { neighborId: string; order: 1 | 2 | 3 }[]>
  ) =>
    adj[id]
      .map((e) => e.order)
      .sort((a, b) => a - b)
      .join(',');

  const sSigs: Record<string, string> = {};
  const tSigs: Record<string, string> = {};
  for (const a of studentAtoms) sSigs[a.id] = getSignature(a.id, sAdj);
  for (const a of targetAtoms) tSigs[a.id] = getSignature(a.id, tAdj);

  // Sort signatures to quickly reject non-isomorphic graphs
  const sortedSSigs = Object.values(sSigs).sort().join(';');
  const sortedTSigs = Object.values(tSigs).sort().join(';');
  if (sortedSSigs !== sortedTSigs) return false;

  // Order target vertices by degree descending for fast backtracking
  const orderedTargetIds = [...targetAtoms]
    .sort((a, b) => tAdj[b.id].length - tAdj[a.id].length)
    .map((a) => a.id);

  const mapping: Record<string, string> = {}; // targetId -> studentId
  const usedStudentIds = new Set<string>();

  const backtrack = (idx: number): boolean => {
    if (idx === orderedTargetIds.length) return true;

    const tId = orderedTargetIds[idx];
    const tSig = tSigs[tId];

    for (const sAtom of studentAtoms) {
      const sId = sAtom.id;
      if (usedStudentIds.has(sId)) continue;
      if (sSigs[sId] !== tSig) continue;

      // Verify all edges between tId and already-mapped target neighbors
      let consistent = true;
      for (const tEdge of tAdj[tId]) {
        const mappedNeighbor = mapping[tEdge.neighborId];
        if (mappedNeighbor) {
          const orderInStudent = sEdgeOrder[`${sId}|${mappedNeighbor}`];
          if (orderInStudent !== tEdge.order) {
            consistent = false;
            break;
          }
        }
      }

      if (!consistent) continue;

      mapping[tId] = sId;
      usedStudentIds.add(sId);

      if (backtrack(idx + 1)) return true;

      delete mapping[tId];
      usedStudentIds.delete(sId);
    }

    return false;
  };

  return backtrack(0);
}

/**
 * Memvalidasi struktur yang digambar siswa terhadap soal tantangan tertentu
 * dan menghasilkan umpan balik diagnostik yang ramah siswa.
 */
export function validateStructureAgainstChallenge(
  studentAtoms: GridAtom[],
  studentBonds: GridBond[],
  challenge: StructureChallenge
): ValidationResult {
  if (studentAtoms.length === 0) {
    return {
      isCorrect: false,
      status: 'incomplete',
      headline: 'Kanvas Struktur Masih Kosong',
      diagnostics: [
        'Letakkan atom Karbon (C) pada grid dan hubungkan sesuai struktur yang diminta.',
      ],
    };
  }

  const analysis = analyzeMolecule(studentAtoms, studentBonds);

  if (!analysis.isValidValence) {
    return {
      isCorrect: false,
      status: 'incorrect',
      headline: 'Ada Atom Karbon dengan Valensi Berlebih',
      diagnostics: [
        'Setiap atom karbon (C) maksimal hanya boleh memiliki 4 ikatan kovalen (aturan oktet). Periksa kembali ikatan rangkap atau cabangnya.',
      ],
    };
  }

  if (!analysis.isConnected) {
    return {
      isCorrect: false,
      status: 'incomplete',
      headline: 'Molekul Belum Tersambung Utuh',
      diagnostics: [
        'Terdapat atom C yang masih terpisah (belum berikatan dengan rantai utama). Sambungkan seluruh atom C menjadi satu molekul tunggal.',
      ],
    };
  }

  // Exact graph isomorphism check
  const matched = areHydrocarbonGraphsIsomorphic(
    studentAtoms,
    studentBonds,
    challenge.referenceAtoms,
    challenge.referenceBonds
  );

  if (matched) {
    return {
      isCorrect: true,
      status: 'correct',
      headline: `Tepat Sekali! Struktur ${challenge.namaIUPAC} Benar!`,
      diagnostics: [
        `Rumus molekul terbentuk ${analysis.formula} dengan rantai induk ${challenge.panjangRantaiInduk} atom C dan susunan ikatan/cabang yang sesuai.`,
      ],
      matchedChainIds: analysis.longestChainIds,
    };
  }

  // Generate helpful chemical diagnostics without leaking exact coordinates
  const diagnostics: string[] = [];

  if (analysis.hasCycle) {
    diagnostics.push(
      'Strukturmu membentuk cincin tertutup (siklis), sedangkan senyawa target adalah hidrokarbon rantai terbuka (alifatik).'
    );
  }

  if (analysis.atomCount !== challenge.jumlahC) {
    const diff = challenge.jumlahC - analysis.atomCount;
    if (diff > 0) {
      diagnostics.push(
        `Jumlah atom C masih kurang: kamu baru memasang ${analysis.atomCount} atom C, padahal ${challenge.namaIUPAC} memiliki total ${challenge.jumlahC} atom C (${challenge.rumusMolekul}).`
      );
    } else {
      diagnostics.push(
        `Jumlah atom C berlebih: kamu memasang ${analysis.atomCount} atom C, padahal ${challenge.namaIUPAC} memiliki total ${challenge.jumlahC} atom C (${challenge.rumusMolekul}).`
      );
    }
  }

  // Check bond types
  const targetDouble = challenge.referenceBonds.filter((b) => b.order === 2).length;
  const targetTriple = challenge.referenceBonds.filter((b) => b.order === 3).length;

  if (analysis.doubleBondCount !== targetDouble) {
    if (targetDouble > 0 && analysis.doubleBondCount === 0) {
      diagnostics.push(
        `Senyawa "${challenge.namaIUPAC}" termasuk golongan ALKENA — kamu perlu memasang ${targetDouble} ikatan rangkap dua (=).`
      );
    } else if (targetDouble === 0 && analysis.doubleBondCount > 0) {
      diagnostics.push(
        `Senyawa "${challenge.namaIUPAC}" tidak memiliki ikatan rangkap dua (=). Ubah ikatan rangkap dua menjadi ikatan yang sesuai.`
      );
    } else {
      diagnostics.push(
        `Jumlah ikatan rangkap dua (=) belum tepat (terpasang ${analysis.doubleBondCount}, seharusnya ${targetDouble}).`
      );
    }
  }

  if (analysis.tripleBondCount !== targetTriple) {
    if (targetTriple > 0 && analysis.tripleBondCount === 0) {
      diagnostics.push(
        `Senyawa "${challenge.namaIUPAC}" termasuk golongan ALKUNA — kamu perlu memasang ${targetTriple} ikatan rangkap tiga (≡).`
      );
    } else if (targetTriple === 0 && analysis.tripleBondCount > 0) {
      diagnostics.push(
        `Senyawa "${challenge.namaIUPAC}" tidak memiliki ikatan rangkap tiga (≡).`
      );
    } else {
      diagnostics.push(
        `Jumlah ikatan rangkap tiga (≡) belum tepat (terpasang ${analysis.tripleBondCount}, seharusnya ${targetTriple}).`
      );
    }
  }

  if (
    !analysis.hasCycle &&
    analysis.longestChainLength !== challenge.panjangRantaiInduk
  ) {
    diagnostics.push(
      `Rantai karbon terpanjang pada gambarmu adalah ${analysis.longestChainLength} atom C, sedangkan rantai induk pada "${challenge.namaIUPAC}" harus memiliki ${challenge.panjangRantaiInduk} atom C berurutan.`
    );
  }

  if (diagnostics.length === 0) {
    diagnostics.push(
      'Jumlah atom C, jenis ikatan, dan panjang rantai induknya sudah mirip, tetapi posisi cabang atau letak ikatan rangkapnya belum tepat. Periksa kembali nomor atom C pada rantai induk!'
    );
  }

  return {
    isCorrect: false,
    status: 'incorrect',
    headline: 'Struktur Belum Sesuai, Ayo Periksa Lagi!',
    diagnostics,
  };
}
